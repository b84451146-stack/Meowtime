# MeowTime (Android)

Per-app daily limits (max 2 h, one +15 min extension per app per day), blocking with an accessibility service,
Focus mode, bedtime lock, phone pickups, Sunday weekly report, Insights, streaks and badge rewards, weekly goal, break reminders, 9 pm summary, first-run welcome.

Build: push this zip to GitHub; the workflow builds app-debug.apk (artifact "MeowTime-apk").
After install: allow restricted settings (App info > three dots), turn on Usage Access, turn on the MeowTime
blocker in Accessibility, allow notifications.

Written without an Android SDK, so expect to fix small build errors.
