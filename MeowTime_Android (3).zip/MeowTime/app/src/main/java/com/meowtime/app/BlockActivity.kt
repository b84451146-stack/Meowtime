package com.meowtime.app

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.animation.OvershootInterpolator
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** The pop-up shown when a blocked app is opened. A live ring counts down to the reset (or the end of Focus). */
class BlockActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pkg = intent.getStringExtra("pkg") ?: ""
        val name = Limits.apps.entries.firstOrNull { it.value == pkg }?.key ?: "This app"
        val focus = Focus.active(this)
        val bed = !focus && Bedtime.active(this)
        val mins = Limits.usedMinutes(this, pkg)
        val d = resources.displayMetrics.density
        fun tv(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = size; setTextColor(color); gravity = Gravity.CENTER; setPadding(0, 16, 0, 16)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }
        val icon = TextView(this).apply { text = if (focus) "📚" else if (bed) "🌙" else "⏱"; textSize = 72f; gravity = Gravity.CENTER }
        val ring = RingView(this).apply {
            color = if (focus) Color.parseColor("#14B8A0") else if (bed) Color.parseColor("#7A5AE0") else Color.parseColor("#F0475A")
            labelScale = 0.15f; sub = if (focus) "focus left" else if (bed) "until morning" else "until reset"
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0D0F26")); setPadding(48, 48, 48, 48)
            addView(icon, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(tv(if (focus) "Focus time!" else if (bed) "Bedtime!" else "Enough screen time!", 28f, Color.WHITE, true))
            addView(tv(if (focus) "$name is paused until your session ends." else if (bed) "$name is locked until ${Bedtime.fmt(Bedtime.endMin(this@BlockActivity))}." else "$name limit reached · $mins min today", 16f, Color.parseColor("#C9B8FF")))
            addView(ring, LinearLayout.LayoutParams((240 * d).toInt(), (240 * d).toInt()).apply { topMargin = (8 * d).toInt(); bottomMargin = (8 * d).toInt() })
            addView(tv(if (focus) "Eyes on your work. You've got this! 📚" else if (bed) "Sleep well. Your phone will be here tomorrow. 🌙" else "Go do some work, study or step outside.", 17f))
            if (!focus && !bed && Limits.canExtend(this@BlockActivity, pkg)) addView(Button(this@BlockActivity).apply {
                text = "+${Limits.EXTRA} min (once today)"
                setOnClickListener {
                    if (Limits.extend(this@BlockActivity, pkg)) Toast.makeText(this@BlockActivity, "+${Limits.EXTRA} minutes. Use them wisely! 👍", Toast.LENGTH_LONG).show()
                    onBackPressed()
                }
            })
            addView(Button(this@BlockActivity).apply {
                text = "Back to MeowTime"
                setOnClickListener { startActivity(Intent(this@BlockActivity, MainActivity::class.java)); finish() }
            })
        })
        // the icon pops in, a limit shakes it once, then it bobs gently
        icon.alpha = 0f; icon.scaleX = 0.6f; icon.scaleY = 0.6f
        icon.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(500).setInterpolator(OvershootInterpolator()).start()
        if (!focus) ObjectAnimator.ofFloat(icon, "rotation", 0f, -8f, 8f, -8f, 8f, -4f, 4f, 0f).apply { startDelay = 450; duration = 650 }.start()
        ObjectAnimator.ofFloat(icon, "translationY", 0f, -10 * d).apply {
            startDelay = 1200; duration = 1300; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
        }.start()

        // live countdown, once per second
        val tick = object : Runnable {
            override fun run() {
                if (focus) {
                    if (!Focus.active(this@BlockActivity)) { finish(); return }
                    val rem = Focus.remainingMs(this@BlockActivity)
                    ring.label = Limits.clock(rem)
                    ring.frac = 1f - rem / Focus.plannedMs(this@BlockActivity).toFloat()
                } else if (bed) {
                    if (!Bedtime.active(this@BlockActivity)) { finish(); return }
                    val ms = Bedtime.msUntilEnd(this@BlockActivity)
                    ring.label = Limits.clock(ms)
                    ring.frac = 1f - ms / Bedtime.spanMs(this@BlockActivity).toFloat()
                } else {
                    val ms = Limits.millisUntilReset()
                    ring.label = Limits.clock(ms)
                    ring.frac = 1f - ms / 86_400_000f
                }
                ring.invalidate()
                handler.postDelayed(this, 1000)
            }
        }
        handler.post(tick)
    }

    override fun onDestroy() { handler.removeCallbacksAndMessages(null); super.onDestroy() }

    @Deprecated("Back goes home so the blocked app stays covered")
    override fun onBackPressed() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
}
