package com.meowtime.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

object Notifier {
    private const val CH = "meow_alerts"

    /** A pop-up notification. (mood is ignored; kept so older calls still compile.) */
    fun post(c: Context, id: Int, title: String, body: String, mood: String = "") {
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "MeowTime alerts", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(c, CH)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title).setContentText(body)
            .setStyle(Notification.BigTextStyle().bigText(body))
            .setContentIntent(open).setAutoCancel(true).build()
        nm.notify(id, n)
    }

    /** Once per day per app, when 80% of the limit is used. */
    fun checkWarnings(c: Context, usage: Map<String, Long>) {
        val p = c.getSharedPreferences("meowtime", Context.MODE_PRIVATE)
        for ((name, pkg) in Limits.apps) {
            val lim = Limits.limitMin(c, pkg); val used = usage[pkg] ?: 0L
            if (lim > 0 && used >= lim * 0.8 && used < lim && p.getInt("warned_$pkg", 0) != Limits.day()) {
                p.edit().putInt("warned_$pkg", Limits.day()).apply()
                post(c, pkg.hashCode() + 1, "$name: almost out of time", "${lim - used} min left today. Wrap it up soon! ⚠️", "worried")
            }
        }
    }
}
