package com.meowtime.app

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import java.util.Calendar

object Limits {
    const val MAX = 240   // 4 hours is the highest daily limit allowed

    val apps = linkedMapOf(
        "Instagram" to "com.instagram.android",
        "YouTube" to "com.google.android.youtube",
        "Snapchat" to "com.snapchat.android",
        "Facebook" to "com.facebook.katana",
        "Reddit" to "com.reddit.frontpage"
    )
    private val defaults = mapOf(
        "com.instagram.android" to 20, "com.google.android.youtube" to 30,
        "com.snapchat.android" to 15, "com.facebook.katana" to 10, "com.reddit.frontpage" to 20
    )

    private fun prefs(c: Context) = c.getSharedPreferences("meowtime", Context.MODE_PRIVATE)

    fun day(): Int = Calendar.getInstance().let { it.get(Calendar.YEAR) * 10000 + (it.get(Calendar.MONTH) + 1) * 100 + it.get(Calendar.DAY_OF_MONTH) }

    /** Today's limit. A raised limit that was requested on an earlier day is applied here. */
    fun limitMin(c: Context, pkg: String): Int {
        val p = prefs(c)
        val pend = p.getInt("pend_$pkg", -1)
        if (pend >= 0 && p.getInt("pend_day_$pkg", 0) != day())
            p.edit().putInt(pkg, pend).remove("pend_$pkg").remove("pend_day_$pkg").apply()
        return p.getInt(pkg, defaults[pkg] ?: 30).coerceIn(1, MAX)
    }

    fun pendingMin(c: Context, pkg: String): Int? { limitMin(c, pkg); return prefs(c).getInt("pend_$pkg", -1).takeIf { it >= 0 } }

    /** Lowering a limit works at once. Raising it only starts tomorrow, so a block can't be dodged. Max is 4 hours. */
    fun setLimit(c: Context, pkg: String, wanted: Int): String {
        val min = wanted.coerceIn(1, MAX)
        val cur = limitMin(c, pkg)
        val e = prefs(c).edit()
        return if (min > cur) {
            e.putInt("pend_$pkg", min).putInt("pend_day_$pkg", day()).apply()
            "Higher limits start tomorrow, so you can't raise it to get more time today."
        } else {
            e.putInt(pkg, min).remove("pend_$pkg").remove("pend_day_$pkg").apply()
            "Limit set to $min min."
        }
    }

    private fun midnight(daysAgo: Int = 0): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        add(Calendar.DAY_OF_YEAR, -daysAgo)
    }.timeInMillis

    /** Minutes in the foreground per tracked app (one pass over the usage events). Default range is today. */
    fun usedAll(c: Context, start: Long = midnight(), end: Long = System.currentTimeMillis()): Map<String, Long> {
        val m = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val events = m.queryEvents(start, end)
        val e = UsageEvents.Event()
        val last = HashMap<String, Long>(); val total = HashMap<String, Long>()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val p = e.packageName
            if (p !in apps.values) continue
            when (e.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> last[p] = e.timeStamp
                UsageEvents.Event.MOVE_TO_BACKGROUND -> last.remove(p)?.let { total[p] = (total[p] ?: 0L) + (e.timeStamp - it) }
            }
        }
        for ((p, t) in last) total[p] = (total[p] ?: 0L) + (end - t)
        return total.mapValues { it.value / 60000 }
    }

    fun usedMinutes(c: Context, pkg: String): Long = usedAll(c)[pkg] ?: 0L

    /** Total tracked minutes for each of the last 7 days, oldest first (today is last). */
    fun dayTotals(c: Context): List<Long> = (6 downTo 0).map { d ->
        val start = midnight(d)
        val end = if (d == 0) System.currentTimeMillis() else start + 24 * 3600_000L
        usedAll(c, start, end).values.sum()
    }

    /** Blocked when the daily limit is used up, or while a Focus session is running. */
    fun isBlocked(c: Context, pkg: String): Boolean {
        if (pkg !in apps.values) return false
        if (Focus.active(c)) return true
        val limit = limitMin(c, pkg)
        return limit > 0 && usedMinutes(c, pkg) >= limit
    }

    fun millisUntilReset(): Long = midnight() + 24 * 3600_000L - System.currentTimeMillis()
}
