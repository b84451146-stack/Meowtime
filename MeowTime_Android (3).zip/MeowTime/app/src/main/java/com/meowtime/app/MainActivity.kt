package com.meowtime.app

import android.animation.Animator
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.Manifest
import android.app.AppOpsManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.text.InputType
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    // ---- colours: a dark "night" navy with bright accents ----
    private val BG = Color.parseColor("#0D0F26")
    private val SURF = Color.parseColor("#181B3D")
    private val INK = Color.parseColor("#F2F1FF")
    private val DARKINK = Color.parseColor("#14163F")
    private val MUTED = Color.parseColor("#9C9AC8")
    private val NAVY = Color.parseColor("#14163F")
    private val INDIGO = Color.parseColor("#4338B8")
    private val PURPLE = Color.parseColor("#9B7DFF")
    private val BLUE = Color.parseColor("#3D8BFF")
    private val TEAL = Color.parseColor("#1FD1B5")
    private val YELLOW = Color.parseColor("#FFC93C")
    private val ORANGE = Color.parseColor("#FF8A2B")
    private val PINK = Color.parseColor("#F0558A")
    private val RED = Color.parseColor("#FF5468")
    private val GREEN = Color.parseColor("#34D98A")
    private val LAV = Color.parseColor("#23265A")
    private val LINE = Color.parseColor("#2A2D5C")
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private var tab = 0
    private var onboardPage = 0
    private lateinit var content: FrameLayout
    private lateinit var nav: LinearLayout
    private val loops = mutableListOf<Animator>()
    private val handler = Handler(Looper.getMainLooper())
    private var focusMin = 25

    private fun prefs() = getSharedPreferences("meowtime", MODE_PRIVATE)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = SURF
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        content = FrameLayout(this)
        nav = LinearLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(nav, LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(root)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() {
        super.onResume()
        try { Streak.update(this) } catch (e: Exception) {}
        show()
    }
    override fun onPause() { super.onPause(); stopLoops() }
    private fun stopLoops() { loops.forEach { it.cancel() }; loops.clear(); handler.removeCallbacksAndMessages(null) }

    // ---------- permissions ----------
    private fun usageGranted(): Boolean {
        val ops = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }
    /** Phones write the service name in different ways (short or full), so compare the real component names. */
    private fun blockerOn(): Boolean {
        val list = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val mine = ComponentName(this, BlockerService::class.java)
        return list.split(':').any { ComponentName.unflattenFromString(it.trim()) == mine }
    }

    // ---------- small view helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tint(color: Int, alpha: Int) = (color and 0x00FFFFFF) or (alpha shl 24)
    private fun onColor(color: Int) = if (Color.luminance(color) > 0.5f) DARKINK else Color.WHITE
    private fun bg(color: Int, r: Int, stroke: Int = 0, sw: Int = 1) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(sw), stroke)
    }
    private fun darken(c: Int) = Color.rgb((Color.red(c) * 0.8f).toInt(), (Color.green(c) * 0.8f).toInt(), (Color.blue(c) * 0.8f).toInt())
    private fun gradient(c1: Int, c2: Int, r: Int) = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2)).apply { cornerRadius = dp(r).toFloat() }
    private fun text(t: CharSequence, sp: Float, color: Int = INK, bold: Boolean = false, spacing: Float = 0f) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(color); letterSpacing = spacing; if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun card(fill: Int = SURF) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = bg(fill, 28, LINE); setPadding(dp(20), dp(20), dp(20), dp(20))
    }
    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(top) }
    private fun page() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(16), dp(20), dp(24)) }
    private fun hm(m: Long) = Limits.hm(m)

    /** Little round brick studs, a decoration for cards. */
    private fun studs(color: Int, n: Int = 4): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        repeat(n) {
            addView(View(this@MainActivity).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(tint(color, 0x77)) }
            }, LinearLayout.LayoutParams(dp(12), dp(12)).apply { rightMargin = dp(6) })
        }
    }

    private fun pill(label: String, color: Int) = text(label, 14f, color, true).apply {
        background = bg(tint(color, 0x28), 20); setPadding(dp(14), dp(6), dp(14), dp(6))
    }

    private fun button(label: String, filled: Boolean, color: Int = PURPLE, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 15f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (filled) onColor(color) else color)
        background = if (filled) gradient(color, darken(color), 24) else bg(SURF, 24, color, 2)
        setPadding(dp(20), dp(12), dp(20), dp(12))
        setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }
        setOnClickListener { onClick() }
    }

    /** Green while there is lots of time, then yellow, orange and red as the limit gets close. */
    private fun barColor(frac: Float) = when { frac < 0.6f -> GREEN; frac < 0.8f -> YELLOW; frac < 1f -> ORANGE; else -> RED }

    /** A progress bar that fills up with an animation. */
    private fun bar(frac: Float, color: Int, track: Int = LINE): View {
        val tr = FrameLayout(this).apply { background = bg(track, 8) }
        val fill = View(this).apply { background = bg(color, 8) }
        tr.addView(fill, FrameLayout.LayoutParams(0, MATCH))
        tr.post {
            ValueAnimator.ofInt(0, (tr.width * frac.coerceIn(0f, 1f)).toInt()).apply {
                duration = 800; startDelay = 150
                addUpdateListener { (fill.layoutParams as FrameLayout.LayoutParams).width = it.animatedValue as Int; fill.requestLayout() }
            }.start()
        }
        return tr
    }

    /** Moves an existing bar (made by bar()) to a new fill and colour. */
    private fun setBar(tr: View, frac: Float, color: Int) {
        val fill = (tr as FrameLayout).getChildAt(0)
        fill.background = bg(color, 8)
        fill.layoutParams.width = (tr.width * frac.coerceIn(0f, 1f)).toInt(); fill.requestLayout()
    }

    private fun span(a: String, b: String) = SpannableString(a + b).apply {
        setSpan(ForegroundColorSpan(PURPLE), a.length, a.length + b.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    private fun stagger(col: ViewGroup) {
        for (i in 0 until col.childCount) {
            val v = col.getChildAt(i)
            v.alpha = 0f; v.translationY = dp(24).toFloat()
            v.animate().alpha(1f).translationY(0f).setStartDelay(i * 70L).setDuration(380).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun appColor(pkg: String) = when (pkg) {
        "com.instagram.android" -> Color.parseColor("#E1306C")
        "com.google.android.youtube" -> Color.parseColor("#F03A3A")
        "com.snapchat.android" -> Color.parseColor("#F5B800")
        "com.facebook.katana" -> Color.parseColor("#1877F2")
        else -> Color.parseColor("#FF5700")
    }

    // ---------- screens ----------
    private fun show() {
        stopLoops()
        content.removeAllViews()
        if (!prefs().getBoolean("onboarded", false)) {
            nav.visibility = View.GONE
            val col = onboarding()
            content.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(col) })
            stagger(col)
            return
        }
        nav.visibility = View.VISIBLE
        content.alpha = 0f; content.animate().alpha(1f).setDuration(220).start()
        val col = when (tab) { 0 -> home(); 1 -> limits(); 2 -> focus(); 3 -> insights(); else -> rewards() }
        content.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(col) })
        stagger(col)
        buildNav()
    }

    private fun buildNav() {
        nav.removeAllViews(); nav.setBackgroundColor(SURF); nav.setPadding(dp(8), dp(8), dp(8), dp(8))
        val items = listOf(Triple("🏠", "Home", PURPLE), Triple("🔒", "Limits", BLUE), Triple("📖", "Focus", TEAL),
            Triple("📈", "Insights", ORANGE), Triple("🏆", "Rewards", PINK))
        items.forEachIndexed { i, item ->
            val sel = i == tab
            val t = TextView(this).apply {
                text = "${item.first}\n${item.second}"; gravity = Gravity.CENTER; textSize = 12f
                setTextColor(if (sel) item.third else MUTED); if (sel) typeface = Typeface.DEFAULT_BOLD
                background = if (sel) bg(tint(item.third, 0x26), 20) else null
                setPadding(0, dp(8), 0, dp(8))
                if (sel) { scaleX = 0.82f; scaleY = 0.82f; animate().scaleX(1f).scaleY(1f).setDuration(320).setInterpolator(OvershootInterpolator(2f)).start() }
                setOnClickListener { if (tab != i) { tab = i; show() } }
            }
            nav.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
    }

    // ---------- first-time welcome ----------
    private fun onboarding(): LinearLayout {
        val col = page().apply { gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(24), dp(40), dp(24), dp(24)) }
        col.addView(text("●  ".repeat(onboardPage + 1) + "○  ".repeat(2 - onboardPage), 14f, PURPLE, true).apply { gravity = Gravity.CENTER })
        when (onboardPage) {
            0 -> {
                val hero = text("⏳", 96f).apply { gravity = Gravity.CENTER }
                col.addView(hero, lp(40))
                loops.add(ObjectAnimator.ofFloat(hero, "translationY", 0f, -dp(10).toFloat()).apply { duration = 1300; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE; start() })
                col.addView(text("Meet MeowTime", 32f, INK, true).apply { gravity = Gravity.CENTER }, lp(12))
                col.addView(text("Your study buddy who keeps your screen time in check.", 16f, MUTED).apply { gravity = Gravity.CENTER }, lp(8))
                col.addView(button("Next", true, PURPLE) { onboardPage = 1; show() }, lp(32))
            }
            1 -> {
                col.addView(text("How it works", 30f, INK, true).apply { gravity = Gravity.CENTER }, lp(20))
                val rows = listOf(
                    "🔒" to "Every app starts at 2 hours. Slide the limit down any time.",
                    "⏱" to "Hit the limit and MeowTime sends you home. You get one +15 min extension per app each day.",
                    "📖" to "Focus mode pauses your distracting apps while you study.",
                    "🔥" to "Stay under every limit to grow a streak and unlock badges."
                )
                for ((e, t) in rows) {
                    val r = card().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                    r.addView(text(e, 26f), LinearLayout.LayoutParams(dp(44), WRAP))
                    r.addView(text(t, 15f, INK), LinearLayout.LayoutParams(0, WRAP, 1f))
                    col.addView(r, lp(12))
                }
                col.addView(button("Next", true, BLUE) { onboardPage = 2; show() }, lp(24))
            }
            else -> {
                val granted = usageGranted(); val blocker = blockerOn()
                col.addView(text("Two quick permissions", 28f, INK, true).apply { gravity = Gravity.CENTER }, lp(20))
                col.addView(text("MeowTime only checks which app is open and for how long. Nothing leaves your phone.", 15f, MUTED).apply { gravity = Gravity.CENTER }, lp(8))
                col.addView(button(if (granted) "✅ Usage Access allowed" else "Allow Usage Access", !granted, TEAL) {
                    startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }, lp(20))
                col.addView(button(if (blocker) "✅ Blocker is on" else "Turn on blocker", !blocker, BLUE) {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, lp(12))
                col.addView(text("If the blocker switch is greyed out: open this app's App info, tap the three dots and choose Allow restricted settings.", 13f, MUTED).apply { gravity = Gravity.CENTER }, lp(14))
                col.addView(button("Let's go!", true, PURPLE) { prefs().edit().putBoolean("onboarded", true).apply(); tab = 0; show() }, lp(24))
            }
        }
        return col
    }

    // ---------- Home ----------
    private fun home(): LinearLayout {
        val granted = usageGranted(); val blocker = blockerOn()
        val mood = if (granted) Mood.current(this) else "happy"
        val col = page()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(text("⏳  MeowTime", 20f, INK, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        top.addView(pill("🔥 ${Streak.current(this)}", ORANGE))
        col.addView(top)
        col.addView(text(SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date()).uppercase(), 12f, MUTED, true, 0.12f), lp(22))
        val h = Mood.headline.getValue(mood)
        col.addView(text(span(h.first, h.second), 34f, INK, true), lp(6))
        col.addView(text(Mood.sub.getValue(mood), 15f, MUTED), lp(6))
        if (!granted || !blocker) col.addView(setupCard(granted, blocker), lp(18))
        val usage = if (granted) Limits.usedAll(this) else emptyMap()
        col.addView(streakCard(), lp(14))
        col.addView(screenTimeCard(usage, granted), lp(14))
        col.addView(pickupsCard(granted), lp(14))
        return col
    }

    private fun setupCard(granted: Boolean, blocker: Boolean): View {
        val c = card(tint(YELLOW, 0x40))
        c.addView(text("Finish setup", 18f, INK, true))
        c.addView(text("MeowTime needs two permissions. It only checks which app is open and for how long. Nothing leaves your phone.", 13f, INK), lp(6))
        if (!granted) c.addView(button("Allow Usage Access", true, TEAL) { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }, lp(14))
        if (!blocker) c.addView(button("Turn on blocker", true, BLUE) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, lp(10))
        return c
    }

    private fun streakCard(): View {
        val s = Streak.current(this); val best = Streak.best(this)
        val c = card(tint(ORANGE, 0x22))
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val flame = text("🔥", 30f)
        head.addView(flame)
        head.addView(text("  $s-day streak", 22f, INK, true))
        c.addView(head)
        val pulse = ObjectAnimator.ofPropertyValuesHolder(flame, PropertyValuesHolder.ofFloat("scaleX", 1f, 1.25f), PropertyValuesHolder.ofFloat("scaleY", 1f, 1.25f))
            .apply { duration = 700; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE }
        loops.add(pulse); pulse.start()
        c.addView(text("Best: $best ${if (best == 1) "day" else "days"}. A day counts when every app stays under its limit.", 13f, MUTED), lp(4))
        Streak.next(this)?.let { (badge, days) ->
            c.addView(text("🎁 $days more ${if (days == 1) "day" else "days"} to unlock ${badge.emoji} ${badge.name}", 14f, ORANGE, true), lp(10))
            c.addView(bar(best / badge.days.toFloat(), ORANGE), lp(8).apply { height = dp(8) })
        }
        return c
    }

    private fun screenTimeCard(usage: Map<String, Long>, granted: Boolean): View {
        val c = card()
        c.addView(text("TODAY ON TRACKED APPS", 11f, MUTED, true, 0.14f))
        fun totals(u: Map<String, Long>): Pair<Long, Long> {
            var used = 0L; var lim = 0L
            for ((_, pkg) in Limits.apps) { used += u[pkg] ?: 0L; lim += Limits.limitMin(this, pkg) }
            return used to lim
        }
        fun statusFor(u: Map<String, Long>): String {
            if (!granted) return ""
            val locked = Limits.apps.entries.filter { Limits.limitMin(this, it.value) > 0 && (u[it.value] ?: 0L) >= Limits.limitMin(this, it.value) }
            return if (locked.isNotEmpty()) "🔒 ${locked.joinToString { it.key }} locked" else "✅ Under every limit so far"
        }
        val (used0, lim0) = totals(usage)
        val f0 = if (lim0 > 0) used0 / lim0.toFloat() else 0f
        val ring = RingView(this).apply { color = barColor(f0); label = "0m"; sub = "of ${hm(lim0)}" }
        c.addView(ring, LinearLayout.LayoutParams(dp(180), dp(180)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(14) })
        ring.animateTo(f0)
        ValueAnimator.ofInt(0, used0.toInt()).apply {
            duration = 900; startDelay = 150
            addUpdateListener { ring.label = hm((it.animatedValue as Int).toLong()); ring.invalidate() }
        }.start()
        val status = text(statusFor(usage), 14f, GREEN, true).apply { gravity = Gravity.CENTER }
        c.addView(status, lp(8))
        if (!granted) c.addView(text("Allow Usage Access to see your real numbers.", 13f, MUTED).apply { gravity = Gravity.CENTER }, lp(6))
        val counts = HashMap<String, TextView>(); val bars = HashMap<String, View>()
        for ((name, pkg) in Limits.apps) {
            val u = usage[pkg] ?: 0L; val l = Limits.limitMin(this, pkg)
            val fr = if (l > 0) u / l.toFloat() else 0f
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            r.addView(View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(appColor(pkg)) } },
                LinearLayout.LayoutParams(dp(10), dp(10)).apply { rightMargin = dp(8) })
            r.addView(text(name, 14f, INK), LinearLayout.LayoutParams(0, WRAP, 1f))
            val ct = text("$u / $l min", 13f, if (l in 1..u.toInt()) RED else MUTED, true)
            r.addView(ct); counts[pkg] = ct
            c.addView(r, lp(16))
            val b = bar(fr, appColor(pkg)); bars[pkg] = b
            c.addView(b, lp(6).apply { height = dp(6) })
        }
        // live numbers: refresh every few seconds while this tab is open
        val tick = object : Runnable {
            override fun run() {
                try {
                    val u = Limits.usedAll(this@MainActivity)
                    val (us, lm) = totals(u); val f = if (lm > 0) us / lm.toFloat() else 0f
                    ring.color = barColor(f); ring.label = hm(us); ring.sub = "of ${hm(lm)}"; ring.animateTo(f, 600, 0)
                    status.text = statusFor(u)
                    for ((_, pkg) in Limits.apps) {
                        val x = u[pkg] ?: 0L; val l = Limits.limitMin(this@MainActivity, pkg)
                        counts[pkg]?.apply { text = "$x / $l min"; setTextColor(if (l in 1..x.toInt()) RED else MUTED) }
                        bars[pkg]?.let { setBar(it, if (l > 0) x / l.toFloat() else 0f, appColor(pkg)) }
                    }
                } catch (e: SecurityException) {}
                handler.postDelayed(this, 5000)
            }
        }
        if (granted) handler.postDelayed(tick, 5000)
        return c
    }

    // ---------- Limits ----------
    private fun limits(): LinearLayout {
        val granted = usageGranted()
        val usage = if (granted) Limits.usedAll(this) else emptyMap()
        val col = page()
        col.addView(text("App limits", 30f, INK, true))
        col.addView(text("Every app starts at 2 hours, the highest. Slide down to lower a limit right away. Sliding up only starts tomorrow. Once an app is locked you get one +15 min extension a day.", 14f, MUTED), lp(6))
        col.addView(bedtimeCard(), lp(14))
        for ((name, pkg) in Limits.apps) col.addView(limitCard(name, pkg, usage[pkg] ?: 0L), lp(14))
        return col
    }

    private fun bedtimeCard(): View {
        val c = card(tint(INDIGO, 0x55))
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(text("🌙 Bedtime lock", 18f, INK, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        val sw = Switch(this).apply { isChecked = Bedtime.enabled(this@MainActivity) }
        sw.setOnCheckedChangeListener { _, on ->
            if (on != Bedtime.enabled(this)) {
                if (Bedtime.active(this)) Toast.makeText(this, "Bedtime is active. You can turn it off after it ends.", Toast.LENGTH_LONG).show()
                else Bedtime.setEnabled(this, on)
                show()
            }
        }
        head.addView(sw)
        c.addView(head)
        c.addView(text("Locks all tracked apps overnight. While it is active you can't turn it off or change the times.", 13f, MUTED), lp(6))
        fun pick(label: String, minutes: Int, set: (Int) -> Unit): View = button("$label ${Bedtime.fmt(minutes)}", false, PURPLE) {
            if (Bedtime.active(this)) Toast.makeText(this, "Bedtime is active. Change it after it ends.", Toast.LENGTH_LONG).show()
            else TimePickerDialog(this, { _, h, m -> set(h * 60 + m); show() }, minutes / 60, minutes % 60, true).show()
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(pick("From", Bedtime.startMin(this)) { Bedtime.setStart(this, it) }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(8) })
        row.addView(pick("Until", Bedtime.endMin(this)) { Bedtime.setEnd(this, it) }, LinearLayout.LayoutParams(0, WRAP, 1f))
        c.addView(row, lp(14))
        if (Bedtime.enabled(this)) {
            val on = Bedtime.active(this)
            c.addView(text(if (on) "🌙 Active now, until ${Bedtime.fmt(Bedtime.endMin(this))}." else "Starts tonight at ${Bedtime.fmt(Bedtime.startMin(this))}.", 14f, if (on) GREEN else MUTED, true), lp(12))
        }
        return c
    }

    private fun limitCard(name: String, pkg: String, used: Long): View {
        val color = appColor(pkg)
        val c = card()
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(text(name.take(1), 16f, onColor(color), true).apply { gravity = Gravity.CENTER; background = bg(color, 12) },
            LinearLayout.LayoutParams(dp(36), dp(36)))
        head.addView(text(name, 17f, INK, true), LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(12) })
        val usedTv = text("", 14f, MUTED, true)
        head.addView(usedTv)
        c.addView(head)
        c.addView(studs(color), lp(10))
        val barHolder = FrameLayout(this)
        c.addView(barHolder, lp(10).apply { height = dp(10) })
        val statusTv = text("", 13f, RED, true)
        c.addView(statusTv, lp(10))
        val extBtn = button("+${Limits.EXTRA} min (once today)", true, color) {}
        c.addView(extBtn, lp(10))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(text("DAILY LIMIT", 11f, MUTED, true, 0.12f), LinearLayout.LayoutParams(0, WRAP, 1f))
        val valTv = text("", 22f, color, true)
        row.addView(valTv)
        c.addView(row, lp(16))
        val noteTv = text("", 13f, MUTED)

        fun refresh() {
            val lim = Limits.limitMin(this, pkg); val base = Limits.baseMin(this, pkg); val pend = Limits.pendingMin(this, pkg)
            val f = if (lim > 0) used / lim.toFloat() else 0f
            usedTv.text = "$used / $lim min"
            usedTv.setTextColor(if (f >= 1f) RED else MUTED)
            barHolder.removeAllViews()
            barHolder.addView(bar(f, barColor(f)), FrameLayout.LayoutParams(MATCH, MATCH))
            statusTv.text = when {
                f >= 1f -> "🔒 Limit reached. Resets in ${Limits.clock(Limits.millisUntilReset())}"
                Limits.extendedToday(this, pkg) -> "⏱ +${Limits.EXTRA} min extension used today."
                else -> ""
            }
            statusTv.visibility = if (statusTv.text.isEmpty()) View.GONE else View.VISIBLE
            extBtn.visibility = if (usageGranted() && Limits.canExtend(this, pkg)) View.VISIBLE else View.GONE
            valTv.text = "${pend ?: base}m"
            noteTv.text = if (pend != null) "Today: ${base}m · Tomorrow: ${pend}m" else "Applies today and every day until you change it."
        }
        extBtn.setOnClickListener {
            if (Limits.extend(this, pkg)) Toast.makeText(this, "+${Limits.EXTRA} minutes added for today.", Toast.LENGTH_SHORT).show()
            show()
        }

        val sb = SeekBar(this).apply {
            max = (Limits.MAX - 5) / 5
            progress = (((Limits.pendingMin(this@MainActivity, pkg) ?: Limits.baseMin(this@MainActivity, pkg)) - 5) / 5).coerceIn(0, max)
            progressTintList = ColorStateList.valueOf(color); thumbTintList = ColorStateList.valueOf(color)
            progressBackgroundTintList = ColorStateList.valueOf(LINE)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) valTv.text = "${5 + p * 5}m" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {
                    val want = 5 + (s?.progress ?: 0) * 5
                    val before = Limits.baseMin(this@MainActivity, pkg)
                    val msg = Limits.setLimit(this@MainActivity, pkg, want)
                    if (want > before) Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show()
                    refresh()
                }
            })
        }
        c.addView(sb, lp(6))
        c.addView(noteTv, lp(4))
        refresh()
        // while locked, the reset countdown ticks every second
        val lockTick = object : Runnable {
            override fun run() {
                if (statusTv.text.startsWith("🔒")) {
                    statusTv.text = "🔒 Limit reached. Resets in ${Limits.clock(Limits.millisUntilReset())}"
                    handler.postDelayed(this, 1000)
                }
            }
        }
        handler.postDelayed(lockTick, 1000)
        return c
    }

    // ---------- Focus ----------
    private fun fmt(ms: Long): String { val t = ms / 1000; return "%02d:%02d".format(t / 60, t % 60) }

    private fun focus(): LinearLayout {
        Focus.finishIfDone(this)
        val active = Focus.active(this)
        val col = page()
        col.addView(text("Focus mode", 30f, INK, true))
        col.addView(text("Silence notifications and pause your distracting apps while you study.", 14f, MUTED), lp(6))
        val c = card(tint(TEAL, 0x1C))
        c.addView(studs(TEAL))
        val planned = if (active) Focus.plannedMs(this) else focusMin * 60_000L
        val rem0 = if (active) Focus.remainingMs(this) else planned
        val ring = RingView(this).apply {
            color = TEAL; label = fmt(rem0); sub = if (active) "remaining" else "ready"
            frac = if (active) 1f - rem0 / planned.toFloat() else 0f
        }
        c.addView(ring, LinearLayout.LayoutParams(dp(220), dp(220)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(12) })
        if (active) {
            // a slow "breathing" pulse while you focus
            val breathe = ObjectAnimator.ofPropertyValuesHolder(ring, PropertyValuesHolder.ofFloat("scaleX", 1f, 1.05f), PropertyValuesHolder.ofFloat("scaleY", 1f, 1.05f))
                .apply { duration = 2000; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE }
            loops.add(breathe); breathe.start()
        }
        if (!active) {
            val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (m in listOf(25, 45, 60)) chips.addView(button("$m min", focusMin == m, TEAL) { focusMin = m; show() },
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(8) })
            chips.addView(button("Custom", focusMin !in listOf(25, 45, 60), TEAL) { customFocus() }, LinearLayout.LayoutParams(0, WRAP, 1f))
            c.addView(chips, lp(18))
            c.addView(button("Start focus", true, PURPLE) { Focus.start(this, focusMin); show() }, lp(14))
        } else {
            c.addView(button("Stop session", false, RED) { Focus.cancel(this); show() }, lp(18))
            val tick = object : Runnable {
                override fun run() {
                    if (tab != 2) return
                    if (Focus.finishIfDone(this@MainActivity)) {
                        Toast.makeText(this@MainActivity, "Session complete! 🎉", Toast.LENGTH_LONG).show()
                        show(); return
                    }
                    val rem = Focus.remainingMs(this@MainActivity)
                    ring.label = fmt(rem)
                    ring.frac = 1f - rem / Focus.plannedMs(this@MainActivity).toFloat()
                    ring.invalidate()
                    handler.postDelayed(this, 500)
                }
            }
            handler.post(tick)
        }
        col.addView(c, lp(18))

        val info = card()
        if (Focus.dndAllowed(this)) {
            info.addView(text("🔕 Do Not Disturb turns on during focus and goes back to how it was afterwards.", 14f, INK))
        } else {
            info.addView(text("Allow Do Not Disturb access so MeowTime can silence notifications while you study.", 14f, INK))
            info.addView(button("Allow Do Not Disturb", false, TEAL) { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }, lp(12).apply { width = WRAP })
        }
        info.addView(text("📵 Your tracked apps are paused until the session ends.", 14f, INK), lp(12))
        col.addView(info, lp(14))
        return col
    }

    private fun customFocus() {
        val input = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(focusMin.toString()) }
        AlertDialog.Builder(this).setTitle("Focus minutes (5 to 180)").setView(input)
            .setPositiveButton("OK") { _, _ -> focusMin = (input.text.toString().toIntOrNull() ?: 25).coerceIn(5, 180); show() }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------- Insights ----------
    private fun statCard(label: String, value: String, color: Int): View = card(tint(color, 0x1E)).apply {
        setPadding(dp(16), dp(16), dp(16), dp(16))
        addView(text(label.uppercase(), 11f, color, true, 0.12f)); addView(text(value, 24f, INK, true), lp(6))
    }

    private fun insights(): LinearLayout {
        val granted = usageGranted()
        val days = if (granted) Limits.dayTotals(this) else List(7) { 0L }
        val col = page()
        col.addView(text("Insights", 30f, INK, true))
        col.addView(text(if (granted) "Your last 7 days on tracked apps. Tap a bar for details." else "Allow Usage Access on the Home tab to see your real numbers.", 14f, MUTED), lp(6))
        val c = card()
        c.addView(text("MINUTES PER DAY", 11f, MUTED, true, 0.14f))
        val detail = text("Tap a bar", 16f, PURPLE, true)
        c.addView(detail, lp(8))
        val top = (days.maxOrNull() ?: 0L).coerceAtLeast(60L)
        val chart = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        val palette = intArrayOf(BLUE, PURPLE, TEAL, ORANGE, PINK, YELLOW, GREEN)
        val cols = mutableListOf<LinearLayout>()
        days.forEachIndexed { i, m ->
            val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -(6 - i)) }
            val dayName = SimpleDateFormat("EEE", Locale.getDefault()).format(cal.time)
            val bcol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            bcol.addView(text(hm(m), 10f, MUTED))
            val barV = View(this).apply { background = bg(palette[i % palette.size], 10) }
            bcol.addView(barV, LinearLayout.LayoutParams(dp(26), 0))
            bcol.addView(text(dayName, 11f, if (i == 6) INK else MUTED, i == 6), lp(4))
            bcol.setOnClickListener {
                detail.text = "$dayName: ${hm(m)}" + if (i == 6) " (today)" else ""
                cols.forEachIndexed { k, v -> v.animate().alpha(if (k == i) 1f else 0.35f).setDuration(200).start() }
                bcol.animate().scaleX(1.12f).scaleY(1.04f).setDuration(120).withEndAction { bcol.animate().scaleX(1f).scaleY(1f).setDuration(160).start() }.start()
            }
            cols.add(bcol)
            chart.addView(bcol, LinearLayout.LayoutParams(0, WRAP, 1f))
            ValueAnimator.ofInt(0, maxOf(dp(4), (dp(140) * m / top).toInt())).apply {
                duration = 700; startDelay = 200L + i * 60
                addUpdateListener { barV.layoutParams.height = it.animatedValue as Int; barV.requestLayout() }
            }.start()
        }
        c.addView(chart, lp(14))
        col.addView(c, lp(18))
        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r1.addView(statCard("Today", hm(days.last()), BLUE), LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(7) })
        r1.addView(statCard("7-day average", hm(days.sum() / 7), TEAL), LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(7) })
        col.addView(r1, lp(14))
        val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r2.addView(statCard("Focus sessions", "${Focus.sessions(this)}", ORANGE), LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(7) })
        r2.addView(statCard("Study time", hm(Focus.minutes(this).toLong()), PINK), LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(7) })
        col.addView(r2, lp(14))

        // today by app
        val today = if (granted) Limits.usedAll(this) else emptyMap()
        val byApp = card()
        byApp.addView(text("TODAY BY APP", 11f, MUTED, true, 0.14f))
        val maxApp = (today.values.maxOrNull() ?: 0L).coerceAtLeast(1L)
        for ((name, pkg) in Limits.apps) {
            val u = today[pkg] ?: 0L
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(text(name, 14f, INK), LinearLayout.LayoutParams(0, WRAP, 1f))
            row.addView(text(hm(u), 14f, appColor(pkg), true))
            byApp.addView(row, lp(14))
            byApp.addView(bar(u / maxApp.toFloat(), appColor(pkg)), lp(6).apply { height = dp(8) })
        }
        col.addView(byApp, lp(14))
        col.addView(pickupsChart(granted), lp(14))
        return col
    }

    // ---------- Phone pickups ----------
    private fun pickupsCard(granted: Boolean): View {
        val c = card()
        c.addView(text("PHONE PICKUPS TODAY", 11f, MUTED, true, 0.14f))
        val n = if (granted) Pickups.today(this) else 0
        val big = text("0", 44f, PINK, true)
        c.addView(big, lp(10))
        ValueAnimator.ofInt(0, n).apply {
            duration = 900; startDelay = 200
            addUpdateListener { big.text = "${it.animatedValue}" }
        }.start()
        c.addView(text(if (n == 1) "time you picked up your phone" else "times you picked up your phone", 14f, MUTED), lp(2))
        if (!granted) c.addView(text("Allow Usage Access to count pickups.", 13f, MUTED), lp(8))
        return c
    }

    private fun pickupsChart(granted: Boolean): View {
        val vals: List<Int> = if (granted) Pickups.daily(this) else List(7) { 0 }
        val c = card()
        c.addView(text("PHONE PICKUPS PER DAY", 11f, MUTED, true, 0.14f))
        val detail = text("Today: ${vals.last()} · 7-day average: ${vals.sum() / 7}", 15f, PINK, true)
        c.addView(detail, lp(8))
        val top = (vals.maxOrNull() ?: 0).coerceAtLeast(10)
        val chart = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        val cols = mutableListOf<LinearLayout>()
        vals.forEachIndexed { i, n ->
            val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -(6 - i)) }
            val dayName = SimpleDateFormat("EEE", Locale.getDefault()).format(cal.time)
            val bcol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            bcol.addView(text("$n", 10f, MUTED))
            val barV = View(this).apply { background = bg(PINK, 10) }
            bcol.addView(barV, LinearLayout.LayoutParams(dp(26), 0))
            bcol.addView(text(dayName, 11f, if (i == 6) INK else MUTED, i == 6), lp(4))
            bcol.setOnClickListener {
                detail.text = "$dayName: $n pickups"
                cols.forEachIndexed { k, v -> v.animate().alpha(if (k == i) 1f else 0.35f).setDuration(200).start() }
            }
            cols.add(bcol)
            chart.addView(bcol, LinearLayout.LayoutParams(0, WRAP, 1f))
            ValueAnimator.ofInt(0, maxOf(dp(4), dp(110) * n / top)).apply {
                duration = 700; startDelay = 200L + i * 60
                addUpdateListener { barV.layoutParams.height = it.animatedValue as Int; barV.requestLayout() }
            }.start()
        }
        c.addView(chart, lp(14))
        return c
    }

    // ---------- Rewards: outfits, streak unlocks and the weekly goal ----------
    private fun rewards(): LinearLayout {
        val col = page()
        col.addView(text("Rewards", 30f, INK, true))
        col.addView(text("Stay under every limit to grow your streak and unlock badges.", 14f, MUTED), lp(6))
        val best = Streak.best(this)
        val cur = Badges.current(best)
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = gradient(NAVY, INDIGO, 28); setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        c.addView(studs(YELLOW))
        val big = text(cur?.emoji ?: "🎯", 72f).apply { gravity = Gravity.CENTER }
        c.addView(big, lp(8))
        big.scaleX = 0f; big.scaleY = 0f
        big.animate().scaleX(1f).scaleY(1f).setStartDelay(250).setDuration(600).setInterpolator(OvershootInterpolator(2.5f)).start()
        c.addView(text(cur?.name ?: "No badge yet", 20f, YELLOW, true).apply { gravity = Gravity.CENTER }, lp(2))
        c.addView(text("Best streak: $best ${if (best == 1) "day" else "days"}", 13f, Color.parseColor("#B9B4FF")).apply { gravity = Gravity.CENTER }, lp(2))
        Badges.nextAfter(best)?.let { nx ->
            c.addView(text("Next: ${nx.emoji} ${nx.name} at ${nx.days} days", 13f, Color.WHITE).apply { gravity = Gravity.CENTER }, lp(14))
            c.addView(bar(best / nx.days.toFloat(), YELLOW, Color.parseColor("#2C2F86")), lp(8).apply { height = dp(10) })
        }
        col.addView(c, lp(18))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        Badges.all.forEachIndexed { i, b ->
            val open = best >= b.days
            val t = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = bg(if (open) tint(YELLOW, 0x22) else SURF, 20, if (open) YELLOW else LINE, if (open) 2 else 1)
            }
            val em = text(b.emoji, 36f).apply { alpha = if (open) 1f else 0.25f }
            t.addView(em)
            t.addView(text(b.name, 12f, INK, true), lp(6))
            t.addView(text(if (open) "Unlocked" else "🔒 ${b.days} days", 11f, if (open) GREEN else MUTED, open))
            t.setOnClickListener {
                if (open) {
                    em.animate().scaleX(1.4f).scaleY(1.4f).rotation(12f).setDuration(160).withEndAction {
                        em.animate().scaleX(1f).scaleY(1f).rotation(0f).setDuration(260).setInterpolator(OvershootInterpolator(3f)).start()
                    }.start()
                } else Toast.makeText(this, "Reach a ${b.days}-day streak to unlock ${b.name}.", Toast.LENGTH_SHORT).show()
            }
            t.alpha = 0f; t.translationX = dp(30).toFloat()
            t.animate().alpha(1f).translationX(0f).setStartDelay(300L + i * 80).setDuration(350).start()
            row.addView(t, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(10) })
        }
        col.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }, lp(16))
        col.addView(goalCard(), lp(16))
        return col
    }

    private fun goalCard(): View {
        val granted = usageGranted()
        val pkg = Goal.pkg(this); val target = Goal.target(this)
        val appName = Limits.apps.entries.first { it.value == pkg }.key
        val met = if (granted) Goal.daysMet(this) else 0
        val done = met >= Goal.NEED
        val c = card()
        c.addView(text("WEEKLY GOAL", 11f, MUTED, true, 0.14f))
        c.addView(text("$appName under ${hm(target.toLong())} a day", 18f, INK, true), lp(6))
        c.addView(text("Do it on ${Goal.NEED} of the last 7 days.", 13f, MUTED), lp(2))
        val ring = RingView(this).apply {
            color = if (done) GREEN else appColor(pkg)
            label = "$met/${Goal.NEED}"; sub = "days"
        }
        ring.animateTo((met / Goal.NEED.toFloat()).coerceAtMost(1f))
        c.addView(ring, LinearLayout.LayoutParams(dp(130), dp(130)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(12) })
        if (done) c.addView(text("🎉 Goal reached this week!", 15f, GREEN, true).apply { gravity = Gravity.CENTER }, lp(8))
        if (!granted) c.addView(text("Allow Usage Access on the Home tab to track this.", 13f, MUTED).apply { gravity = Gravity.CENTER }, lp(8))

        c.addView(text("APP", 11f, MUTED, true, 0.12f), lp(16))
        val apps = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((n, p) in Limits.apps) apps.addView(button(n, p == pkg, appColor(p)) { Goal.set(this, p, target); show() },
            LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
        c.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(apps) }, lp(8))

        c.addView(text("DAILY TARGET", 11f, MUTED, true, 0.12f), lp(16))
        val mins = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (m in listOf(30, 60, 90)) mins.addView(button(hm(m.toLong()), m == target, PURPLE) { Goal.set(this, pkg, m); show() },
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(8) })
        c.addView(mins, lp(8))
        return c
    }
}
