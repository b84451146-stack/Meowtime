package com.meowtime.app

import android.content.Context
import kotlin.math.min

/** The cat's mood, worked out from today's real usage unless an event (like a focus session) sets one. */
object Mood {
    val all = listOf("happy", "excited", "worried", "sleepy", "sad", "proud", "study")
    val say = mapOf(
        "happy" to "Nice balance today! ✅", "excited" to "Study done! Let's celebrate! 🎉",
        "worried" to "A limit is close… ⚠️", "sleepy" to "So much scrolling… 💤",
        "sad" to "Rough day? Tomorrow is fresh. 💤", "proud" to "Goal reached! 🎉", "study" to "Shh… reading time 📚"
    )
    val headline = mapOf(
        "happy" to Pair("Your day, ", "in balance."), "excited" to Pair("Great job, ", "celebrate!"),
        "worried" to Pair("Careful, ", "a limit is close."), "sleepy" to Pair("A lot of ", "scrolling today."),
        "sad" to Pair("Time for ", "a break."), "proud" to Pair("Goal ", "reached!"), "study" to Pair("Deep ", "focus time.")
    )
    val sub = mapOf(
        "happy" to "A little less scrolling. A little more living.", "excited" to "Study session done. Well earned!",
        "worried" to "One of your apps is almost out of time.", "sleepy" to "Your eyes deserve a rest.",
        "sad" to "A limit was hit. Tomorrow is a fresh start.", "proud" to "You hit your daily goal.", "study" to "Notifications off. You've got this."
    )
    val title = mapOf(
        "happy" to "Feeling great", "excited" to "Celebrating", "worried" to "A bit worried", "sleepy" to "Sleepy",
        "sad" to "Needs a break", "proud" to "Proud of you", "study" to "Studying"
    )
    val line = mapOf(
        "happy" to "You are staying in balance. Keep it up!", "excited" to "You did it! Time to celebrate.",
        "worried" to "You are close to a limit. Take it easy.", "sleepy" to "Let's rest our eyes and do something offline.",
        "sad" to "That's okay. Let's do better tomorrow.", "proud" to "Goal reached. I'm so proud!", "study" to "Shh… reading time."
    )

    private fun prefs(c: Context) = c.getSharedPreferences("meowtime", Context.MODE_PRIVATE)

    fun override(c: Context, mood: String, ms: Long) =
        prefs(c).edit().putString("mood_o", mood).putLong("mood_until", System.currentTimeMillis() + ms).apply()
    fun clear(c: Context) = prefs(c).edit().putLong("mood_until", 0).apply()

    fun current(c: Context): String {
        val p = prefs(c)
        if (System.currentTimeMillis() < p.getLong("mood_until", 0)) return p.getString("mood_o", "happy")!!
        return try {
            val u = Limits.usedAll(c)
            var total = 0L; var near = false
            for (pkg in Limits.apps.values) {
                val used = u[pkg] ?: 0L; val lim = Limits.limitMin(c, pkg)
                total += used
                if (lim > 0 && used >= lim) return "sad"
                if (lim > 0 && used >= lim * 0.8) near = true
            }
            if (near) "worried" else if (total >= 90) "sleepy" else "happy"
        } catch (e: SecurityException) { "happy" }   // Usage Access not granted yet
    }

    /** 10..100, from how much of each daily limit has been used. */
    fun happiness(c: Context): Int = try {
        val u = Limits.usedAll(c)
        val r = Limits.apps.values.map { val l = Limits.limitMin(c, it); if (l > 0) min(1.0, (u[it] ?: 0L).toDouble() / l) else 0.0 }
        (100 - r.average() * 60 - (if (r.any { it >= 1.0 }) 20 else 0)).toInt().coerceIn(10, 100)
    } catch (e: SecurityException) { 75 }
}
