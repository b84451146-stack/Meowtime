# OFFGRID (Android)

A student screen-time app. It keeps the student in control while making automatic phone habits visible.

## What it does

**Limits**
- Every app starts at **3 hours/day** and can't go higher, YouTube included (apps you add too). To give YouTube 5 hours,
  set `YOUTUBE_MAX = 300` in `Limits.kt`.
- **+ Add app** (Limits tab): pick any installed app to track and limit. Added apps can be removed again
  (not while they are locked today, so a limit can't be dodged). The 5 built-in apps stay.
- Lowering a limit works at once; raising it starts tomorrow.

**Pause instead of a wall**
- **Open it?** When a tracked app is opened, OFFGRID waits 10 seconds ("Open Instagram?") and offers a quick
  optional launch pause has been removed; tracked apps open immediately unless a real app limit, Focus mode or Bedtime lock blocks them.
  Can be switched off on the Limits tab. (Not shown for YouTube while a study session is running.)
- **Continue?** At the limit the app is covered by a "You've hit your limit. Continue?" screen. Continuing
  (once per app per day, +15 min) needs a 10-second wait and a reason. Reasons are counted on the Insights tab.
- Insights also shows how many pauses ended in "Not now".

**Study tab (YouTube)**
- Start a **study session** with a subject and topic.
- While YouTube is in front, OFFGRID reads the **title and hashtags** shown on screen and
  labels the time **Educational / Entertainment / Mixed / Unknown** with an **offline keyword matcher**
  (no internet, no API key). If no title can be read, the label is **Unknown**. It never guesses.
- **Reminders** after about 90 s of entertainment during a session, with "It's study-related" and "Dismiss".
- **Correct** any label from the Study tab ("Study-related" / "Not study"); corrections are remembered.
- **Dashboard**: study time, sessions, focus score, time per label, daily goal.
- **Controls**: turn detection off, or pause it for 30 minutes.
- **Verification**: after a session, an optional one-sentence note about what you learned.
- **Privacy**: no audio, no screenshots, nothing leaves the phone. A privacy screen explains each permission,
  and the first session asks for a one-time "I understand".

Other features from before are unchanged: Focus mode, bedtime lock, phone pickups, streaks and badges, weekly goal,
break reminders, 9 pm summary, Sunday weekly report.

## After the YouTube limit: study videos only
When YouTube's daily limit is used up, YouTube is not simply closed. OFFGRID looks at what is on screen:

| Screen | What happens |
|---|---|
| **Shorts** | Always blocked (sent to the break screen). |
| **Home / search** | Allowed, so you can look for a lecture (`ALLOW_BROWSING` in `BlockerService.kt`). |
| **A video page** | Allowed only if the title reads **Educational with confidence 65 or more** (two study words, or a match with your topic). Entertainment, Mixed, Unknown and unreadable titles are blocked. |
| **Fullscreen video** | The title is hidden, so the last Educational result is kept for **5 minutes**. At **4 minutes** a notification says "Exit fullscreen to keep watching". Exiting fullscreen reads the title again and restarts the 5 minutes. |

- A hashtag on its own never counts: a title must be found.
- Marking a video "Study-related" on the Study tab does **not** unlock YouTube after the limit. Marking one "Not study" does block it.
- Focus mode and Bedtime still block YouTube completely, and the +15 min extension is never offered for YouTube.
- The numbers (`MIN_CONFIDENCE`, `STICKY_MS`, `WARN_AFTER_MS`, `OPEN_GRACE_MS`) are at the top of `BlockerService.kt`.
- Needs the one-time "I understand" (Study tab > Start study session) and detection switched on and not paused.
  Without that, YouTube is fully blocked after its limit.

### Check the view ids before you rely on it
`YouTubeReader.kt` finds the screen type by view ids, and the ids in this version are **unverified guesses**.
On your phone: Study tab > "What MeowTime read" while (a) a lecture plays, (b) a Short plays, (c) YouTube's home
screen is open. The **Page** and **Ids** lines show what was seen. Put ids that appear only on that kind of screen into
`SHORTS_IDS`, `WATCH_IDS` and `BROWSE_IDS`. Until they are right the safe result is "unknown screen", which is
blocked after the limit (set `ALLOW_BROWSING = false` to make that explicit).

## Edit the keywords
`app/src/main/java/com/meowtime/app/Keywords.kt` holds all word lists (study words, entertainment words and hashtags).
Add words that are specific to your school and rebuild. Plural "s" is ignored automatically.

## Build
Push this folder to GitHub; the workflow builds `app-debug.apk` (artifact "MeowTime-apk").
After install: allow restricted settings (App info > three dots), turn on Usage Access, turn on the OFFGRID
blocker in Accessibility, allow notifications.

Note: the new accessibility settings (reading YouTube's on-screen text) mean Android asks you to re-confirm
the Accessibility permission after updating over an older build.

## Honest limits
- YouTube does not promise what its screens contain, and a YouTube update can change view ids and what is visible.
  When the title can't be read, the result is Unknown (blocked after the limit).
- A video playing in YouTube's small floating player while you browse is not checked.
- The browser (m.youtube.com), YouTube Music and modified YouTube apps are not tracked.
- The title is found by its view id (`YouTubeReader.TITLE_IDS`). If titles are never found on your phone, run a study
  session, play a video, open **Study > See what OFFGRID just read**, and add the id shown next to the title.
- No transcripts, audio or video content can be read; Android does not allow it.
- The matcher is English-only and keyword based. Vague titles come out as Unknown or Mixed.
- Written without an Android SDK, so expect to fix small build errors.
- Google restricts Accessibility use on the Play Store; this suits a school project or a sideloaded APK.
