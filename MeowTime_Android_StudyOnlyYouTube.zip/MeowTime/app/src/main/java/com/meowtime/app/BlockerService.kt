package com.meowtime.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.accessibility.AccessibilityEvent
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Android does not let an app force-close another app. Instead, when a limited app comes to the
 * front, this service sends the user to the home screen and opens OFFGRID's break screen.
 * When a tracked app is opened (and isn't blocked) it first shows a short "Open Instagram?" pause.
 * While YouTube is open (after the student's one-time OK) it also reads the screen type, title and hashtags that YouTube shows.
 * After the YouTube limit only study videos may continue: Shorts are blocked, browsing is allowed, and a video page must read as EDUCATIONAL.
 * It also runs the small background jobs: 80% warnings, the streak check, break reminders and the 9 pm summary.
 */
class BlockerService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var current: String? = null
    private var contPkg: String? = null      // tracked app the user has been in without leaving
    private var contSince = 0L
    private var lastRead = 0L                // when YouTube's screen text was last read (throttle)
    private var lastTick = 0L                // when YouTube study time was last counted
    private var lastPauseAt = 0L             // so a late event from the app can't restart the pause
    private var entSeconds = 0               // continuous seconds on entertainment during a study session
    private var lastEnforce = 0L             // throttle for checking YouTube after screen changes
    private var youTubeOpenedAt = 0L         // when YouTube last came to the front (short grace while its screen loads)
    private var lastEduAt = 0L               // last moment a readable EDUCATIONAL video page was confirmed
    private var hiddenWarned = false         // the "exit fullscreen" warning was already shown for this stretch

    companion object {
        /** After the YouTube limit, home/search screens stay usable; Shorts and non-study video pages are blocked.
         *  Set to false to block every YouTube screen after the limit (the safe fallback while the view ids in
         *  YouTubeReader are unverified). */
        const val ALLOW_BROWSING = true
        /** Minimum classifier confidence for a video to count as study content after the limit (65 = two study words or a topic match). */
        const val MIN_CONFIDENCE = 65
        /** A fullscreen video hides its title: the last EDUCATIONAL result is kept this long. */
        const val STICKY_MS = 5 * 60_000L
        /** ...and a warning ("exit fullscreen") is shown after this long. */
        const val WARN_AFTER_MS = 4 * 60_000L
        /** YouTube may show an unreadable screen this long right after it opens, while it loads. */
        const val OPEN_GRACE_MS = 5_000L
    }

    private val poll = object : Runnable {
        override fun run() {
            // Catches the moment a limit is reached while the app is already open.
            current?.let { enforce(it) }
            Focus.finishIfDone(this@BlockerService)
            try {
                val usage = Limits.usedAll(this@BlockerService)
                Notifier.checkWarnings(this@BlockerService, usage)
                Streak.update(this@BlockerService)
                dailySummary(usage)
                dailyQuote()
                weeklyReport()
            } catch (e: SecurityException) {}
            breakCheck()
            studyTick()
            handler.postDelayed(this, 10_000)
        }
    }

    override fun onServiceConnected() { handler.post(poll) }
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); super.onDestroy() }
    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val pkg = event.packageName?.toString() ?: return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            if (pkg == Limits.YOUTUBE && contPkg == pkg) {   // the screen changed inside YouTube
                readYouTube()
                val now = System.currentTimeMillis()
                if (now - lastEnforce >= 2000) { lastEnforce = now; enforce(pkg) }
            }
            return
        }
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        current = pkg
        val tracked = Limits.tracked(this)
        val fresh = pkg in tracked && contPkg != pkg          // the app was just opened (not just a new screen inside it)
        if (pkg in tracked) {
            if (contPkg != pkg) {
                contPkg = pkg; contSince = System.currentTimeMillis()
                if (pkg == Limits.YOUTUBE) youTubeOpenedAt = contSince
            }
        } else if (!pkg.contains("inputmethod") && !pkg.contains("keyboard") && pkg != "com.android.systemui") {
            if (contPkg == Limits.YOUTUBE) { Study.Last.clear(); entSeconds = 0; clearSticky() }
            contPkg = null   // the user left for something else
        }
        if (enforce(pkg)) return
        // Do not interrupt app launches with the optional breathing/stretch/puzzle pause screen.
        if (pkg == Limits.YOUTUBE) readYouTube()
    }

    /** Reads YouTube's screen (type, title, hashtags) for post-limit decisions and study tracking.
     *  Needs the one-time consent, and respects the Study tab's off / pause switch. */
    private fun readYouTube(force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (!force && now - lastRead < 2000) return
        lastRead = now
        fun unreadable(why: String) {
            Study.Last.title = null; Study.Last.hashtags = emptyList(); Study.Last.at = now
            Study.Last.page = YouTubeReader.Page.UNKNOWN
            Study.Last.result = Classifier.Result(Classifier.Label.UNKNOWN, 0, why)
        }
        if (!Study.consented(this) || !Study.enabled(this) || Study.paused(this)) { unreadable("YouTube reading is off."); return }
        val root = try { rootInActiveWindow } catch (e: Exception) { null }
        if (root == null || root.packageName?.toString() != Limits.YOUTUBE) { unreadable("YouTube title is not readable."); return }
        val r = try { YouTubeReader.read(root) } catch (e: Exception) { unreadable("YouTube title could not be read."); return }
        Study.Last.title = r.title; Study.Last.hashtags = r.hashtags; Study.Last.at = now; Study.Last.page = r.page
        val inSession = Study.active(this)
        val correction = Study.correctionFor(this, r.title)
        Study.Last.result = when {
            r.page == YouTubeReader.Page.SHORTS -> Classifier.Result(Classifier.Label.UNKNOWN, 0, "Shorts are never counted as study videos.")
            correction != null -> Classifier.Result(correction, 100, "You marked this one yourself.")
            else -> Classifier.classify(r.title, r.hashtags,
                if (inSession) Study.subject(this) else "", if (inSession) Study.topic(this) else "")
        }
    }

    /** Every 10 s: file YouTube time under the current label and send a gentle reminder if it looks like entertainment. */
    private fun studyTick() {
        Study.finishIfStale(this)
        val now = System.currentTimeMillis()
        val delta = if (lastTick == 0L) 0 else ((now - lastTick) / 1000).toInt().coerceIn(0, 15)
        lastTick = now
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!Study.detecting(this) || contPkg != Limits.YOUTUBE || !pm.isInteractive) { entSeconds = 0; return }
        readYouTube()   // keep the label fresh even if YouTube sent no screen-change event
        val res = Study.Last.result
        val label = res?.label ?: Classifier.Label.UNKNOWN
        Study.addSeconds(this, label, delta)
        if (label == Classifier.Label.ENTERTAINMENT) entSeconds += delta else entSeconds = 0
        if (entSeconds >= 90 && Study.canRemind(this)) {
            Study.markReminded(this)
            val title = Study.Last.title?.take(60)?.let { "\"$it\" " } ?: ""
            Notifier.postWithActions(this, Notifier.ID_STUDY, "Studying ${Study.topic(this).ifBlank { Study.subject(this).ifBlank { "now" } }}?",
                "This ${title}looks like entertainment. Keep going or switch back when you're ready.",
                listOf("It's study-related" to ReminderReceiver.ACTION_FIX, "Dismiss" to ReminderReceiver.ACTION_DISMISS))
        }
    }

    /** After 20 minutes in one tracked app without leaving, suggest a break (and again every 20 minutes). */
    private fun breakCheck() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) { contPkg = null; return }
        val pkg = contPkg ?: return
        if (System.currentTimeMillis() - contSince >= 20 * 60_000L) {
            contSince = System.currentTimeMillis()
            val name = Limits.nameOf(this, pkg)
            Notifier.post(this, 4242, "Time for a break ⚠️", "You've been on $name for 20 minutes straight. Look away, stretch and drink some water.", "sleepy")
        }
    }

    /** One notification after 9 pm with the day's total and the streak. */
    private fun dailySummary(usage: Map<String, Long>) {
        if (Calendar.getInstance().get(Calendar.HOUR_OF_DAY) < 21) return
        val p = getSharedPreferences("meowtime", MODE_PRIVATE)
        if (p.getInt("sum_day", 0) == Limits.day()) return
        p.edit().putInt("sum_day", Limits.day()).apply()
        val over = Limits.tracked(this).any { (usage[it] ?: 0L) >= Limits.limitMin(this, it) }
        val s = Streak.current(this)
        Notifier.post(this, 99, if (over) "Rough day 💤" else "Nice day! ✅",
            "Today: ${Limits.hm(usage.values.sum())} on tracked apps." + if (s > 0) " 🔥 $s-day streak so far." else "",
            if (over) "sad" else "proud")
    }

    /** Sunday evening (7 pm on): this week's total, best day and phone pickups. */
    private fun weeklyReport() {
        val cal = Calendar.getInstance()
        if (cal.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY || cal.get(Calendar.HOUR_OF_DAY) < 19) return
        val p = getSharedPreferences("meowtime", MODE_PRIVATE)
        if (p.getInt("report_day", 0) == Limits.day()) return
        val totals = Limits.dayTotals(this)
        val best = totals.indices.minByOrNull { totals[it] } ?: 6
        val bestCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -(6 - best)) }
        val bestName = SimpleDateFormat("EEEE", Locale.getDefault()).format(bestCal.time)
        val pickups = Pickups.daily(this).sum()
        p.edit().putInt("report_day", Limits.day()).apply()
        Notifier.post(this, 77, "Your week in review 📊",
            "This week: ${Limits.hm(totals.sum())} on tracked apps (about ${Limits.hm(totals.sum() / 7)} a day). " +
            "Best day: $bestName with ${Limits.hm(totals[best])}. Phone pickups: $pickups. 🔥 Streak: ${Streak.current(this)}.", "")
    }

    /** One motivational quote a day, from 7 am. */
    private fun dailyQuote() {
        if (Calendar.getInstance().get(Calendar.HOUR_OF_DAY) < 7) return
        val p = getSharedPreferences("meowtime", MODE_PRIVATE)
        if (p.getInt("quote_day", 0) == Limits.day()) return
        p.edit().putInt("quote_day", Limits.day()).apply()
        Notifier.post(this, 88, "Today's motivation 💪", Quotes.today(), "")
    }

    private fun clearSticky() { lastEduAt = 0L; hiddenWarned = false }

    /** The label used for the post-limit decision. Marking a video "study-related" never unlocks YouTube
     *  (that would be too easy to abuse); marking one "not study" does block it. */
    private fun gateLabel(): Pair<Classifier.Label, Int> {
        val title = Study.Last.title
        val inSession = Study.active(this)
        val auto = Classifier.classify(title, Study.Last.hashtags,
            if (inSession) Study.subject(this) else "", if (inSession) Study.topic(this) else "")
        val marked = Study.correctionFor(this, title)
        return if (marked != null && marked != Classifier.Label.EDUCATIONAL) Pair(marked, 100) else Pair(auto.label, auto.confidence)
    }

    /** After the YouTube limit: may YouTube stay open right now? */
    private fun youTubeAllowed(): Boolean {
        readYouTube()
        val now = System.currentTimeMillis()
        val page = Study.Last.page
        if (page == YouTubeReader.Page.SHORTS) { clearSticky(); return false }
        if (page == YouTubeReader.Page.BROWSE && ALLOW_BROWSING) { clearSticky(); return true }
        if (Study.Last.title != null) {
            val (label, conf) = gateLabel()
            if (label == Classifier.Label.EDUCATIONAL && conf >= MIN_CONFIDENCE) {
                lastEduAt = now; hiddenWarned = false
                return true
            }
            clearSticky(); return false
        }
        // No readable title: YouTube is still loading, or a fullscreen video hides it.
        if (now - youTubeOpenedAt <= OPEN_GRACE_MS) return true
        val age = now - lastEduAt
        if (lastEduAt == 0L || age > STICKY_MS) { clearSticky(); return false }
        if (age >= WARN_AFTER_MS && !hiddenWarned) {
            hiddenWarned = true
            Notifier.post(this, 4343, "Keep watching? 📘", "Exit fullscreen to keep watching. OFFGRID can't see the video title in fullscreen, and will pause YouTube soon.", "")
        }
        return true
    }

    /** Covers a tracked app that is out of time (or paused by Focus / Bedtime). Returns true when it blocked. */
    private fun enforce(pkg: String): Boolean {
        if (pkg == packageName || pkg !in Limits.tracked(this)) return false
        val locked = Focus.active(this) || Bedtime.active(this)   // Focus and Bedtime always override the study-video rule
        if (pkg == Limits.YOUTUBE && !locked) {
            if (Limits.usedMinutes(this, pkg) < Limits.limitMin(this, pkg)) return false
            if (youTubeAllowed()) return false
        } else if (!Limits.isBlocked(this, pkg)) return false
        current = packageName
        if (!locked) {
            val name = Limits.nameOf(this, pkg)
            val text = if (pkg == Limits.YOUTUBE) "Your YouTube limit is used up. Only study videos can play now."
                else "$name is done for today. Go do some work or step outside."
            Notifier.post(this, pkg.hashCode(), "Enough screen time! ⏱", text, "angry")
        }
        performGlobalAction(GLOBAL_ACTION_HOME)
        startActivity(Intent(this, BlockActivity::class.java)
            .putExtra("pkg", pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
        return true
    }
}
