package com.meowtime.app

import android.content.Context
import com.meowtime.app.Classifier.Label
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Study sessions + YouTube tracking state. Everything is stored on the phone (SharedPreferences).
 * The student starts a session with a subject and a topic; while it runs, the blocker service reads the
 * title and hashtags of what is on screen in YouTube and files the time under a label.
 */
object Study {
    private fun p(c: Context) = c.getSharedPreferences("meowtime", Context.MODE_PRIVATE)
    private const val MAX_SESSION_MS = 4 * 3600_000L

    // ---- consent, on/off and pause ----
    fun consented(c: Context) = p(c).getBoolean("st_consent", false)
    fun setConsented(c: Context) = p(c).edit().putBoolean("st_consent", true).apply()
    fun enabled(c: Context) = p(c).getBoolean("st_enabled", true)
    fun setEnabled(c: Context, on: Boolean) = p(c).edit().putBoolean("st_enabled", on).apply()
    fun pausedUntil(c: Context) = p(c).getLong("st_pause_until", 0)
    fun paused(c: Context) = System.currentTimeMillis() < pausedUntil(c)
    fun pauseFor(c: Context, minutes: Int) = p(c).edit().putLong("st_pause_until", System.currentTimeMillis() + minutes * 60_000L).apply()
    fun resume(c: Context) = p(c).edit().putLong("st_pause_until", 0).apply()

    // ---- the session ----
    fun active(c: Context) = p(c).getBoolean("st_on", false)
    fun subject(c: Context) = p(c).getString("st_subject", "") ?: ""
    fun topic(c: Context) = p(c).getString("st_topic", "") ?: ""
    fun startedAt(c: Context) = p(c).getLong("st_start", 0)

    /** True while a session runs and detection is switched on and not paused. */
    fun detecting(c: Context) = active(c) && enabled(c) && !paused(c)

    fun start(c: Context, subject: String, topic: String) {
        Last.clear()
        p(c).edit().putBoolean("st_on", true).putString("st_subject", subject.trim()).putString("st_topic", topic.trim())
            .putLong("st_start", System.currentTimeMillis()).apply()
    }

    /** Ends the session and returns how many minutes it lasted. */
    fun stop(c: Context): Int {
        if (!active(c)) return 0
        val mins = ((System.currentTimeMillis() - startedAt(c)) / 60_000L).toInt().coerceAtLeast(0)
        val day = Limits.day()
        p(c).edit().putBoolean("st_on", false).putInt("st_sess_$day", p(c).getInt("st_sess_$day", 0) + mins)
            .putInt("st_count_$day", p(c).getInt("st_count_$day", 0) + 1).apply()
        Last.clear()
        return mins
    }

    /** A session that was forgotten ends by itself after 4 hours. */
    fun finishIfStale(c: Context) { if (active(c) && System.currentTimeMillis() - startedAt(c) > MAX_SESSION_MS) stop(c) }

    // ---- what was read most recently (kept in memory only) ----
    object Last {
        @Volatile var title: String? = null
        @Volatile var hashtags: List<String> = emptyList()
        @Volatile var result: Classifier.Result? = null
        @Volatile var page: YouTubeReader.Page = YouTubeReader.Page.UNKNOWN
        @Volatile var at = 0L
        fun clear() { title = null; hashtags = emptyList(); result = null; page = YouTubeReader.Page.UNKNOWN; at = 0 }
    }

    fun key(title: String?): String = (title ?: "").lowercase(Locale.ROOT).trim().take(80).hashCode().toString()

    // ---- corrections: "this is / isn't study-related" ----
    private fun fixes(c: Context): MutableSet<String> = (p(c).getStringSet("st_fix", emptySet()) ?: emptySet()).toMutableSet()

    fun correct(c: Context, title: String?, label: Label) {
        if (title.isNullOrBlank()) return
        val k = key(title); val set = fixes(c).filterNot { it.startsWith("$k:") }.toMutableList()
        set.add("$k:${label.name}")
        p(c).edit().putStringSet("st_fix", set.takeLast(100).toSet()).apply()
        Last.result = Classifier.Result(label, 100, "You marked this one yourself.")
    }

    fun correctionFor(c: Context, title: String?): Label? {
        if (title.isNullOrBlank()) return null
        val k = key(title)
        return fixes(c).firstOrNull { it.startsWith("$k:") }?.substringAfter(':')?.let { runCatching { Label.valueOf(it) }.getOrNull() }
    }

    /** Classify a reading (title + hashtags) for the running session, honouring the student's corrections. */
    fun classify(c: Context, title: String?, tags: List<String>): Classifier.Result {
        correctionFor(c, title)?.let { return Classifier.Result(it, 100, "You marked this one yourself.") }
        return Classifier.classify(title, tags, subject(c), topic(c))
    }

    // ---- time per label, per day (in seconds) ----
    fun addSeconds(c: Context, label: Label, sec: Int) {
        val k = "st_s_${Limits.day()}_${label.name}"
        p(c).edit().putInt(k, p(c).getInt(k, 0) + sec).apply()
    }
    fun seconds(c: Context, label: Label): Int = p(c).getInt("st_s_${Limits.day()}_${label.name}", 0)
    private fun min(c: Context, l: Label) = seconds(c, l) / 60

    fun eduMin(c: Context) = min(c, Label.EDUCATIONAL)
    fun entMin(c: Context) = min(c, Label.ENTERTAINMENT)
    fun mixMin(c: Context) = min(c, Label.MIXED)
    fun unkMin(c: Context) = min(c, Label.UNKNOWN)

    /** Minutes of study sessions today, including the one running now. */
    fun sessionMin(c: Context): Int {
        val saved = p(c).getInt("st_sess_${Limits.day()}", 0)
        val live = if (active(c)) ((System.currentTimeMillis() - startedAt(c)) / 60_000L).toInt() else 0
        return saved + live
    }
    fun sessionCount(c: Context) = p(c).getInt("st_count_${Limits.day()}", 0) + if (active(c)) 1 else 0

    /** Study time = session minutes minus the entertainment minutes found on YouTube during sessions. */
    fun studyMin(c: Context) = (sessionMin(c) - entMin(c)).coerceAtLeast(0)

    /** Share of YouTube time that was on topic, 0..100, or null when nothing was classified yet. Unknown time is left out. */
    fun focusScore(c: Context): Int? {
        val edu = seconds(c, Label.EDUCATIONAL); val mix = seconds(c, Label.MIXED); val ent = seconds(c, Label.ENTERTAINMENT)
        val total = edu + mix + ent
        if (total < 30) return null
        return ((edu + 0.5 * mix) * 100.0 / total).toInt()
    }

    fun goal(c: Context) = p(c).getInt("st_goal", 30)
    fun setGoal(c: Context, m: Int) = p(c).edit().putInt("st_goal", m).apply()
    fun goalFraction(c: Context) = (studyMin(c) / goal(c).toFloat()).coerceIn(0f, 1f)

    // ---- reminders ----
    fun lastRemind(c: Context) = p(c).getLong("st_remind", 0)
    fun markReminded(c: Context, snoozeMin: Int = 0) = p(c).edit().putLong("st_remind", System.currentTimeMillis() + snoozeMin * 60_000L).apply()
    fun canRemind(c: Context) = System.currentTimeMillis() - lastRemind(c) >= 5 * 60_000L

    // ---- verification notes ----
    fun saveNote(c: Context, note: String) {
        val clean = note.trim().replace('\n', ' ').take(300)
        if (clean.isEmpty()) return
        val day = SimpleDateFormat("MMM d", Locale.getDefault()).format(Date())
        val line = "$day · ${subject(c).ifBlank { "Study" }}: $clean"
        val list = (listOf(line) + notes(c)).take(20)
        p(c).edit().putString("st_notes", list.joinToString("\n")).putInt("st_note_count", p(c).getInt("st_note_count", 0) + 1).apply()
    }
    fun notes(c: Context): List<String> = (p(c).getString("st_notes", "") ?: "").split("\n").filter { it.isNotBlank() }
    fun noteCount(c: Context) = p(c).getInt("st_note_count", 0)
}
