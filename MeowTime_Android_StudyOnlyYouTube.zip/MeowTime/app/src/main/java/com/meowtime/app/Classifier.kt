package com.meowtime.app

import java.util.Locale

/**
 * Offline keyword matcher. Compares a video's title and hashtags with the student's subject and topic.
 * It never guesses: when nothing useful was read, the answer is UNKNOWN.
 */
object Classifier {
    enum class Label { EDUCATIONAL, ENTERTAINMENT, MIXED, UNKNOWN }
    class Result(val label: Label, val confidence: Int, val reason: String)

    private val wordRe = Regex("[\\p{L}\\p{N}]+")

    /** Lowercase, drop apostrophes, split into words, apply synonyms and ignore a plural "s". */
    fun tokens(text: String): List<String> =
        wordRe.findAll(text.lowercase(Locale.ROOT).replace("'", "").replace("\u2019", "")).map { norm(it.value) }.toList()

    private fun norm(w: String): String {
        val s = Keywords.synonyms[w] ?: w
        return if (s.length > 3 && s.endsWith("s") && !s.endsWith("ss")) s.dropLast(1) else s
    }

    private val study = Keywords.studyWords.map { norm(it) }.toSet()
    private val studyTag = Keywords.studyTags.map { norm(it) }.toSet()
    private val fun_ = Keywords.funWords.map { norm(it) }.toSet()
    private val funTag = Keywords.funTags.map { norm(it) }.toSet()
    private val stop = Keywords.stop.map { norm(it) }.toSet()

    fun classify(title: String?, hashtags: List<String>, subject: String, topic: String): Result {
        if (title.isNullOrBlank()) return Result(Label.UNKNOWN, 0, "Could not read a video title.")
        val titleWords = tokens(title).toSet()
        val tagWords = hashtags.flatMap { tokens(it) }.toSet()
        if (titleWords.isEmpty() && tagWords.isEmpty())
            return Result(Label.UNKNOWN, 0, "Could not read a title or hashtags.")

        val subj = tokens("$subject $topic").filter { it.length >= 3 && it !in stop }.toSet()
        val subjHits = subj.filter { it in titleWords || it in tagWords }
        val studyHits = titleWords.filter { it in study }.toSet() + tagWords.filter { it in studyTag }
        val funHits = titleWords.filter { it in fun_ }.toSet() + tagWords.filter { it in funTag }
        val what = listOf(subject, topic).filter { it.isNotBlank() }.joinToString(": ")

        if (subjHits.isNotEmpty()) {
            val conf = (70 + subjHits.size * 10 + studyHits.size * 5).coerceAtMost(95)
            return if (funHits.isEmpty())
                Result(Label.EDUCATIONAL, conf, "Matches your topic (${subjHits.joinToString(", ")}).")
            else
                Result(Label.MIXED, 55, "Matches your topic (${subjHits.joinToString(", ")}) but also looks like entertainment (${funHits.joinToString(", ")}).")
        }
        if (studyHits.isNotEmpty()) {
            return if (funHits.isEmpty())
                Result(Label.EDUCATIONAL, (45 + studyHits.size * 10).coerceAtMost(65),
                    if (what.isEmpty()) "Looks like study content (${studyHits.joinToString(", ")})."
                    else "Looks like study content (${studyHits.joinToString(", ")}), but it doesn't mention $what.")
            else
                Result(Label.MIXED, 50, "Has study words (${studyHits.joinToString(", ")}) and entertainment words (${funHits.joinToString(", ")}).")
        }
        if (funHits.isNotEmpty())
            return Result(Label.ENTERTAINMENT, (55 + funHits.size * 15).coerceAtMost(90), "Looks like entertainment (${funHits.joinToString(", ")}).")
        return Result(Label.UNKNOWN, 20, "No study or entertainment words found.")
    }
}
