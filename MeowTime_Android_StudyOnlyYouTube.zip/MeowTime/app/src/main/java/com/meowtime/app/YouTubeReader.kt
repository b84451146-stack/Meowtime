package com.meowtime.app

import android.view.accessibility.AccessibilityNodeInfo

/**
 * Reads what YouTube shows on screen: which kind of screen it is (Shorts, a video page, or browsing) and, on a
 * video page, the title and hashtags. It never records audio, takes screenshots or looks at the video itself,
 * and the text stays on the phone (in memory only).
 *
 * YouTube does not promise what its screens contain, and an update can change it. When no title can be
 * found the answer is simply "no title" and the classifier returns UNKNOWN.
 *
 * IMPORTANT: the view ids below are best guesses. Open Study > "What MeowTime read" on your phone while
 * (a) a lecture plays, (b) a Short plays and (c) YouTube's home screen is open. The "Ids" line lists every
 * view id on screen. Put the ones that only exist on that kind of screen into the lists below.
 * If an id is wrong the safe result is no match: the screen is then treated as unknown and blocked after the limit.
 */
object YouTubeReader {
    /** Ids of the video title on a video page. */
    val TITLE_IDS = listOf("video_title")
    /** Ids that hold a title but are also used by feed cards, so they only count when a player is on screen. */
    val WEAK_TITLE_IDS = listOf("title")
    /** Ids that exist only inside the Shorts player (UNVERIFIED guesses). */
    val SHORTS_IDS = listOf("reel_player_page_container", "reel_recycler", "shorts_player")
    /** Ids that exist only on a video page / player (UNVERIFIED guesses). */
    val WATCH_IDS = listOf("watch_player", "player_view", "watch_while_time_bar_view")
    /** Ids that exist on home / search / subscriptions but not in a player (UNVERIFIED guesses). */
    val BROWSE_IDS = listOf("pivot_bar", "pivot_home", "results")

    enum class Page { SHORTS, WATCH, BROWSE, UNKNOWN }

    class Reading(val title: String?, val hashtags: List<String>, val page: Page) {
        val isShort: Boolean get() = page == Page.SHORTS
    }

    /** What the last read saw, for the "What MeowTime read" screen. Kept in memory only. */
    @Volatile var lastDump: String = "Nothing read yet. Open a YouTube video."

    private val tagRe = Regex("#[\\p{L}\\p{N}_]{2,40}")
    private const val MAX_NODES = 400

    private class Item(val id: String, val text: String)

    fun read(root: AccessibilityNodeInfo): Reading {
        val items = ArrayList<Item>()
        val ids = LinkedHashSet<String>()
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.addLast(root)
        var seen = 0
        while (stack.isNotEmpty() && seen < MAX_NODES) {
            val n = stack.removeLast(); seen++
            if (!n.isVisibleToUser) continue
            val id = n.viewIdResourceName?.substringAfter("/") ?: ""
            if (id.isNotEmpty()) ids.add(id)
            val t = n.text?.toString()?.trim().orEmpty()
            val d = n.contentDescription?.toString()?.trim().orEmpty()
            if (t.isNotEmpty()) items.add(Item(id, t))
            if (d.isNotEmpty() && d != t) items.add(Item(id, d))
            for (i in n.childCount - 1 downTo 0) n.getChild(i)?.let { stack.addLast(it) }
        }
        val hasShorts = ids.any { it in SHORTS_IDS }
        val hasWatch = ids.any { it in WATCH_IDS }
        val strong = items.firstOrNull { it.id in TITLE_IDS && it.text.length >= 4 }?.text
        val weak = if (hasWatch) items.firstOrNull { it.id in WEAK_TITLE_IDS && it.text.length >= 4 }?.text else null
        // A Short never has a usable title, so nothing from a Short can ever pass as study content.
        val title = if (hasShorts) null else (strong ?: weak)
        val page = when {
            hasShorts -> Page.SHORTS
            hasWatch || title != null -> Page.WATCH
            ids.any { it in BROWSE_IDS } -> Page.BROWSE
            else -> Page.UNKNOWN
        }
        // Hashtags only count together with a real title (a hashtag on its own is too easy to fake).
        val tags = if (title == null) emptyList()
            else items.flatMap { tagRe.findAll(it.text).map { m -> m.value.lowercase() }.toList() }.distinct().take(8)
        lastDump = buildString {
            append("Page: ").append(page.name).append('\n')
            append("Title: ").append(title ?: "(not found)").append('\n')
            append("Hashtags: ").append(if (tags.isEmpty()) "(none)" else tags.joinToString(" ")).append('\n')
            append("Ids: ").append(if (ids.isEmpty()) "(none)" else ids.take(60).joinToString(", ")).append("\n\n")
            items.take(50).forEach { append(it.id.ifEmpty { "-" }).append("  |  ").append(it.text.take(70)).append('\n') }
        }
        return Reading(title, tags, page)
    }
}
