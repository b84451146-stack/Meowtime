# Changes in this version (YouTube study-only rule)

- Shorts are blocked after the YouTube limit; a Short can never pass as study content.
- Home/search stay usable after the limit; a video page must read Educational with confidence >= 65.
- A hashtag alone no longer counts; a real title is required (matches the "unreadable = blocked" promise).
- Study subject/topic are used again for classification while a study session runs.
- Fullscreen: the last Educational result is kept 5 minutes, with a warning at 4 minutes ("Exit fullscreen to keep watching").
- Switching videos is caught within about 2 seconds (was up to 10).
- "Study-related" corrections no longer unlock YouTube after the limit.
- Reading YouTube's screen now needs the one-time consent and respects the off/pause switch; privacy texts updated.
- Cleanup: stale 5 h comments, dead code in enforce(), duplicate screen read.
- The view ids in YouTubeReader.kt are unverified guesses. See README, "Check the view ids".
- Not compiled here (no Android SDK). The GitHub Action will show any build error.
