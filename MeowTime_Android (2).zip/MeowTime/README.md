# MeowTime (Android, step 1)

Includes: usage tracking, per-app daily limits, and blocking after the limit.

## Build
1. Open this folder in Android Studio (Koala or newer). Let Gradle sync.
2. Plug in a phone (USB debugging on) and press Run, or Build > Build APK(s).
   APK path: app/build/outputs/apk/debug/app-debug.apk
3. Open MeowTime, tap "Allow Usage Access", then "Turn on blocker" and enable MeowTime blocker.
4. Set a low limit (1 min) on an installed app to test.

## How blocking works
Android cannot force-close another app. When a limited app is opened (or hits its limit while open),
the Accessibility Service sends the phone to the home screen and shows the MeowTime break screen.
Limits count from local midnight, so they reset daily.

Cat: the banana cat is the default. Outfits: watermelon, fire, strawberry (your artwork) and grape, dragonfruit,
blueberry, ice flame (recolours I made of your artwork). All selectable for now; unlock rules come with rewards.
Moods (happy, excited, worried, sleepy, sad, proud, study) have their own face for every outfit. The mood follows real
usage: sad if an app hit its limit, worried at 80% of a limit, sleepy at 90+ min total, otherwise happy. The widget
refreshes when the mood changes (checked every ~10 s while the blocker is on) and every 30 min as a fallback.
Tap the cat in the app for a hop and floating hearts. Add the widget from the home-screen widget picker ("MeowTime");
tapping the cat there plays a short hearts sequence. Widgets cannot run free animation, so it is a few quick picture updates.

Not yet built: Focus mode, DND, mood changes, stats, rewards, widget sizes beyond one resizable widget.
Untested: written without an Android SDK, so expect to fix small build errors.
