# OFFGRID (Android)

A student screen-time app. It keeps the student in control while making automatic phone habits visible.

## What it does

**Limits**
- Every app starts at **3 hours/day**. **YouTube only** can go up to **5 hours** (apps you add stay at 3 h).
- **+ Add app** (Limits tab): pick any installed app to track and limit. Added apps can be removed again
  (not while they are locked today, so a limit can't be dodged). The 5 built-in apps stay.
- Lowering a limit works at once; raising it starts tomorrow.

**Pause instead of a wall**
- **Open it?** When a tracked app is opened, OFFGRID waits 10 seconds ("Open Instagram?") and offers a quick
  alternative: breathing, a 2-minute stretch or a puzzle. The student can still open the app after the wait.
  Can be switched off on the Limits tab. (Not shown for YouTube while a study session is running.)
- **Continue?** At the limit the app is covered by a "You've hit your limit. Continue?" screen. Continuing
  (once per app per day, +15 min) needs a 10-second wait and a reason. Reasons are counted on the Insights tab.
- Insights also shows how many pauses ended in "Not now".

**Study tab (YouTube)**
- Start a **study session** with a subject and topic.
- While a session runs and YouTube is in front, OFFGRID reads the **title and hashtags** shown on screen and
  labels the time **Educational / Entertainment / Mixed / Unknown** with an **offline keyword matcher**
  (no internet, no API key). If no title can be read, the label is **Unknown**. It never guesses.
- **Reminders** after about 90 s of entertainment during a session, with "It's study-related" and "Dismiss".
- **Correct** any label from the Study tab ("Study-related" / "Not study"); corrections are remembered.
- **Dashboard**: study time, sessions, focus score, time per label, daily goal.
- **Controls**: turn detection off, or pause it for 30 minutes.
- **Verification**: after a session, an optional one-sentence note about what you learned.
- **Privacy**: no audio, no screenshots, nothing leaves the phone. A privacy screen explains each permission,
  and the first session asks for a one-time "I understand".

Other features from before are unchanged: Focus mode, bedtime lock, phone pickups, streaks and badges, weekly goal,
break reminders, 9 pm summary, Sunday weekly report.

## Edit the keywords
`app/src/main/java/com/meowtime/app/Keywords.kt` holds all word lists (study words, entertainment words and hashtags).
Add words that are specific to your school and rebuild. Plural "s" is ignored automatically.

## Build
Push this folder to GitHub; the workflow builds `app-debug.apk` (artifact "MeowTime-apk").
After install: allow restricted settings (App info > three dots), turn on Usage Access, turn on the OFFGRID
blocker in Accessibility, allow notifications.

Note: the new accessibility settings (reading YouTube's on-screen text) mean Android asks you to re-confirm
the Accessibility permission after updating over an older build.

## Honest limits
- YouTube does not promise what its screens contain. Shorts often show little text, and a YouTube update can
  change what is visible. When the title can't be read, the result is Unknown.
- The title is found by its view id (`YouTubeReader.TITLE_IDS`). If titles are never found on your phone, run a study
  session, play a video, open **Study > See what OFFGRID just read**, and add the id shown next to the title.
- No transcripts, audio or video content can be read; Android does not allow it.
- The matcher is English-only and keyword based. Vague titles come out as Unknown or Mixed.
- Written without an Android SDK, so expect to fix small build errors.
- Google restricts Accessibility use on the Play Store; this suits a school project or a sideloaded APK.
