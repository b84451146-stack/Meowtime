package com.meowtime.app

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context

/** Counts how many times the phone was unlocked (falls back to screen-on events). Needs Usage Access. */
object Pickups {
    private const val KEYGUARD_HIDDEN = 18      // the phone was unlocked
    private const val SCREEN_INTERACTIVE = 15   // the screen turned on

    private fun bucket(c: Context, starts: List<Long>): List<Int> {
        val unlock = IntArray(starts.size); val screen = IntArray(starts.size)
        try {
            val m = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val ev = m.queryEvents(starts[0], System.currentTimeMillis())
            val e = UsageEvents.Event()
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                val idx = starts.indexOfLast { it <= e.timeStamp }
                if (idx < 0) continue
                when (e.eventType) {
                    KEYGUARD_HIDDEN -> unlock[idx]++
                    SCREEN_INTERACTIVE -> screen[idx]++
                }
            }
        } catch (e: SecurityException) {}
        val useUnlock = unlock.sum() > 0
        return starts.indices.map { if (useUnlock) unlock[it] else screen[it] }
    }

    /** Pickups for each of the last 7 days, oldest first (today is last). */
    fun daily(c: Context): List<Int> = bucket(c, (6 downTo 0).map { Limits.midnight(it) })

    fun today(c: Context): Int = bucket(c, listOf(Limits.midnight(0))).first()
}
