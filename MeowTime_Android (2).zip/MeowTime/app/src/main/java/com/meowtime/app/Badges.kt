package com.meowtime.app

/** Streak badges. Your best streak counts, so a broken streak never locks a badge again. */
object Badges {
    class Badge(val key: String, val emoji: String, val name: String, val days: Int)

    val all = listOf(
        Badge("brick", "🧱", "Brick", 3),
        Badge("bronze", "🥉", "Bronze", 5),
        Badge("silver", "🥈", "Silver", 7),
        Badge("gold", "🥇", "Gold", 10),
        Badge("diamond", "💎", "Diamond", 14),
        Badge("rocket", "🚀", "Rocket", 21),
        Badge("crown", "👑", "Crown", 30)
    )

    /** The best badge earned so far, or null. */
    fun current(best: Int): Badge? = all.lastOrNull { it.days <= best }

    /** The next badge to earn, or null when everything is unlocked. */
    fun nextAfter(best: Int): Badge? = all.firstOrNull { it.days > best }
}
