package com.meowtime.app

/**
 * Word lists for the offline YouTube classifier. Edit freely: add your own words (for example subjects
 * that are specific to your school) and rebuild. Everything is lowercase. Plural "s" is ignored when
 * matching, so "lecture" also matches "lectures".
 *
 * Nothing in here needs the internet, and no video title ever leaves the phone.
 */
object Keywords {
    /** Study words found in a video title. */
    val studyWords = setOf(
        "lecture", "lesson", "tutorial", "explained", "explanation", "explain", "chapter", "exam", "exams",
        "revision", "revise", "solved", "solution", "experiment", "derivation", "proof", "theorem", "formula",
        "concept", "numerical", "problem", "syllabus", "course", "learn", "learning", "study", "studying",
        "homework", "assignment", "practical", "demonstration", "introduction", "fundamentals", "ncert",
        "cbse", "icse", "neet", "jee", "gcse", "mcq", "quiz", "worksheet", "textbook", "masterclass"
    )

    /** Hashtags (written without the #) that point to studying. */
    val studyTags = setOf(
        "study", "studywithme", "studytips", "education", "educational", "learning", "physics", "maths", "math",
        "mathematics", "chemistry", "biology", "science", "history", "geography", "economics", "coding",
        "programming", "neet", "jee", "upsc", "exam", "exams", "revision", "homework", "lecture", "tutorial",
        "english", "grammar", "algebra", "calculus", "geometry", "trigonometry"
    )

    /** Entertainment words found in a video title. */
    val funWords = setOf(
        "funny", "funniest", "prank", "comedy", "meme", "reaction", "reacts", "vlog", "gameplay", "gaming", "trailer",
        "highlights", "roast", "challenge", "dance", "remix", "lyrics", "skit", "fails", "fail", "compilation",
        "asmr", "unboxing", "livestream", "playthrough", "walkthrough", "mukbang", "tiktok", "viral", "trending",
        "song", "music", "episode", "cartoon", "anime", "sketch", "bloopers", "hilarious", "lol"
    )

    /** Hashtags (written without the #) that point to entertainment. #shorts alone says nothing, so it is not here. */
    val funTags = setOf(
        "funny", "viral", "trending", "comedy", "memes", "meme", "prank", "dance", "fyp", "gaming", "gameplay",
        "vlog", "trend", "challenge", "lol", "relatable", "edit", "edits", "reels", "tiktok", "music", "song",
        "cartoon", "anime", "roast"
    )

    /** Words that are never treated as part of a subject or topic. */
    val stop = setOf("the", "and", "for", "with", "from", "into", "about", "this", "that", "are", "was", "of", "in", "on", "to", "a", "an")

    /** Different ways of writing the same subject. */
    val synonyms = mapOf(
        "maths" to "math", "mathematics" to "math", "phy" to "physics", "chem" to "chemistry",
        "bio" to "biology", "eco" to "economics", "econ" to "economics", "cs" to "computer"
    )
}
