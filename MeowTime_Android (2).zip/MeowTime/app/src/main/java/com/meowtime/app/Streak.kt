package com.meowtime.app

import android.content.Context
import java.util.Calendar

/** Days in a row with every tracked app under its limit. Checked once a new day starts. Unlocks badges. */
object Streak {
    private fun p(c: Context) = c.getSharedPreferences("meowtime", Context.MODE_PRIVATE)
    fun current(c: Context) = p(c).getInt("streak", 0)
    fun best(c: Context) = p(c).getInt("best", 0)

    private fun dayToMillis(d: Int): Long = Calendar.getInstance().apply {
        set(d / 10000, d / 100 % 100 - 1, d % 100, 0, 0, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    /** Is every app under its saved limit for the day that starts daysAgo days ago? */
    private fun dayOk(c: Context, daysAgo: Int): Boolean {
        val start = Limits.midnight(daysAgo)
        val used = Limits.usedAll(c, start, start + 24 * 3600_000L)
        return Limits.tracked(c).all { (used[it] ?: 0L) <= Limits.baseMin(c, it) }
    }

    /** Call often; it only does work once per day. Needs Usage Access (quietly skips if it is missing). */
    fun update(c: Context) {
        val pr = p(c); val today = Limits.day()
        val last = pr.getInt("st_checked", 0)
        if (last == today) return
        if (last == 0) {   // first run: start counting from tomorrow
            pr.edit().putInt("st_checked", today).putString("unl_seen", "").apply(); return
        }
        val gap = Math.round((Limits.midnight(0) - dayToMillis(last)) / 86400000.0).toInt().coerceIn(1, 7)
        var streak = pr.getInt("streak", 0)
        try {
            for (d in gap downTo 1) streak = if (dayOk(c, d)) streak + 1 else 0
        } catch (e: SecurityException) { return }
        val best = maxOf(pr.getInt("best", 0), streak)
        pr.edit().putInt("st_checked", today).putInt("streak", streak).putInt("best", best).apply()
        announceUnlocks(c, best)
    }

    private fun announceUnlocks(c: Context, best: Int) {
        val pr = p(c)
        val seen = (pr.getString("unl_seen", "") ?: "").split(",").filter { it.isNotEmpty() }.toMutableSet()
        for (b in Badges.all) {
            if (b.days <= best && seen.add(b.key))
                Notifier.post(c, 500 + b.days, "New badge unlocked! ${b.emoji}", "${b.name} badge earned. See it on the Rewards tab.", "")
        }
        pr.edit().putString("unl_seen", seen.joinToString(",")).apply()
    }

    /** The next locked badge and how many streak days are still needed, or null when everything is unlocked. */
    fun next(c: Context): Pair<Badges.Badge, Int>? {
        val b = best(c)
        return Badges.nextAfter(b)?.let { it to (it.days - b) }
    }
}

/** Weekly goal: keep one app under a daily target on at least 5 of the last 7 days. */
object Goal {
    const val NEED = 5
    private fun p(c: Context) = c.getSharedPreferences("meowtime", Context.MODE_PRIVATE)
    fun pkg(c: Context): String {
        val saved = p(c).getString("goal_pkg", null)
        return if (saved != null && saved in Limits.tracked(c)) saved else Limits.defaults.getValue("Instagram")
    }
    fun target(c: Context): Int = p(c).getInt("goal_min", 60)
    fun set(c: Context, pkg: String, min: Int) = p(c).edit().putString("goal_pkg", pkg).putInt("goal_min", min).apply()

    /** How many of the last 7 days (today included) the app stayed at or under the target. */
    fun daysMet(c: Context): Int {
        val pkg = pkg(c); val t = target(c)
        return (6 downTo 0).count { d ->
            val start = Limits.midnight(d)
            val end = if (d == 0) System.currentTimeMillis() else start + 24 * 3600_000L
            (Limits.usedAll(c, start, end)[pkg] ?: 0L) <= t
        }
    }
}
