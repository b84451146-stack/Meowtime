package com.meowtime.app

import android.app.NotificationManager
import android.content.Context

/** Study sessions. Survives the app being closed: the end time is stored, and the blocker service checks it. */
object Focus {
    private fun p(c: Context) = c.getSharedPreferences("meowtime", Context.MODE_PRIVATE)
    private fun nm(c: Context) = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun active(c: Context) = System.currentTimeMillis() < p(c).getLong("f_end", 0)
    fun remainingMs(c: Context) = (p(c).getLong("f_end", 0) - System.currentTimeMillis()).coerceAtLeast(0)
    fun plannedMs(c: Context) = p(c).getInt("f_min", 25) * 60_000L
    fun sessions(c: Context) = p(c).getInt("f_sessions", 0)
    fun minutes(c: Context) = p(c).getInt("f_minutes", 0)
    fun dndAllowed(c: Context) = nm(c).isNotificationPolicyAccessGranted

    fun start(c: Context, min: Int) {
        var prev = -1
        if (dndAllowed(c)) {
            prev = nm(c).currentInterruptionFilter
            nm(c).setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        }
        p(c).edit().putLong("f_end", System.currentTimeMillis() + min * 60_000L).putInt("f_min", min).putInt("f_prev", prev).apply()
        Mood.override(c, "study", min * 60_000L)
    }

    private fun restore(c: Context) {
        val prev = p(c).getInt("f_prev", -1)
        if (prev > 0 && dndAllowed(c)) nm(c).setInterruptionFilter(prev)   // put notifications back how they were
        p(c).edit().putInt("f_prev", -1).apply()
    }

    fun cancel(c: Context) {
        restore(c)
        p(c).edit().putLong("f_end", 0).apply()
        Mood.clear(c)
    }

    /** Call often. Returns true once, at the moment a session has just finished. */
    fun finishIfDone(c: Context): Boolean {
        val end = p(c).getLong("f_end", 0)
        if (end == 0L || System.currentTimeMillis() < end) return false
        restore(c)
        val planned = p(c).getInt("f_min", 25)
        p(c).edit().putLong("f_end", 0).putInt("f_sessions", sessions(c) + 1).putInt("f_minutes", minutes(c) + planned).apply()
        Mood.override(c, "excited", 90_000)
        Notifier.post(c, 7, "Focus session done! 🎉", "You studied for $planned minutes. Great work!", "excited")
        return true
    }
}
