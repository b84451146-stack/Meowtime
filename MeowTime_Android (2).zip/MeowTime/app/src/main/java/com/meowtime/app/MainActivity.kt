package com.meowtime.app

import android.app.Activity
import android.app.AppOpsManager
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Process
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    override fun onResume() { super.onResume(); build() }

    private fun usageGranted(): Boolean {
        val ops = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }
    private fun blockerOn(): Boolean =
        Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains("$packageName/.BlockerService") == true

    private fun build() {
        val granted0 = usageGranted()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        fun tv(t: String, s: Float = 16f, c: Int = Color.WHITE) = TextView(this).apply { text = t; textSize = s; setTextColor(c); setPadding(0, 10, 0, 10) }
        col.addView(tv("MeowTime", 28f))
        val catView = CatView(this).apply { setMood(if (granted0) Mood.current(this@MainActivity) else "happy") }
        col.addView(catView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (260 * resources.displayMetrics.density).toInt()))
        col.addView(tv("Tap the cat to pet it. Outfit:", 14f, Color.parseColor("#C9B8FF")))
        val outfitRow = LinearLayout(this)
        for (n in CatArt.outfits.keys) outfitRow.addView(Button(this).apply {
            text = n; textSize = 11f
            setOnClickListener { CatArt.setOutfit(this@MainActivity, n); catView.setOutfit(n); MeowWidget.refresh(this@MainActivity) }
        })
        col.addView(HorizontalScrollView(this).apply { addView(outfitRow) })
        col.addView(tv("Preview a mood (shows for 1 minute, also on the widget):", 14f, Color.parseColor("#C9B8FF")))
        val moodRow = LinearLayout(this)
        for (mo in Mood.all) moodRow.addView(Button(this).apply {
            text = mo; textSize = 11f
            setOnClickListener { Mood.override(this@MainActivity, mo, 60_000); catView.setMood(mo); MeowWidget.refresh(this@MainActivity) }
        })
        col.addView(HorizontalScrollView(this).apply { addView(moodRow) })
        col.addView(tv("Step 1: Usage Access, to count minutes per app.", 14f, Color.parseColor("#C9B8FF")))
        col.addView(Button(this).apply {
            text = if (usageGranted()) "Usage Access: on ✓" else "Allow Usage Access"
            setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        })
        col.addView(tv("Step 2: Accessibility, to cover apps that hit their limit.", 14f, Color.parseColor("#C9B8FF")))
        col.addView(Button(this).apply {
            text = if (blockerOn()) "Blocker: on ✓" else "Turn on blocker"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        col.addView(tv("Daily limits (tap to change)", 18f))
        val granted = usageGranted()
        for ((name, pkg) in Limits.apps) {
            val used = if (granted) Limits.usedMinutes(this, pkg) else 0
            val lim = Limits.limitMin(this, pkg)
            col.addView(Button(this).apply {
                text = "$name   $used / $lim min"
                setOnClickListener { editLimit(name, pkg) }
            })
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#0F1030")); addView(col) })
    }

    private fun editLimit(name: String, pkg: String) {
        val input = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(Limits.limitMin(this@MainActivity, pkg).toString()) }
        AlertDialog.Builder(this).setTitle("$name daily limit (minutes)").setView(input)
            .setPositiveButton("Save") { _, _ ->
                Limits.setLimit(this, pkg, input.text.toString().toIntOrNull() ?: 20); build()
            }.setNegativeButton("Cancel", null).show()
    }
}
