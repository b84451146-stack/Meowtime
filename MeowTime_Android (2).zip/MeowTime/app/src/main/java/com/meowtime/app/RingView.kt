package com.meowtime.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import android.view.animation.DecelerateInterpolator

/** A round progress ring with text in the middle. animateTo() sweeps it smoothly. */
class RingView(c: Context) : View(c) {
    var frac = 0f
    var color = 0xFF9B7DFF.toInt()
    var label = ""
    var sub = ""
    var labelScale = 0.26f
    var trackColor = 0xFF2A2D5C.toInt()
    var textColor = 0xFFF2F1FF.toInt()
    var subColor = 0xFF9C9AC8.toInt()
    private var anim: ValueAnimator? = null
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val t1 = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; isFakeBoldText = true }
    private val t2 = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val r = RectF()

    fun animateTo(target: Float, ms: Long = 900, delay: Long = 150) {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(frac, target.coerceIn(0f, 1f)).apply {
            duration = ms; startDelay = delay; interpolator = DecelerateInterpolator()
            addUpdateListener { frac = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() { anim?.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val s = w * 0.11f
        track.strokeWidth = s; arc.strokeWidth = s
        track.color = trackColor; arc.color = color; t1.color = textColor; t2.color = subColor
        r.set(s, s, w - s, height - s)
        canvas.drawArc(r, 0f, 360f, false, track)
        canvas.drawArc(r, -90f, 360f * frac.coerceIn(0f, 1f), false, arc)
        t1.textSize = w * labelScale; t2.textSize = w * 0.10f
        canvas.drawText(label, w / 2, height / 2f + t1.textSize * 0.3f, t1)
        canvas.drawText(sub, w / 2, height / 2f + t1.textSize * 0.3f + t2.textSize * 1.5f, t2)
    }
}
