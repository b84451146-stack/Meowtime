package com.meowtime.app

import android.content.Context

/** The short pause before a tracked app opens ("Open Instagram?"), plus a few small stats about it. */
object Pause {
    const val WAIT_SEC = 10
    private const val PASS_MS = 45_000L   // after "Open anyway" the app may open without a second pause

    private fun p(c: Context) = c.getSharedPreferences("meowtime", Context.MODE_PRIVATE)

    fun enabled(c: Context) = p(c).getBoolean("pause_on", true)
    fun setEnabled(c: Context, on: Boolean) = p(c).edit().putBoolean("pause_on", on).apply()

    /** No pause for YouTube while a study session is running (the student opened it on purpose to study). */
    fun needed(c: Context, pkg: String): Boolean {
        if (!enabled(c)) return false
        if (pkg == Limits.YOUTUBE && Study.active(c)) return false
        return System.currentTimeMillis() > p(c).getLong("pass_$pkg", 0)
    }
    fun allow(c: Context, pkg: String) = p(c).edit().putLong("pass_$pkg", System.currentTimeMillis() + PASS_MS).apply()

    private fun bump(c: Context, k: String) { val key = "${k}_${Limits.day()}"; p(c).edit().putInt(key, p(c).getInt(key, 0) + 1).apply() }
    fun recordOpened(c: Context) = bump(c, "pz_open")
    fun recordSkipped(c: Context) = bump(c, "pz_skip")
    fun opened(c: Context) = p(c).getInt("pz_open_${Limits.day()}", 0)
    fun skipped(c: Context) = p(c).getInt("pz_skip_${Limits.day()}", 0)

    /** Why the student asked for the extra 15 minutes (counts per reason, all time). */
    val reasons = listOf("📚 Studying / class", "💬 Messaging someone", "💼 Something important", "😅 Just want to keep scrolling")
    fun recordReason(c: Context, i: Int) { val k = "why_$i"; p(c).edit().putInt(k, p(c).getInt(k, 0) + 1).apply() }
    fun reasonCount(c: Context, i: Int) = p(c).getInt("why_$i", 0)
}
