package com.meowtime.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.accessibility.AccessibilityEvent
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Android does not let an app force-close another app. Instead, when a limited app comes to the
 * front, this service sends the user to the home screen and opens OFFGRID's break screen.
 * When a tracked app is opened (and isn't blocked) it first shows a short "Open Instagram?" pause.
 * During a study session it also reads the title and hashtags that YouTube shows on screen.
 * It also runs the small background jobs: 80% warnings, the streak check, break reminders and the 9 pm summary.
 */
class BlockerService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var current: String? = null
    private var contPkg: String? = null      // tracked app the user has been in without leaving
    private var contSince = 0L
    private var lastRead = 0L                // when YouTube's screen text was last read (throttle)
    private var lastTick = 0L                // when YouTube study time was last counted
    private var lastPauseAt = 0L             // so a late event from the app can't restart the pause
    private var entSeconds = 0               // continuous seconds on entertainment during a study session

    private val poll = object : Runnable {
        override fun run() {
            // Catches the moment a limit is reached while the app is already open.
            current?.let { enforce(it) }
            Focus.finishIfDone(this@BlockerService)
            try {
                val usage = Limits.usedAll(this@BlockerService)
                Notifier.checkWarnings(this@BlockerService, usage)
                Streak.update(this@BlockerService)
                dailySummary(usage)
                dailyQuote()
                weeklyReport()
            } catch (e: SecurityException) {}
            breakCheck()
            studyTick()
            handler.postDelayed(this, 10_000)
        }
    }

    override fun onServiceConnected() { handler.post(poll) }
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); super.onDestroy() }
    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val pkg = event.packageName?.toString() ?: return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            if (pkg == Limits.YOUTUBE && contPkg == pkg) readYouTube()   // the screen changed inside YouTube
            return
        }
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        current = pkg
        val tracked = Limits.tracked(this)
        val fresh = pkg in tracked && contPkg != pkg          // the app was just opened (not just a new screen inside it)
        if (pkg in tracked) {
            if (contPkg != pkg) { contPkg = pkg; contSince = System.currentTimeMillis() }
        } else if (!pkg.contains("inputmethod") && !pkg.contains("keyboard") && pkg != "com.android.systemui") {
            if (contPkg == Limits.YOUTUBE) { Study.Last.clear(); entSeconds = 0 }
            contPkg = null   // the user left for something else
        }
        if (enforce(pkg)) return
        if (fresh && pkg != packageName && Pause.needed(this, pkg)) { pause(pkg); return }
        if (pkg == Limits.YOUTUBE) readYouTube()
    }

    /** Sends the user home and shows the "Open Instagram?" pause. */
    private fun pause(pkg: String) {
        val now = System.currentTimeMillis()
        if (now - lastPauseAt < 3000) return
        lastPauseAt = now
        current = packageName
        performGlobalAction(GLOBAL_ACTION_HOME)
        startActivity(Intent(this, PauseActivity::class.java)
            .putExtra("pkg", pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
    }

    /** Reads the title and hashtags on YouTube's screen, only while a study session is running. Throttled. */
    private fun readYouTube() {
        if (!Study.detecting(this)) return
        val now = System.currentTimeMillis()
        if (now - lastRead < 2000) return
        lastRead = now
        val root = (try { rootInActiveWindow } catch (e: Exception) { null }) ?: return
        if (root.packageName?.toString() != Limits.YOUTUBE) return
        val r = try { YouTubeReader.read(root) } catch (e: Exception) { return }
        Study.Last.title = r.title; Study.Last.hashtags = r.hashtags; Study.Last.at = now
        Study.Last.result = Study.classify(this, r.title, r.hashtags)
    }

    /** Every 10 s: file YouTube time under the current label and send a gentle reminder if it looks like entertainment. */
    private fun studyTick() {
        Study.finishIfStale(this)
        val now = System.currentTimeMillis()
        val delta = if (lastTick == 0L) 0 else ((now - lastTick) / 1000).toInt().coerceIn(0, 15)
        lastTick = now
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!Study.detecting(this) || contPkg != Limits.YOUTUBE || !pm.isInteractive) { entSeconds = 0; return }
        readYouTube()   // keep the label fresh even if YouTube sent no screen-change event
        val res = Study.Last.result
        val label = res?.label ?: Classifier.Label.UNKNOWN
        Study.addSeconds(this, label, delta)
        if (label == Classifier.Label.ENTERTAINMENT) entSeconds += delta else entSeconds = 0
        if (entSeconds >= 90 && Study.canRemind(this)) {
            Study.markReminded(this)
            val title = Study.Last.title?.take(60)?.let { "\"$it\" " } ?: ""
            Notifier.postWithActions(this, Notifier.ID_STUDY, "Studying ${Study.topic(this).ifBlank { Study.subject(this).ifBlank { "now" } }}?",
                "This ${title}looks like entertainment. Keep going or switch back when you're ready.",
                listOf("It's study-related" to ReminderReceiver.ACTION_FIX, "Dismiss" to ReminderReceiver.ACTION_DISMISS))
        }
    }

    /** After 20 minutes in one tracked app without leaving, suggest a break (and again every 20 minutes). */
    private fun breakCheck() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) { contPkg = null; return }
        val pkg = contPkg ?: return
        if (System.currentTimeMillis() - contSince >= 20 * 60_000L) {
            contSince = System.currentTimeMillis()
            val name = Limits.nameOf(this, pkg)
            Notifier.post(this, 4242, "Time for a break ⚠️", "You've been on $name for 20 minutes straight. Look away, stretch and drink some water.", "sleepy")
        }
    }

    /** One notification after 9 pm with the day's total and the streak. */
    private fun dailySummary(usage: Map<String, Long>) {
        if (Calendar.getInstance().get(Calendar.HOUR_OF_DAY) < 21) return
        val p = getSharedPreferences("meowtime", MODE_PRIVATE)
        if (p.getInt("sum_day", 0) == Limits.day()) return
        p.edit().putInt("sum_day", Limits.day()).apply()
        val over = Limits.tracked(this).any { (usage[it] ?: 0L) >= Limits.limitMin(this, it) }
        val s = Streak.current(this)
        Notifier.post(this, 99, if (over) "Rough day 💤" else "Nice day! ✅",
            "Today: ${Limits.hm(usage.values.sum())} on tracked apps." + if (s > 0) " 🔥 $s-day streak so far." else "",
            if (over) "sad" else "proud")
    }

    /** Sunday evening (7 pm on): this week's total, best day and phone pickups. */
    private fun weeklyReport() {
        val cal = Calendar.getInstance()
        if (cal.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY || cal.get(Calendar.HOUR_OF_DAY) < 19) return
        val p = getSharedPreferences("meowtime", MODE_PRIVATE)
        if (p.getInt("report_day", 0) == Limits.day()) return
        val totals = Limits.dayTotals(this)
        val best = totals.indices.minByOrNull { totals[it] } ?: 6
        val bestCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -(6 - best)) }
        val bestName = SimpleDateFormat("EEEE", Locale.getDefault()).format(bestCal.time)
        val pickups = Pickups.daily(this).sum()
        p.edit().putInt("report_day", Limits.day()).apply()
        Notifier.post(this, 77, "Your week in review 📊",
            "This week: ${Limits.hm(totals.sum())} on tracked apps (about ${Limits.hm(totals.sum() / 7)} a day). " +
            "Best day: $bestName with ${Limits.hm(totals[best])}. Phone pickups: $pickups. 🔥 Streak: ${Streak.current(this)}.", "")
    }

    /** One motivational quote a day, from 7 am. */
    private fun dailyQuote() {
        if (Calendar.getInstance().get(Calendar.HOUR_OF_DAY) < 7) return
        val p = getSharedPreferences("meowtime", MODE_PRIVATE)
        if (p.getInt("quote_day", 0) == Limits.day()) return
        p.edit().putInt("quote_day", Limits.day()).apply()
        Notifier.post(this, 88, "Today's motivation 💪", Quotes.today(), "")
    }

    /** Covers a tracked app that is out of time (or paused by Focus / Bedtime). Returns true when it blocked. */
    private fun enforce(pkg: String): Boolean {
        if (pkg == packageName || pkg !in Limits.tracked(this)) return false
        if (!Limits.isBlocked(this, pkg)) return false
        current = packageName
        if (!Focus.active(this) && !Bedtime.active(this)) {
            val name = Limits.nameOf(this, pkg)
            Notifier.post(this, pkg.hashCode(), "Enough screen time! ⏱", "$name is done for today. Go do some work or step outside.", "angry")
        }
        performGlobalAction(GLOBAL_ACTION_HOME)
        startActivity(Intent(this, BlockActivity::class.java)
            .putExtra("pkg", pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
        return true
    }
}
