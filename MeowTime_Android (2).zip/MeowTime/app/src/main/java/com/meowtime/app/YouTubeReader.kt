package com.meowtime.app

import android.view.accessibility.AccessibilityNodeInfo

/**
 * Reads the text YouTube shows on screen (video title and hashtags). It never records audio, takes
 * screenshots or looks at the video itself, and the text stays on the phone.
 *
 * YouTube does not promise what its screens contain, and an update can change it. When no title can be
 * found the answer is simply "no title" and the classifier returns UNKNOWN. If titles stop being found,
 * open Study > "What MeowTime read" while a video is playing and add the view id you see next to the
 * title to TITLE_IDS below.
 */
object YouTubeReader {
    /** View ids (the part after "id/") that normally hold the video title. Best effort: edit if YouTube changes. */
    val TITLE_IDS = listOf("video_title", "title")

    class Reading(val title: String?, val hashtags: List<String>, val isShort: Boolean)

    /** What the last read saw, for the "What MeowTime read" screen. Kept in memory only. */
    @Volatile var lastDump: String = "Nothing read yet. Start a study session and open a YouTube video."

    private val tagRe = Regex("#[\\p{L}\\p{N}_]{2,40}")
    private const val MAX_NODES = 400

    private class Item(val id: String, val text: String)

    fun read(root: AccessibilityNodeInfo): Reading {
        val items = ArrayList<Item>()
        var short = false
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.addLast(root)
        var seen = 0
        while (stack.isNotEmpty() && seen < MAX_NODES) {
            val n = stack.removeLast(); seen++
            if (!n.isVisibleToUser) continue
            val id = n.viewIdResourceName?.substringAfter("/") ?: ""
            if (id.contains("reel") || id.contains("shorts")) short = true
            val t = n.text?.toString()?.trim().orEmpty()
            val d = n.contentDescription?.toString()?.trim().orEmpty()
            if (t.isNotEmpty()) items.add(Item(id, t))
            if (d.isNotEmpty() && d != t) items.add(Item(id, d))
            for (i in n.childCount - 1 downTo 0) n.getChild(i)?.let { stack.addLast(it) }
        }
        // items are already in on-screen order; the title is the first node with a known title id
        val ordered: List<Item> = items
        val title = ordered.firstOrNull { it.id in TITLE_IDS && it.text.length >= 4 }?.text
        val tags = ordered.flatMap { tagRe.findAll(it.text).map { m -> m.value.lowercase() }.toList() }.distinct().take(8)
        lastDump = buildString {
            append("Title: ").append(title ?: "(not found)").append('\n')
            append("Hashtags: ").append(if (tags.isEmpty()) "(none)" else tags.joinToString(" ")).append("\n\n")
            ordered.take(50).forEach { append(it.id.ifEmpty { "-" }).append("  |  ").append(it.text.take(70)).append('\n') }
        }
        return Reading(title, tags, short)
    }
}
