package com.meowtime.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/**
 * Real home-screen widget. Widgets cannot run free animation, so petting plays a short sequence
 * of pictures (hearts rising) pushed one after another, then the widget goes back to normal.
 */
class MeowWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) = push(c, m, ids, null)

    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        if (i.action != ACTION_PET) return
        val pending = goAsync()
        val m = AppWidgetManager.getInstance(c)
        val ids = m.getAppWidgetIds(ComponentName(c, MeowWidget::class.java))
        Thread {
            try {
                for (p in floatArrayOf(.1f, .25f, .4f, .55f, .7f, .85f)) { push(c, m, ids, p); Thread.sleep(280) }
                push(c, m, ids, null)
            } finally { pending.finish() }
        }.start()
    }

    private fun push(c: Context, m: AppWidgetManager, ids: IntArray, progress: Float?) {
        val v = RemoteViews(c.packageName, R.layout.widget_cat)
        val mood = if (progress != null) "excited" else Mood.current(c)
        v.setImageViewBitmap(R.id.cat_img, CatArt.frame(c, CatArt.outfit(c), mood, progress))
        v.setTextViewText(R.id.bubble, if (progress != null) "Purr… 💗" else Mood.say.getValue(mood))
        if (progress == null) c.getSharedPreferences("meowtime", Context.MODE_PRIVATE).edit().putString("widget_mood", mood).apply()
        val pet = Intent(c, MeowWidget::class.java).setAction(ACTION_PET)
        v.setOnClickPendingIntent(R.id.cat_img, PendingIntent.getBroadcast(c, 0, pet, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        val open = Intent(c, MainActivity::class.java)
        v.setOnClickPendingIntent(R.id.bubble, PendingIntent.getActivity(c, 1, open, PendingIntent.FLAG_IMMUTABLE))
        m.updateAppWidget(ids, v)
    }

    companion object {
        const val ACTION_PET = "com.meowtime.app.PET"
        /** Cheap check the blocker service runs every few seconds: redraw only when the mood changed. */
        fun refreshIfChanged(c: Context) {
            val last = c.getSharedPreferences("meowtime", Context.MODE_PRIVATE).getString("widget_mood", null)
            if (Mood.current(c) != last) refresh(c)
        }

        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, MeowWidget::class.java))
            if (ids.isNotEmpty()) MeowWidget().onUpdate(c, m, ids)
        }
    }
}
