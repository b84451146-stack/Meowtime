package com.meowtime.app

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import java.util.Calendar

object Limits {
    const val MAX = 120   // 2 hours is the highest daily limit allowed, and the starting limit for every app
    const val EXTRA = 15  // one 15-minute extension per app per day, only once the limit is used up

    val apps = linkedMapOf(
        "Instagram" to "com.instagram.android",
        "YouTube" to "com.google.android.youtube",
        "Snapchat" to "com.snapchat.android",
        "Facebook" to "com.facebook.katana",
        "Reddit" to "com.reddit.frontpage"
    )

    private fun prefs(c: Context) = c.getSharedPreferences("meowtime", Context.MODE_PRIVATE)

    fun day(): Int = Calendar.getInstance().let { it.get(Calendar.YEAR) * 10000 + (it.get(Calendar.MONTH) + 1) * 100 + it.get(Calendar.DAY_OF_MONTH) }

    /** The saved daily limit. A raised limit that was requested on an earlier day is applied here. Stays the same every day. */
    fun baseMin(c: Context, pkg: String): Int {
        val p = prefs(c)
        val pend = p.getInt("pend_$pkg", -1)
        if (pend >= 0 && p.getInt("pend_day_$pkg", 0) != day())
            p.edit().putInt(pkg, pend).remove("pend_$pkg").remove("pend_day_$pkg").apply()
        return p.getInt(pkg, MAX).coerceIn(1, MAX)
    }

    fun extendedToday(c: Context, pkg: String) = prefs(c).getInt("ext_$pkg", 0) == day()

    /** Today's limit: the saved limit plus the one-time 15 minutes if it was used. */
    fun limitMin(c: Context, pkg: String): Int = baseMin(c, pkg) + if (extendedToday(c, pkg)) EXTRA else 0

    fun pendingMin(c: Context, pkg: String): Int? { baseMin(c, pkg); return prefs(c).getInt("pend_$pkg", -1).takeIf { it >= 0 } }

    /** The extension can be taken once per app per day, and only after the saved limit is used up. */
    fun canExtend(c: Context, pkg: String): Boolean =
        pkg in apps.values && !extendedToday(c, pkg) && usedMinutes(c, pkg) >= baseMin(c, pkg)

    fun extend(c: Context, pkg: String): Boolean {
        if (!canExtend(c, pkg)) return false
        prefs(c).edit().putInt("ext_$pkg", day()).apply()
        return true
    }

    /** Lowering a limit works at once. Raising it only starts tomorrow, so a block can't be dodged. Max is 2 hours. */
    fun setLimit(c: Context, pkg: String, wanted: Int): String {
        val min = wanted.coerceIn(1, MAX)
        val cur = baseMin(c, pkg)
        val e = prefs(c).edit()
        return if (min > cur) {
            e.putInt("pend_$pkg", min).putInt("pend_day_$pkg", day()).apply()
            "Higher limits start tomorrow, so you can't raise it to get more time today."
        } else {
            e.putInt(pkg, min).remove("pend_$pkg").remove("pend_day_$pkg").apply()
            "Limit set to $min min."
        }
    }

    fun hm(m: Long) = if (m >= 60) "${m / 60}h ${m % 60}m" else "${m}m"

    fun midnight(daysAgo: Int = 0): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        add(Calendar.DAY_OF_YEAR, -daysAgo)
    }.timeInMillis

    /** Minutes in the foreground per tracked app (one pass over the usage events). Default range is today. */
    fun usedAll(c: Context, start: Long = midnight(), end: Long = System.currentTimeMillis()): Map<String, Long> {
        val m = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val events = m.queryEvents(start, end)
        val e = UsageEvents.Event()
        val last = HashMap<String, Long>(); val total = HashMap<String, Long>()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val p = e.packageName
            if (p !in apps.values) continue
            when (e.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> last[p] = e.timeStamp
                UsageEvents.Event.MOVE_TO_BACKGROUND -> last.remove(p)?.let { total[p] = (total[p] ?: 0L) + (e.timeStamp - it) }
            }
        }
        for ((p, t) in last) total[p] = (total[p] ?: 0L) + (end - t)
        return total.mapValues { it.value / 60000 }
    }

    fun usedMinutes(c: Context, pkg: String): Long = usedAll(c)[pkg] ?: 0L

    /** Total tracked minutes for each of the last 7 days, oldest first (today is last). */
    fun dayTotals(c: Context): List<Long> = (6 downTo 0).map { d ->
        val start = midnight(d)
        val end = if (d == 0) System.currentTimeMillis() else start + 24 * 3600_000L
        usedAll(c, start, end).values.sum()
    }

    /** Blocked when the daily limit is used up, or while a Focus session is running. */
    fun isBlocked(c: Context, pkg: String): Boolean {
        if (pkg !in apps.values) return false
        if (Focus.active(c)) return true
        val limit = limitMin(c, pkg)
        return limit > 0 && usedMinutes(c, pkg) >= limit
    }

    fun clock(ms: Long): String { val s = (ms / 1000).coerceAtLeast(0); return "%02d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60) }

    fun millisUntilReset(): Long = midnight() + 24 * 3600_000L - System.currentTimeMillis()
}
