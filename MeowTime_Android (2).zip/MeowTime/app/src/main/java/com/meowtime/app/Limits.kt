package com.meowtime.app

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import java.util.Calendar

object Limits {
    val apps = linkedMapOf(
        "Instagram" to "com.instagram.android",
        "YouTube" to "com.google.android.youtube",
        "Snapchat" to "com.snapchat.android",
        "Facebook" to "com.facebook.katana",
        "Reddit" to "com.reddit.frontpage"
    )
    private val defaults = mapOf(
        "com.instagram.android" to 20, "com.google.android.youtube" to 30,
        "com.snapchat.android" to 15, "com.facebook.katana" to 10, "com.reddit.frontpage" to 20
    )

    private fun prefs(c: Context) = c.getSharedPreferences("meowtime", Context.MODE_PRIVATE)
    fun limitMin(c: Context, pkg: String) = prefs(c).getInt(pkg, defaults[pkg] ?: 30)
    fun setLimit(c: Context, pkg: String, min: Int) = prefs(c).edit().putInt(pkg, min).apply()

    private fun midnight(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    /** Minutes in the foreground since local midnight. The count restarts by itself each day. */
    fun usedMinutes(c: Context, pkg: String): Long {
        val m = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val events = m.queryEvents(midnight(), now)
        val e = UsageEvents.Event()
        var last = 0L; var total = 0L
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.packageName != pkg) continue
            when (e.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> last = e.timeStamp
                UsageEvents.Event.MOVE_TO_BACKGROUND -> if (last > 0) { total += e.timeStamp - last; last = 0 }
            }
        }
        if (last > 0) total += now - last
        return total / 60000
    }

    fun isBlocked(c: Context, pkg: String): Boolean {
        if (pkg !in apps.values) return false
        val limit = limitMin(c, pkg)
        return limit > 0 && usedMinutes(c, pkg) >= limit
    }

    fun millisUntilReset(): Long = midnight() + 24 * 3600_000L - System.currentTimeMillis()
}
