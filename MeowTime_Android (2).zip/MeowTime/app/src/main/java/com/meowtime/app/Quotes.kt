package com.meowtime.app

/** Short motivational lines, one per day (picked by the date so it changes daily). */
object Quotes {
    val all = listOf(
        "Small steps every day add up to big change.",
        "Your future self is watching. Make them proud.",
        "Less scrolling, more living.",
        "Focus on progress, not perfection.",
        "One hour of focus beats five hours of distraction.",
        "You don't need more time. You need more focus.",
        "Do it now. Future you says thanks.",
        "Discipline is choosing what you want most over what you want now.",
        "The best time to start was yesterday. The next best is now.",
        "Your goals are waiting. Put the phone down and go get them.",
        "Be present. This moment is the only one you get.",
        "Tiny habits build a big life.",
        "Rest your eyes, clear your mind, then crush your day.",
        "Every minute you save is a minute you can spend on what matters.",
        "Consistency beats motivation. Show up anyway.",
        "You are in control of your time, not the other way round.",
        "Study now, celebrate later.",
        "A streak is just a lot of good days in a row. Keep going.",
        "Progress feels slow until you look back.",
        "Win the morning, win the day."
    )

    fun today(): String = all[Limits.day() % all.size]
}
