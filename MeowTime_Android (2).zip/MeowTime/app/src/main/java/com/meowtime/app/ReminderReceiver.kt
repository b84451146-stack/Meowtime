package com.meowtime.app

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Handles the buttons on the study reminder notification. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        when (i.action) {
            ACTION_FIX -> Study.correct(c, Study.Last.title, Classifier.Label.EDUCATIONAL)   // "this is study-related"
            ACTION_DISMISS -> {}
        }
        Study.markReminded(c, snoozeMin = 10)   // stay quiet for a while after any answer
        (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(Notifier.ID_STUDY)
    }
    companion object {
        const val ACTION_FIX = "com.meowtime.app.STUDY_FIX"
        const val ACTION_DISMISS = "com.meowtime.app.STUDY_DISMISS"
    }
}
