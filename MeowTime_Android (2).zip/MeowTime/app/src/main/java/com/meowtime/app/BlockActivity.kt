package com.meowtime.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class BlockActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pkg = intent.getStringExtra("pkg") ?: ""
        val name = Limits.apps.entries.firstOrNull { it.value == pkg }?.key ?: "This app"
        val mins = Limits.usedMinutes(this, pkg)
        val ms = Limits.millisUntilReset()
        fun tv(t: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply {
            text = t; textSize = size; setTextColor(color); gravity = Gravity.CENTER; setPadding(0, 16, 0, 16)
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0F1030")); setPadding(48, 48, 48, 48)
            addView(tv("🙀", 72f))
            addView(tv("$name limit reached", 24f))
            addView(tv("You spent $mins minutes on $name today.", 16f, Color.parseColor("#C9B8FF")))
            addView(tv("Take a break with me. Tomorrow is a fresh start. 💜", 16f))
            addView(tv("Resets in ${ms / 3600000}h ${ms % 3600000 / 60000}m", 14f, Color.parseColor("#A9A8D6")))
            addView(Button(this@BlockActivity).apply {
                text = "Back to MeowTime"
                setOnClickListener {
                    startActivity(Intent(this@BlockActivity, MainActivity::class.java)); finish()
                }
            })
        })
    }

    @Deprecated("Back goes home so the blocked app stays covered")
    override fun onBackPressed() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
}
