package com.meowtime.app

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * "Open Instagram?" The 10-second pause shown when a tracked app is opened. While the student waits, a
 * quick alternative (breathing, a stretch or a puzzle) is offered. They can still open the app after the
 * wait, so they stay in control; the pause just makes the automatic habit visible.
 */
class PauseActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val anims = mutableListOf<ValueAnimator>()
    private var pkg = ""
    private var name = ""
    private var kind = (0..2).random()
    private var left = Pause.WAIT_SEC
    private var decided = false
    private lateinit var openBtn: Button
    private lateinit var box: LinearLayout

    private val BG = Color.parseColor("#0D0F26")
    private val SURF = Color.parseColor("#181B3D")
    private val MUTED = Color.parseColor("#9C9AC8")
    private val TEAL = Color.parseColor("#1FD1B5")
    private val PURPLE = Color.parseColor("#9B7DFF")

    private val puzzles = listOf(
        "What comes next?  2, 4, 8, 16, ?" to "32",
        "What is 15 × 4?" to "60",
        "What comes next?  1, 1, 2, 3, 5, ?" to "8",
        "I have hands but can't clap. What am I? (one word)" to "clock",
        "What is 100 − 37?" to "63",
        "What comes next?  3, 6, 9, 12, ?" to "15"
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        build()
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); setIntent(i); recreate() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(6))
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun build() {
        handler.removeCallbacksAndMessages(null); anims.forEach { it.cancel() }; anims.clear()
        pkg = intent.getStringExtra("pkg") ?: ""
        name = Limits.nameOf(this, pkg)
        left = Pause.WAIT_SEC; decided = false
        val used = Limits.usedMinutes(this, pkg); val lim = Limits.limitMin(this, pkg)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(BG); setPadding(dp(24), dp(40), dp(24), dp(24))
        }
        col.addView(tv("⏸", 56f))
        col.addView(tv("Open $name?", 28f, Color.WHITE, true))
        col.addView(tv("Most opening is automatic. Take a moment first.", 15f, MUTED))
        col.addView(tv("Today: ${Limits.hm(used)} of ${Limits.hm(lim.toLong())} used", 14f, Color.parseColor("#C9B8FF")))

        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            background = GradientDrawable().apply { setColor(SURF); cornerRadius = dp(24).toFloat() }
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        col.addView(box, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        render()

        col.addView(Button(this).apply {
            text = "Try something else"; isAllCaps = false
            setOnClickListener { kind = (kind + 1) % 3; render() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        openBtn = Button(this).apply {
            isAllCaps = false; isEnabled = false; text = "Open $name anyway ($left)"
            setOnClickListener { openApp() }
        }
        col.addView(openBtn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        col.addView(Button(this).apply {
            text = "Not now"; isAllCaps = false
            setOnClickListener { skip() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

        setContentView(ScrollView(this).apply { setBackgroundColor(BG); addView(col) })

        restartWait()
    }

    // ---- the quick alternatives ----
    private fun render() {
        handler.removeCallbacksAndMessages(null)   // stops the breathing / timer loops; the open-wait tick is restarted below
        anims.forEach { it.cancel() }; anims.clear()
        box.removeAllViews()
        when (kind) { 0 -> breathing(); 1 -> stretch(); else -> puzzle() }
        if (::openBtn.isInitialized && left > 0) restartWait()
    }

    private fun restartWait() {
        val tick = object : Runnable {
            override fun run() {
                left--
                if (left <= 0) { openBtn.isEnabled = true; openBtn.text = "Open $name anyway" }
                else { openBtn.text = "Open $name anyway ($left)"; handler.postDelayed(this, 1000) }
            }
        }
        handler.postDelayed(tick, 1000)
    }

    private fun breathing() {
        box.addView(tv("🫁 Breathe", 18f, Color.WHITE, true))
        val circle = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(TEAL) }
            scaleX = 0.7f; scaleY = 0.7f
        }
        box.addView(circle, LinearLayout.LayoutParams(dp(110), dp(110)).apply { topMargin = dp(12); bottomMargin = dp(12) })
        val label = tv("Breathe in…", 16f, TEAL, true)
        box.addView(label)
        val a = ObjectAnimator.ofPropertyValuesHolder(circle, PropertyValuesHolder.ofFloat("scaleX", 0.7f, 1.25f), PropertyValuesHolder.ofFloat("scaleY", 0.7f, 1.25f))
            .apply { duration = 4000; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE; start() }
        anims.add(a)
        var inhale = true
        val flip = object : Runnable {
            override fun run() { inhale = !inhale; label.text = if (inhale) "Breathe in…" else "Breathe out…"; handler.postDelayed(this, 4000) }
        }
        handler.postDelayed(flip, 4000)
    }

    private fun stretch() {
        box.addView(tv("🧘 A 2-minute stretch", 18f, Color.WHITE, true))
        box.addView(tv("1. Roll your shoulders back 5 times\n2. Look at something far away for 20 seconds\n3. Reach both arms overhead and hold for 10 seconds\n4. Slowly turn your neck left, then right\n5. Take 3 deep breaths", 15f, Color.parseColor("#E4E2FF")).apply { gravity = Gravity.START })
        val timer = tv("2:00", 28f, PURPLE, true)
        val btn = Button(this).apply { text = "Start 2-minute timer"; isAllCaps = false }
        var running = false
        btn.setOnClickListener {
            if (running) return@setOnClickListener
            running = true; btn.isEnabled = false
            var s = 120
            val t = object : Runnable {
                override fun run() {
                    s--
                    timer.text = "%d:%02d".format(s / 60, s % 60)
                    if (s <= 0) { timer.text = "Nice! 🎉"; return }
                    handler.postDelayed(this, 1000)
                }
            }
            handler.postDelayed(t, 1000)
        }
        box.addView(timer); box.addView(btn)
    }

    private fun puzzle() {
        val (q, a) = puzzles.random()
        box.addView(tv("🧩 Quick puzzle", 18f, Color.WHITE, true))
        box.addView(tv(q, 17f, Color.parseColor("#E4E2FF")))
        val input = EditText(this).apply {
            hint = "Your answer"; setTextColor(Color.WHITE); setHintTextColor(MUTED); inputType = InputType.TYPE_CLASS_TEXT; gravity = Gravity.CENTER
        }
        val result = tv("", 15f, TEAL, true)
        val check = Button(this).apply {
            text = "Check"; isAllCaps = false
            setOnClickListener {
                result.text = if (input.text.toString().trim().equals(a, ignoreCase = true)) "Correct! 🎉 Your brain is warmed up." else "Not quite. Try again, or tap \"Try something else\"."
            }
        }
        box.addView(input, LinearLayout.LayoutParams(-1, -2)); box.addView(check); box.addView(result)
    }

    // ---- choices ----
    private fun openApp() {
        if (decided) return
        decided = true
        Pause.recordOpened(this)
        Pause.allow(this, pkg)
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        else Toast.makeText(this, "Couldn't open $name.", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun skip() {
        if (decided) return
        decided = true
        Pause.recordSkipped(this)
        Toast.makeText(this, "Nice choice. 👍", Toast.LENGTH_SHORT).show()
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }

    @Deprecated("Back counts as \"Not now\"")
    override fun onBackPressed() { skip() }

    override fun onDestroy() { handler.removeCallbacksAndMessages(null); anims.forEach { it.cancel() }; super.onDestroy() }
}
