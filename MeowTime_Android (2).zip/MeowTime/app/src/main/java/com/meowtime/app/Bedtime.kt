package com.meowtime.app

import android.content.Context
import java.util.Calendar

/** Overnight lock: every tracked app is blocked between the start and end time. Can't be changed while it is active. */
object Bedtime {
    private fun p(c: Context) = c.getSharedPreferences("meowtime", Context.MODE_PRIVATE)
    fun enabled(c: Context) = p(c).getBoolean("bed_on", false)
    fun startMin(c: Context) = p(c).getInt("bed_start", 23 * 60)
    fun endMin(c: Context) = p(c).getInt("bed_end", 6 * 60)
    fun setEnabled(c: Context, on: Boolean) = p(c).edit().putBoolean("bed_on", on).apply()
    fun setStart(c: Context, m: Int) = p(c).edit().putInt("bed_start", m).apply()
    fun setEnd(c: Context, m: Int) = p(c).edit().putInt("bed_end", m).apply()
    fun fmt(m: Int) = "%02d:%02d".format(m / 60, m % 60)

    private fun nowMin(): Int = Calendar.getInstance().let { it.get(Calendar.HOUR_OF_DAY) * 60 + it.get(Calendar.MINUTE) }

    fun active(c: Context): Boolean {
        if (!enabled(c)) return false
        val now = nowMin(); val s = startMin(c); val e = endMin(c)
        if (s == e) return false
        return if (s < e) now in s until e else now >= s || now < e
    }

    /** Milliseconds until the lock ends (only meaningful while active). */
    fun msUntilEnd(c: Context): Long {
        val cal = Calendar.getInstance()
        val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        var diff = endMin(c) - now
        if (diff <= 0) diff += 1440
        return (diff * 60_000L - cal.get(Calendar.SECOND) * 1000L).coerceAtLeast(1000L)
    }

    /** Length of the whole lock window in milliseconds. */
    fun spanMs(c: Context): Long {
        var d = endMin(c) - startMin(c)
        if (d <= 0) d += 1440
        return d * 60_000L
    }
}
