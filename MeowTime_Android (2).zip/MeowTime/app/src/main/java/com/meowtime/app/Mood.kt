package com.meowtime.app

import android.content.Context

/** The cat's mood, worked out from today's real usage unless a mood is being previewed or set by an event. */
object Mood {
    val all = listOf("happy", "excited", "worried", "sleepy", "sad", "proud", "study")
    val say = mapOf(
        "happy" to "Nice balance today! 😸", "excited" to "Study done! Let's celebrate! 😻",
        "worried" to "A limit is close… 🙀", "sleepy" to "So much scrolling… 😴",
        "sad" to "Rough day? Tomorrow is fresh. 😿", "proud" to "Goal reached! 🥳", "study" to "Shh… reading time 📚"
    )
    private fun prefs(c: Context) = c.getSharedPreferences("meowtime", Context.MODE_PRIVATE)

    /** Force a mood for a while, for example "study" during a focus session or "excited" after one. */
    fun override(c: Context, mood: String, ms: Long) =
        prefs(c).edit().putString("mood_o", mood).putLong("mood_until", System.currentTimeMillis() + ms).apply()

    fun current(c: Context): String {
        val p = prefs(c)
        if (System.currentTimeMillis() < p.getLong("mood_until", 0)) return p.getString("mood_o", "happy")!!
        return try {
            var total = 0L; var near = false
            for (pkg in Limits.apps.values) {
                val used = Limits.usedMinutes(c, pkg); val lim = Limits.limitMin(c, pkg)
                total += used
                if (lim > 0 && used >= lim) return "sad"
                if (lim > 0 && used >= lim * 0.8) near = true
            }
            if (near) "worried" else if (total >= 90) "sleepy" else "happy"
        } catch (e: SecurityException) { "happy" }   // Usage Access not granted yet
    }
}
