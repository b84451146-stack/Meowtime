OFFGRID YouTube 3-hour category policy patch

This source patch changes the YouTube daily cap to 180 minutes and disables the extra-time extension for YouTube. After the cap, the accessibility service attempts to read the currently visible YouTube title/hashtags and classify them using the existing offline keyword classifier. Only EDUCATIONAL is allowed; ENTERTAINMENT, MIXED, UNKNOWN, and unreadable titles are blocked. Focus and Bedtime continue to override the exception.

Important limitations: classification depends on YouTube exposing a readable title in its accessibility tree and on the existing keyword list. It does not inspect video/audio content. If YouTube changes its UI or the title is unavailable, the safe fallback is UNKNOWN (blocked). Test on-device before relying on this.
