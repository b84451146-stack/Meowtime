package com.meowtime.app

import android.content.Context
import android.graphics.*

/** Cat artwork. Banana is the default; the rest are outfits. Every outfit has a picture for every mood. */
object CatArt {
    // mx = horizontal centre between the eyes, ey = eye height (fractions of the picture)
    class Info(val mx: Float, val ey: Float)
    val outfits = linkedMapOf(
        "nightcat" to Info(0.441f, 0.485f),
        "banana" to Info(0.441f, 0.485f),
        "watermelon" to Info(0.416f, 0.494f),
        "fire" to Info(0.480f, 0.537f),
        "strawberry" to Info(0.392f, 0.375f),
        "grape" to Info(0.441f, 0.485f),
        "dragonfruit" to Info(0.416f, 0.494f),
        "blueberry" to Info(0.392f, 0.375f),
        "iceflame" to Info(0.480f, 0.537f)
    )

    /** Streak days needed to unlock each outfit (best streak counts, so a broken streak never locks one again). */
    val unlockAt = mapOf(
        "nightcat" to 0, "banana" to 0, "watermelon" to 3, "strawberry" to 5, "grape" to 7,
        "fire" to 10, "blueberry" to 14, "dragonfruit" to 21, "iceflame" to 30
    )
    fun label(n: String) = when (n) { "iceflame" -> "Ice flame"; "nightcat" -> "Night cat"; else -> n.replaceFirstChar { it.uppercase() } }
    fun unlocked(c: Context, n: String) = Streak.best(c) >= (unlockAt[n] ?: 0)

    private fun prefs(c: Context) = c.getSharedPreferences("meowtime", Context.MODE_PRIVATE)
    fun outfit(c: Context): String = prefs(c).getString("outfit", "nightcat")!!.takeIf { it in outfits } ?: "nightcat"
    fun setOutfit(c: Context, name: String) = prefs(c).edit().putString("outfit", name).apply()

    fun bitmap(c: Context, name: String, mood: String): Bitmap {
        val id = c.resources.getIdentifier("cat_${name}_$mood", "drawable", c.packageName)
        return BitmapFactory.decodeResource(c.resources, id)
    }

    private val heart = Paint(Paint.ANTI_ALIAS_FLAG)
    private val colors = intArrayOf(0xFFFF7AA8.toInt(), 0xFFFF5C93.toInt(), 0xFFFFB8DA.toInt(), 0xFFFF9EC4.toInt(), 0xFFFF5C93.toInt())

    /** Small hearts rising from the top of the head. progress goes 0..1. */
    fun drawHearts(canvas: Canvas, w: Float, h: Float, name: String, progress: Float) {
        val info = outfits.getValue(name)
        for (i in 0 until 5) {
            val p = (progress * 1.3f - i * 0.08f).coerceIn(0f, 1f)
            if (p <= 0f || p >= 1f) continue
            heart.color = colors[i]
            heart.alpha = ((if (p < .2f) p / .2f else 1f - (p - .2f) / .8f) * 255).toInt().coerceIn(0, 255)
            heart.textSize = w * (0.07f + 0.02f * (i % 3))
            canvas.drawText("♥", info.mx * w + (i - 2) * w * 0.09f, (info.ey - 0.17f) * h - p * h * 0.2f, heart)
        }
    }

    /** One finished picture for the widget (cat in this mood, plus hearts at this point of the animation). */
    fun frame(c: Context, name: String, mood: String, progress: Float?): Bitmap {
        val bmp = bitmap(c, name, mood).copy(Bitmap.Config.ARGB_8888, true)
        if (progress != null) drawHearts(Canvas(bmp), bmp.width.toFloat(), bmp.height.toFloat(), name, progress)
        return bmp
    }
}
