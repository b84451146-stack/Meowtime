package com.meowtime.app

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.animation.OvershootInterpolator
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** The pop-up shown when a blocked app is opened: an angry cat when the limit is used up, a studying cat during Focus. */
class BlockActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pkg = intent.getStringExtra("pkg") ?: ""
        val name = Limits.apps.entries.firstOrNull { it.value == pkg }?.key ?: "This app"
        val focus = Focus.active(this)
        val mins = Limits.usedMinutes(this, pkg)
        val ms = Limits.millisUntilReset()
        val d = resources.displayMetrics.density
        fun tv(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = size; setTextColor(color); gravity = Gravity.CENTER; setPadding(0, 16, 0, 16)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val cat = ImageView(this).apply {
            setImageBitmap(CatArt.bitmap(this@BlockActivity, CatArt.outfit(this@BlockActivity), if (focus) "study" else "angry"))
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0F1030")); setPadding(48, 48, 48, 48)
            addView(cat, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (260 * d).toInt()))
            addView(tv(if (focus) "Focus time!" else "Enough screen time!", 28f, Color.WHITE, true))
            addView(tv(if (focus) "$name is paused until your session ends." else "$name limit reached · $mins min today", 16f, Color.parseColor("#C9B8FF")))
            addView(tv(if (focus) "Eyes on your work. You've got this! 📚" else "Go do some work, study or step outside. I'm watching you 😾", 17f))
            if (!focus) addView(tv("Resets in ${ms / 3600000}h ${ms % 3600000 / 60000}m", 14f, Color.parseColor("#A9A8D6")))
            if (!focus && Limits.canExtend(this@BlockActivity, pkg)) addView(Button(this@BlockActivity).apply {
                text = "+${Limits.EXTRA} min (once today)"
                setOnClickListener {
                    if (Limits.extend(this@BlockActivity, pkg)) Toast.makeText(this@BlockActivity, "+${Limits.EXTRA} minutes. Use them wisely! 😼", Toast.LENGTH_LONG).show()
                    onBackPressed()
                }
            })
            addView(Button(this@BlockActivity).apply {
                text = "Back to MeowTime"
                setOnClickListener { startActivity(Intent(this@BlockActivity, MainActivity::class.java)); finish() }
            })
        })
        // the cat pops in; an angry cat shakes, then everyone bobs gently
        cat.alpha = 0f; cat.scaleX = 0.6f; cat.scaleY = 0.6f
        cat.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(500).setInterpolator(OvershootInterpolator()).start()
        if (!focus) ObjectAnimator.ofFloat(cat, "rotation", 0f, -5f, 5f, -5f, 5f, -3f, 3f, 0f).apply { startDelay = 450; duration = 650 }.start()
        ObjectAnimator.ofFloat(cat, "translationY", 0f, -12 * d).apply {
            startDelay = 1200; duration = 1300; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
        }.start()
    }

    @Deprecated("Back goes home so the blocked app stays covered")
    override fun onBackPressed() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
}
