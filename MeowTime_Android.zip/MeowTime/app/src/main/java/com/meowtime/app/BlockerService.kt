package com.meowtime.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.accessibility.AccessibilityEvent
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Android does not let an app force-close another app. Instead, when a limited app comes to the
 * front, this service sends the user to the home screen and opens OFFGRID's break screen.
 * It also runs the small background jobs: 80% warnings, the streak check, break reminders and the 9 pm summary.
 */
class BlockerService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var current: String? = null
    private var contPkg: String? = null      // tracked app the user has been in without leaving
    private var contSince = 0L

    private val poll = object : Runnable {
        override fun run() {
            // Catches the moment a limit is reached while the app is already open.
            current?.let { enforce(it) }
            Focus.finishIfDone(this@BlockerService)
            try {
                val usage = Limits.usedAll(this@BlockerService)
                Notifier.checkWarnings(this@BlockerService, usage)
                Streak.update(this@BlockerService)
                dailySummary(usage)
                dailyQuote()
                weeklyReport()
            } catch (e: SecurityException) {}
            breakCheck()
            handler.postDelayed(this, 10_000)
        }
    }

    override fun onServiceConnected() { handler.post(poll) }
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); super.onDestroy() }
    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        current = pkg
        if (pkg in Limits.apps.values) {
            if (contPkg != pkg) { contPkg = pkg; contSince = System.currentTimeMillis() }
        } else if (!pkg.contains("inputmethod") && !pkg.contains("keyboard") && pkg != "com.android.systemui") {
            contPkg = null   // the user left for something else
        }
        enforce(pkg)
    }

    /** After 20 minutes in one tracked app without leaving, suggest a break (and again every 20 minutes). */
    private fun breakCheck() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) { contPkg = null; return }
        val pkg = contPkg ?: return
        if (System.currentTimeMillis() - contSince >= 20 * 60_000L) {
            contSince = System.currentTimeMillis()
            val name = Limits.apps.entries.firstOrNull { it.value == pkg }?.key ?: "this app"
            Notifier.post(this, 4242, "Time for a break ⚠️", "You've been on $name for 20 minutes straight. Look away, stretch and drink some water.", "sleepy")
        }
    }

    /** One notification after 9 pm with the day's total and the streak. */
    private fun dailySummary(usage: Map<String, Long>) {
        if (Calendar.getInstance().get(Calendar.HOUR_OF_DAY) < 21) return
        val p = getSharedPreferences("meowtime", MODE_PRIVATE)
        if (p.getInt("sum_day", 0) == Limits.day()) return
        p.edit().putInt("sum_day", Limits.day()).apply()
        val over = Limits.apps.values.any { (usage[it] ?: 0L) >= Limits.limitMin(this, it) }
        val s = Streak.current(this)
        Notifier.post(this, 99, if (over) "Rough day 💤" else "Nice day! ✅",
            "Today: ${Limits.hm(usage.values.sum())} on tracked apps." + if (s > 0) " 🔥 $s-day streak so far." else "",
            if (over) "sad" else "proud")
    }

    /** Sunday evening (7 pm on): this week's total, best day and phone pickups. */
    private fun weeklyReport() {
        val cal = Calendar.getInstance()
        if (cal.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY || cal.get(Calendar.HOUR_OF_DAY) < 19) return
        val p = getSharedPreferences("meowtime", MODE_PRIVATE)
        if (p.getInt("report_day", 0) == Limits.day()) return
        val totals = Limits.dayTotals(this)
        val best = totals.indices.minByOrNull { totals[it] } ?: 6
        val bestCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -(6 - best)) }
        val bestName = SimpleDateFormat("EEEE", Locale.getDefault()).format(bestCal.time)
        val pickups = Pickups.daily(this).sum()
        p.edit().putInt("report_day", Limits.day()).apply()
        Notifier.post(this, 77, "Your week in review 📊",
            "This week: ${Limits.hm(totals.sum())} on tracked apps (about ${Limits.hm(totals.sum() / 7)} a day). " +
            "Best day: $bestName with ${Limits.hm(totals[best])}. Phone pickups: $pickups. 🔥 Streak: ${Streak.current(this)}.", "")
    }

    /** One motivational quote a day, from 7 am. */
    private fun dailyQuote() {
        if (Calendar.getInstance().get(Calendar.HOUR_OF_DAY) < 7) return
        val p = getSharedPreferences("meowtime", MODE_PRIVATE)
        if (p.getInt("quote_day", 0) == Limits.day()) return
        p.edit().putInt("quote_day", Limits.day()).apply()
        Notifier.post(this, 88, "Today's motivation 💪", Quotes.today(), "")
    }

    private fun enforce(pkg: String) {
        if (pkg == packageName || pkg !in Limits.apps.values) return
        if (!Limits.isBlocked(this, pkg)) return
        current = packageName
        if (!Focus.active(this) && !Bedtime.active(this)) {
            val name = Limits.apps.entries.firstOrNull { it.value == pkg }?.key ?: "This app"
            Notifier.post(this, pkg.hashCode(), "Enough screen time! ⏱", "$name is done for today. Go do some work or step outside.", "angry")
        }
        performGlobalAction(GLOBAL_ACTION_HOME)
        startActivity(Intent(this, BlockActivity::class.java)
            .putExtra("pkg", pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
    }
}
