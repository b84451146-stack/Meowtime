package com.meowtime.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/** A round progress ring with text in the middle. */
class RingView(c: Context) : View(c) {
    var frac = 0f; var color = 0xFF7A5AE0.toInt(); var label = ""; var sub = ""
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFFE3DDFB.toInt() }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val t1 = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; color = 0xFF1D1B3A.toInt(); isFakeBoldText = true }
    private val t2 = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; color = 0xFF8A87B0.toInt() }
    private val r = RectF()

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val s = w * 0.11f
        track.strokeWidth = s; arc.strokeWidth = s; arc.color = color
        r.set(s, s, w - s, height - s)
        canvas.drawArc(r, 0f, 360f, false, track)
        canvas.drawArc(r, -90f, 360f * frac.coerceIn(0f, 1f), false, arc)
        t1.textSize = w * 0.26f; t2.textSize = w * 0.11f
        canvas.drawText(label, w / 2, height / 2f + t1.textSize * 0.3f, t1)
        canvas.drawText(sub, w / 2, height / 2f + t1.textSize * 0.3f + t2.textSize * 1.5f, t2)
    }
}
