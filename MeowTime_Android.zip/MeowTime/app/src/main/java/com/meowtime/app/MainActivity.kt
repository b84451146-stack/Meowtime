package com.meowtime.app

import android.animation.Animator
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.Manifest
import android.app.AppOpsManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.text.InputType
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    // ---- colours: a dark "night brick" navy with bright toy-brick accents ----
    private val BG = Color.parseColor("#F4F5FF")
    private val INK = Color.parseColor("#1D1B3A")
    private val MUTED = Color.parseColor("#7F7CA8")
    private val NAVY = Color.parseColor("#14163F")
    private val INDIGO = Color.parseColor("#4338B8")
    private val PURPLE = Color.parseColor("#7A5AE0")
    private val BLUE = Color.parseColor("#2F7BFF")
    private val TEAL = Color.parseColor("#14B8A0")
    private val YELLOW = Color.parseColor("#FFC93C")
    private val ORANGE = Color.parseColor("#FF8A2B")
    private val PINK = Color.parseColor("#E0457B")
    private val RED = Color.parseColor("#F0475A")
    private val GREEN = Color.parseColor("#2FC77B")
    private val LAV = Color.parseColor("#EFEAFF")
    private val LINE = Color.parseColor("#E3DDFB")
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private var tab = 0
    private var onboardPage = 0
    private lateinit var content: FrameLayout
    private lateinit var nav: LinearLayout
    private val loops = mutableListOf<Animator>()
    private val handler = Handler(Looper.getMainLooper())
    private var focusMin = 25

    private fun prefs() = getSharedPreferences("meowtime", MODE_PRIVATE)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        content = FrameLayout(this)
        nav = LinearLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(nav, LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(root)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() {
        super.onResume()
        try { Streak.update(this) } catch (e: Exception) {}
        show()
    }
    override fun onPause() { super.onPause(); stopLoops() }
    private fun stopLoops() { loops.forEach { it.cancel() }; loops.clear(); handler.removeCallbacksAndMessages(null) }

    // ---------- permissions ----------
    private fun usageGranted(): Boolean {
        val ops = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }
    private fun blockerOn(): Boolean =
        Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains("$packageName/.BlockerService") == true

    // ---------- small view helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tint(color: Int, alpha: Int) = (color and 0x00FFFFFF) or (alpha shl 24)
    private fun onColor(color: Int) = if (Color.luminance(color) > 0.5f) INK else Color.WHITE
    private fun bg(color: Int, r: Int, stroke: Int = 0, sw: Int = 1) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(sw), stroke)
    }
    private fun darken(c: Int) = Color.rgb((Color.red(c) * 0.8f).toInt(), (Color.green(c) * 0.8f).toInt(), (Color.blue(c) * 0.8f).toInt())
    private fun gradient(c1: Int, c2: Int, r: Int) = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2)).apply { cornerRadius = dp(r).toFloat() }
    private fun text(t: CharSequence, sp: Float, color: Int = INK, bold: Boolean = false, spacing: Float = 0f) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(color); letterSpacing = spacing; if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun card(fill: Int = Color.WHITE) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = bg(fill, 28, LINE); setPadding(dp(20), dp(20), dp(20), dp(20))
    }
    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(top) }
    private fun page() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(16), dp(20), dp(24)) }
    private fun hm(m: Long) = Limits.hm(m)

    /** Little round brick studs, a decoration for cards. */
    private fun studs(color: Int, n: Int = 4): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        repeat(n) {
            addView(View(this@MainActivity).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(tint(color, 0x77)) }
            }, LinearLayout.LayoutParams(dp(12), dp(12)).apply { rightMargin = dp(6) })
        }
    }

    private fun pill(label: String, color: Int) = text(label, 14f, color, true).apply {
        background = bg(tint(color, 0x28), 20); setPadding(dp(14), dp(6), dp(14), dp(6))
    }

    private fun button(label: String, filled: Boolean, color: Int = PURPLE, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 15f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (filled) onColor(color) else color)
        background = if (filled) gradient(color, darken(color), 24) else bg(Color.WHITE, 24, color, 2)
        setPadding(dp(20), dp(12), dp(20), dp(12))
        setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }
        setOnClickListener { onClick() }
    }

    /** Green while there is lots of time, then yellow, orange and red as the limit gets close. */
    private fun barColor(frac: Float) = when { frac < 0.6f -> GREEN; frac < 0.8f -> YELLOW; frac < 1f -> ORANGE; else -> RED }

    /** A progress bar that fills up with an animation. */
    private fun bar(frac: Float, color: Int, track: Int = LINE): View {
        val tr = FrameLayout(this).apply { background = bg(track, 8) }
        val fill = View(this).apply { background = bg(color, 8) }
        tr.addView(fill, FrameLayout.LayoutParams(0, MATCH))
        tr.post {
            ValueAnimator.ofInt(0, (tr.width * frac.coerceIn(0f, 1f)).toInt()).apply {
                duration = 800; startDelay = 150
                addUpdateListener { (fill.layoutParams as FrameLayout.LayoutParams).width = it.animatedValue as Int; fill.requestLayout() }
            }.start()
        }
        return tr
    }

    private fun span(a: String, b: String) = SpannableString(a + b).apply {
        setSpan(ForegroundColorSpan(PURPLE), a.length, a.length + b.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    private fun stagger(col: ViewGroup) {
        for (i in 0 until col.childCount) {
            val v = col.getChildAt(i)
            v.alpha = 0f; v.translationY = dp(24).toFloat()
            v.animate().alpha(1f).translationY(0f).setStartDelay(i * 70L).setDuration(380).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun appColor(pkg: String) = when (pkg) {
        "com.instagram.android" -> Color.parseColor("#E1306C")
        "com.google.android.youtube" -> Color.parseColor("#F03A3A")
        "com.snapchat.android" -> Color.parseColor("#F5B800")
        "com.facebook.katana" -> Color.parseColor("#1877F2")
        else -> Color.parseColor("#FF5700")
    }

    // ---------- screens ----------
    private fun show() {
        stopLoops()
        content.removeAllViews()
        if (!prefs().getBoolean("onboarded", false)) {
            nav.visibility = View.GONE
            val col = onboarding()
            content.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(col) })
            stagger(col)
            return
        }
        nav.visibility = View.VISIBLE
        val col = when (tab) { 0 -> home(); 1 -> limits(); 2 -> focus(); 3 -> insights(); else -> rewards() }
        content.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(col) })
        stagger(col)
        buildNav()
    }

    private fun buildNav() {
        nav.removeAllViews(); nav.setBackgroundColor(Color.WHITE); nav.setPadding(dp(8), dp(8), dp(8), dp(8))
        val items = listOf(Triple("🏠", "Home", PURPLE), Triple("🔒", "Limits", BLUE), Triple("📖", "Focus", TEAL),
            Triple("📈", "Insights", ORANGE), Triple("🏆", "Rewards", PINK))
        items.forEachIndexed { i, item ->
            val sel = i == tab
            val t = TextView(this).apply {
                text = "${item.first}\n${item.second}"; gravity = Gravity.CENTER; textSize = 12f
                setTextColor(if (sel) item.third else MUTED); if (sel) typeface = Typeface.DEFAULT_BOLD
                background = if (sel) bg(tint(item.third, 0x26), 20) else null
                setPadding(0, dp(8), 0, dp(8))
                setOnClickListener { if (tab != i) { tab = i; show() } }
            }
            nav.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
    }

    // ---------- first-time welcome ----------
    private fun onboarding(): LinearLayout {
        val col = page().apply { gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(24), dp(40), dp(24), dp(24)) }
        col.addView(text("●  ".repeat(onboardPage + 1) + "○  ".repeat(2 - onboardPage), 14f, PURPLE, true).apply { gravity = Gravity.CENTER })
        when (onboardPage) {
            0 -> {
                col.addView(CatView(this).apply { setMood("happy") }, LinearLayout.LayoutParams(MATCH, dp(260)).apply { topMargin = dp(16) })
                col.addView(text("Meet MeowTime", 32f, INK, true).apply { gravity = Gravity.CENTER }, lp(12))
                col.addView(text("Your study buddy who keeps your screen time in check. Tap the cat to say hi!", 16f, MUTED).apply { gravity = Gravity.CENTER }, lp(8))
                col.addView(button("Next", true, PURPLE) { onboardPage = 1; show() }, lp(32))
            }
            1 -> {
                col.addView(text("How it works", 30f, INK, true).apply { gravity = Gravity.CENTER }, lp(20))
                val rows = listOf(
                    "🔒" to "Every app starts at 2 hours. Slide the limit down any time.",
                    "😾" to "Hit the limit and MeowTime sends you home. You get one +15 min extension per app each day.",
                    "📖" to "Focus mode pauses your distracting apps while you study.",
                    "🔥" to "Stay under every limit to grow a streak and unlock new outfits."
                )
                for ((e, t) in rows) {
                    val r = card().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                    r.addView(text(e, 26f), LinearLayout.LayoutParams(dp(44), WRAP))
                    r.addView(text(t, 15f, INK), LinearLayout.LayoutParams(0, WRAP, 1f))
                    col.addView(r, lp(12))
                }
                col.addView(button("Next", true, BLUE) { onboardPage = 2; show() }, lp(24))
            }
            else -> {
                val granted = usageGranted(); val blocker = blockerOn()
                col.addView(text("Two quick permissions", 28f, INK, true).apply { gravity = Gravity.CENTER }, lp(20))
                col.addView(text("MeowTime only checks which app is open and for how long. Nothing leaves your phone.", 15f, MUTED).apply { gravity = Gravity.CENTER }, lp(8))
                col.addView(button(if (granted) "✅ Usage Access allowed" else "Allow Usage Access", !granted, TEAL) {
                    startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }, lp(20))
                col.addView(button(if (blocker) "✅ Blocker is on" else "Turn on blocker", !blocker, BLUE) {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, lp(12))
                col.addView(text("If the blocker switch is greyed out: open this app's App info, tap the three dots and choose Allow restricted settings.", 13f, MUTED).apply { gravity = Gravity.CENTER }, lp(14))
                col.addView(button("Let's go!", true, PURPLE) { prefs().edit().putBoolean("onboarded", true).apply(); tab = 0; show() }, lp(24))
            }
        }
        return col
    }

    // ---------- Home ----------
    private fun home(): LinearLayout {
        val granted = usageGranted(); val blocker = blockerOn()
        val mood = if (granted) Mood.current(this) else "happy"
        val col = page()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(text("🐾  MeowTime", 20f, INK, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        top.addView(pill("🔥 ${Streak.current(this)}", ORANGE))
        col.addView(top)
        col.addView(text(SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date()).uppercase(), 12f, MUTED, true, 0.12f), lp(22))
        val h = Mood.headline.getValue(mood)
        col.addView(text(span(h.first, h.second), 34f, INK, true), lp(6))
        col.addView(text(Mood.sub.getValue(mood), 15f, MUTED), lp(6))
        if (!granted || !blocker) col.addView(setupCard(granted, blocker), lp(18))
        val usage = if (granted) Limits.usedAll(this) else emptyMap()
        col.addView(companionCard(mood, granted), lp(18))
        col.addView(streakCard(), lp(14))
        col.addView(screenTimeCard(usage, granted), lp(14))
        return col
    }

    private fun setupCard(granted: Boolean, blocker: Boolean): View {
        val c = card(tint(YELLOW, 0x40))
        c.addView(text("Finish setup", 18f, INK, true))
        c.addView(text("MeowTime needs two permissions. It only checks which app is open and for how long. Nothing leaves your phone.", 13f, INK), lp(6))
        if (!granted) c.addView(button("Allow Usage Access", true, TEAL) { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }, lp(14))
        if (!blocker) c.addView(button("Turn on blocker", true, BLUE) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, lp(10))
        return c
    }

    private fun companionCard(mood: String, granted: Boolean): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = gradient(NAVY, INDIGO, 28); setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        c.addView(studs(YELLOW))
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(text("YOUR COMPANION", 11f, YELLOW, true, 0.14f))
        left.addView(text(Mood.title.getValue(mood), 16f, Color.parseColor("#B9B4FF"), true), lp(4))
        left.addView(text(Mood.line.getValue(mood), 19f, Color.WHITE, true), lp(10))
        top.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))

        val cat = CatView(this).apply { setMood(mood) }
        val holder = FrameLayout(this)
        holder.addView(cat, FrameLayout.LayoutParams(dp(110), dp(110), Gravity.CENTER))
        val circle = FrameLayout(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#2C2F86")) }
        }
        circle.addView(holder, FrameLayout.LayoutParams(dp(110), dp(110), Gravity.CENTER))
        top.addView(circle, LinearLayout.LayoutParams(dp(130), dp(130)).apply { leftMargin = dp(12) })
        // gentle idle bounce so MeowTime feels alive
        val bob = ObjectAnimator.ofFloat(holder, "translationY", 0f, -dp(6).toFloat()).apply {
            duration = 1400; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
        }
        loops.add(bob); bob.start()
        c.addView(top, lp(10))

        c.addView(button("♥  Pet MeowTime", true, YELLOW) { cat.pet() }, lp(16).apply { width = WRAP })

        val hp = if (granted) Mood.happiness(this) else 75
        val pct = text("0%", 14f, YELLOW, true)
        ValueAnimator.ofInt(0, hp).apply {
            duration = 800; startDelay = 300
            addUpdateListener { pct.text = "${it.animatedValue}%" }
        }.start()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(text("HAPPINESS", 11f, Color.parseColor("#B9B4FF"), true, 0.12f))
        row.addView(bar(hp / 100f, YELLOW, Color.parseColor("#2C2F86")), LinearLayout.LayoutParams(0, dp(10), 1f).apply { setMargins(dp(10), 0, dp(10), 0) })
        row.addView(pct)
        c.addView(row, lp(18))
        return c
    }

    private fun streakCard(): View {
        val s = Streak.current(this); val best = Streak.best(this)
        val c = card(tint(ORANGE, 0x22))
        c.addView(text("🔥 $s-day streak", 22f, INK, true))
        c.addView(text("Best: $best ${if (best == 1) "day" else "days"}. A day counts when every app stays under its limit.", 13f, MUTED), lp(4))
        Streak.next(this)?.let { (name, days) ->
            c.addView(text("🎁 $days more ${if (days == 1) "day" else "days"} to unlock ${CatArt.label(name)}", 14f, Color.parseColor("#C25A00"), true), lp(10))
        }
        return c
    }

    private fun screenTimeCard(usage: Map<String, Long>, granted: Boolean): View {
        val c = card()
        c.addView(text("TODAY ON TRACKED APPS", 11f, MUTED, true, 0.14f))
        c.addView(text("Your daily balance", 18f, INK, true), lp(6))
        var used = 0L; var lim = 0L
        for ((_, pkg) in Limits.apps) { used += usage[pkg] ?: 0L; lim += Limits.limitMin(this, pkg) }
        val big = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        big.addView(text(hm(used), 40f, INK, true))
        big.addView(text("  / ${hm(lim)}", 16f, MUTED))
        c.addView(big, lp(14))
        val f = if (lim > 0) used / lim.toFloat() else 0f
        c.addView(bar(f, barColor(f)), lp(12).apply { height = dp(10) })
        if (!granted) c.addView(text("Allow Usage Access to see your real numbers.", 13f, MUTED), lp(10))
        for ((name, pkg) in Limits.apps) {
            val u = usage[pkg] ?: 0L; val l = Limits.limitMin(this, pkg)
            val fr = if (l > 0) u / l.toFloat() else 0f
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            r.addView(View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(appColor(pkg)) } },
                LinearLayout.LayoutParams(dp(10), dp(10)).apply { rightMargin = dp(8) })
            r.addView(text(name, 14f, INK), LinearLayout.LayoutParams(0, WRAP, 1f))
            r.addView(text("$u / $l min", 13f, if (l in 1..u.toInt()) RED else MUTED, true))
            c.addView(r, lp(16))
            c.addView(bar(fr, appColor(pkg)), lp(6).apply { height = dp(6) })
        }
        return c
    }

    // ---------- Limits ----------
    private fun limits(): LinearLayout {
        val granted = usageGranted()
        val usage = if (granted) Limits.usedAll(this) else emptyMap()
        val col = page()
        col.addView(text("App limits", 30f, INK, true))
        col.addView(text("Every app starts at 2 hours, the highest. Slide down to lower a limit right away. Sliding up only starts tomorrow. Once an app is locked you get one +15 min extension a day.", 14f, MUTED), lp(6))
        for ((name, pkg) in Limits.apps) col.addView(limitCard(name, pkg, usage[pkg] ?: 0L), lp(14))
        return col
    }

    private fun limitCard(name: String, pkg: String, used: Long): View {
        val color = appColor(pkg)
        val c = card()
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(text(name.take(1), 16f, onColor(color), true).apply { gravity = Gravity.CENTER; background = bg(color, 12) },
            LinearLayout.LayoutParams(dp(36), dp(36)))
        head.addView(text(name, 17f, INK, true), LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(12) })
        val usedTv = text("", 14f, MUTED, true)
        head.addView(usedTv)
        c.addView(head)
        c.addView(studs(color), lp(10))
        val barHolder = FrameLayout(this)
        c.addView(barHolder, lp(10).apply { height = dp(10) })
        val statusTv = text("", 13f, RED, true)
        c.addView(statusTv, lp(10))
        val extBtn = button("+${Limits.EXTRA} min (once today)", true, color) {}
        c.addView(extBtn, lp(10))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(text("DAILY LIMIT", 11f, MUTED, true, 0.12f), LinearLayout.LayoutParams(0, WRAP, 1f))
        val valTv = text("", 22f, color, true)
        row.addView(valTv)
        c.addView(row, lp(16))
        val noteTv = text("", 13f, MUTED)

        fun refresh() {
            val lim = Limits.limitMin(this, pkg); val base = Limits.baseMin(this, pkg); val pend = Limits.pendingMin(this, pkg)
            val f = if (lim > 0) used / lim.toFloat() else 0f
            usedTv.text = "$used / $lim min"
            usedTv.setTextColor(if (f >= 1f) RED else MUTED)
            barHolder.removeAllViews()
            barHolder.addView(bar(f, barColor(f)), FrameLayout.LayoutParams(MATCH, MATCH))
            statusTv.text = when {
                f >= 1f -> "🔒 Limit reached. Locked until midnight."
                Limits.extendedToday(this, pkg) -> "⏱ +${Limits.EXTRA} min extension used today."
                else -> ""
            }
            statusTv.visibility = if (statusTv.text.isEmpty()) View.GONE else View.VISIBLE
            extBtn.visibility = if (usageGranted() && Limits.canExtend(this, pkg)) View.VISIBLE else View.GONE
            valTv.text = "${pend ?: base}m"
            noteTv.text = if (pend != null) "Today: ${base}m · Tomorrow: ${pend}m" else "Applies today and every day until you change it."
        }
        extBtn.setOnClickListener {
            if (Limits.extend(this, pkg)) Toast.makeText(this, "+${Limits.EXTRA} minutes added for today.", Toast.LENGTH_SHORT).show()
            show()
        }

        val sb = SeekBar(this).apply {
            max = (Limits.MAX - 5) / 5
            progress = (((Limits.pendingMin(this@MainActivity, pkg) ?: Limits.baseMin(this@MainActivity, pkg)) - 5) / 5).coerceIn(0, max)
            progressTintList = ColorStateList.valueOf(color); thumbTintList = ColorStateList.valueOf(color)
            progressBackgroundTintList = ColorStateList.valueOf(LINE)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) valTv.text = "${5 + p * 5}m" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {
                    val want = 5 + (s?.progress ?: 0) * 5
                    val before = Limits.baseMin(this@MainActivity, pkg)
                    val msg = Limits.setLimit(this@MainActivity, pkg, want)
                    if (want > before) Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show()
                    refresh()
                }
            })
        }
        c.addView(sb, lp(6))
        c.addView(noteTv, lp(4))
        refresh()
        return c
    }

    // ---------- Focus ----------
    private fun fmt(ms: Long): String { val t = ms / 1000; return "%02d:%02d".format(t / 60, t % 60) }

    private fun focus(): LinearLayout {
        Focus.finishIfDone(this)
        val active = Focus.active(this)
        val col = page()
        col.addView(text("Focus mode", 30f, INK, true))
        col.addView(text("Silence notifications and pause your distracting apps while you study.", 14f, MUTED), lp(6))
        val c = card(tint(TEAL, 0x1C))
        c.addView(studs(TEAL))
        val cat = CatView(this).apply { setMood(if (active) "study" else "happy") }
        c.addView(cat, LinearLayout.LayoutParams(MATCH, dp(170)))
        val clock = text(fmt(if (active) Focus.remainingMs(this) else focusMin * 60_000L), 48f, INK, true).apply { gravity = Gravity.CENTER }
        c.addView(clock, lp(8))
        val track = FrameLayout(this).apply { background = bg(LINE, 8) }
        val fill = View(this).apply { background = bg(TEAL, 8) }
        track.addView(fill, FrameLayout.LayoutParams(0, MATCH))
        c.addView(track, lp(12).apply { height = dp(10) })
        if (!active) {
            val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (m in listOf(25, 45, 60)) chips.addView(button("$m min", focusMin == m, TEAL) { focusMin = m; show() },
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(8) })
            chips.addView(button("Custom", focusMin !in listOf(25, 45, 60), TEAL) { customFocus() }, LinearLayout.LayoutParams(0, WRAP, 1f))
            c.addView(chips, lp(18))
            c.addView(button("Start focus", true, PURPLE) { Focus.start(this, focusMin); show() }, lp(14))
        } else {
            c.addView(button("Stop session", false, RED) { Focus.cancel(this); show() }, lp(18))
            val tick = object : Runnable {
                override fun run() {
                    if (tab != 2) return
                    if (Focus.finishIfDone(this@MainActivity)) {
                        Toast.makeText(this@MainActivity, "Session complete! 🎉", Toast.LENGTH_LONG).show()
                        show(); return
                    }
                    val rem = Focus.remainingMs(this@MainActivity)
                    clock.text = fmt(rem)
                    fill.layoutParams.width = (track.width * (1f - rem / Focus.plannedMs(this@MainActivity).toFloat())).toInt()
                    fill.requestLayout()
                    handler.postDelayed(this, 1000)
                }
            }
            handler.post(tick)
        }
        col.addView(c, lp(18))

        val info = card()
        if (Focus.dndAllowed(this)) {
            info.addView(text("🔕 Do Not Disturb turns on during focus and goes back to how it was afterwards.", 14f, INK))
        } else {
            info.addView(text("Allow Do Not Disturb access so MeowTime can silence notifications while you study.", 14f, INK))
            info.addView(button("Allow Do Not Disturb", false, TEAL) { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }, lp(12).apply { width = WRAP })
        }
        info.addView(text("📵 Your tracked apps are paused until the session ends.", 14f, INK), lp(12))
        col.addView(info, lp(14))
        return col
    }

    private fun customFocus() {
        val input = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(focusMin.toString()) }
        AlertDialog.Builder(this).setTitle("Focus minutes (5 to 180)").setView(input)
            .setPositiveButton("OK") { _, _ -> focusMin = (input.text.toString().toIntOrNull() ?: 25).coerceIn(5, 180); show() }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------- Insights ----------
    private fun statCard(label: String, value: String, color: Int): View = card(tint(color, 0x1E)).apply {
        setPadding(dp(16), dp(16), dp(16), dp(16))
        addView(text(label.uppercase(), 11f, color, true, 0.12f)); addView(text(value, 24f, INK, true), lp(6))
    }

    private fun insights(): LinearLayout {
        val granted = usageGranted()
        val days = if (granted) Limits.dayTotals(this) else List(7) { 0L }
        val col = page()
        col.addView(text("Insights", 30f, INK, true))
        col.addView(text(if (granted) "Your last 7 days on tracked apps." else "Allow Usage Access on the Home tab to see your real numbers.", 14f, MUTED), lp(6))
        val c = card()
        c.addView(text("MINUTES PER DAY", 11f, MUTED, true, 0.14f))
        val top = (days.maxOrNull() ?: 0L).coerceAtLeast(60L)
        val chart = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        val palette = intArrayOf(BLUE, PURPLE, TEAL, ORANGE, PINK, YELLOW, GREEN)
        days.forEachIndexed { i, m ->
            val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -(6 - i)) }
            val bcol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            bcol.addView(text(hm(m), 10f, MUTED))
            val barV = View(this).apply { background = bg(palette[i % palette.size], 10) }
            bcol.addView(barV, LinearLayout.LayoutParams(dp(26), 0))
            bcol.addView(text(SimpleDateFormat("EEE", Locale.getDefault()).format(cal.time), 11f, if (i == 6) INK else MUTED, i == 6), lp(4))
            chart.addView(bcol, LinearLayout.LayoutParams(0, WRAP, 1f))
            ValueAnimator.ofInt(0, maxOf(dp(4), (dp(140) * m / top).toInt())).apply {
                duration = 700; startDelay = 200L + i * 60
                addUpdateListener { barV.layoutParams.height = it.animatedValue as Int; barV.requestLayout() }
            }.start()
        }
        c.addView(chart, lp(14))
        col.addView(c, lp(18))
        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r1.addView(statCard("Today", hm(days.last()), BLUE), LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(7) })
        r1.addView(statCard("7-day average", hm(days.sum() / 7), TEAL), LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(7) })
        col.addView(r1, lp(14))
        val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r2.addView(statCard("Focus sessions", "${Focus.sessions(this)}", ORANGE), LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(7) })
        r2.addView(statCard("Study time", hm(Focus.minutes(this).toLong()), PINK), LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(7) })
        col.addView(r2, lp(14))
        return col
    }

    // ---------- Rewards: outfits, streak unlocks and the weekly goal ----------
    private fun rewards(): LinearLayout {
        val col = page()
        col.addView(text("Rewards", 30f, INK, true))
        col.addView(text("Stay under every limit to grow your streak and unlock new outfits.", 14f, MUTED), lp(6))
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = gradient(NAVY, INDIGO, 28); setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        c.addView(studs(YELLOW))
        val preview = CatView(this).apply { setMood("happy") }
        c.addView(preview, LinearLayout.LayoutParams(MATCH, dp(210)))
        val nameTv = text(CatArt.label(CatArt.outfit(this)), 17f, YELLOW, true).apply { gravity = Gravity.CENTER }
        c.addView(nameTv, lp(4))
        col.addView(c, lp(18))

        val tiles = LinkedHashMap<String, LinearLayout>()
        fun paint() {
            val cur = CatArt.outfit(this)
            for ((n, t) in tiles) t.background = bg(Color.WHITE, 20, if (n == cur) PURPLE else LINE, if (n == cur) 3 else 1)
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (n in CatArt.outfits.keys) {
            val open = CatArt.unlocked(this, n)
            val t = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(10), dp(10), dp(10), dp(10))
            }
            val img = ImageView(this).apply {
                setImageBitmap(CatArt.bitmap(this@MainActivity, n, "happy")); scaleType = ImageView.ScaleType.FIT_CENTER
                alpha = if (open) 1f else 0.3f
            }
            t.addView(img, LinearLayout.LayoutParams(dp(72), dp(100)))
            t.addView(text(CatArt.label(n), 12f, INK, true), lp(6))
            t.addView(text(if (open) "Unlocked" else "🔒 ${CatArt.unlockAt[n]}-day streak", 11f, if (open) GREEN else MUTED, open))
            t.setOnClickListener {
                if (!open) {
                    Toast.makeText(this, "Reach a ${CatArt.unlockAt[n]}-day streak to unlock ${CatArt.label(n)}.", Toast.LENGTH_SHORT).show()
                } else {
                    CatArt.setOutfit(this, n); preview.setOutfit(n); preview.pet(); nameTv.text = CatArt.label(n); paint()
                }
            }
            tiles[n] = t
            row.addView(t, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(10) })
        }
        paint()
        col.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }, lp(16))
        col.addView(goalCard(), lp(16))
        return col
    }

    private fun goalCard(): View {
        val granted = usageGranted()
        val pkg = Goal.pkg(this); val target = Goal.target(this)
        val appName = Limits.apps.entries.first { it.value == pkg }.key
        val met = if (granted) Goal.daysMet(this) else 0
        val done = met >= Goal.NEED
        val c = card()
        c.addView(text("WEEKLY GOAL", 11f, MUTED, true, 0.14f))
        c.addView(text("$appName under ${hm(target.toLong())} a day", 18f, INK, true), lp(6))
        c.addView(text("Do it on ${Goal.NEED} of the last 7 days.", 13f, MUTED), lp(2))
        val ring = RingView(this).apply {
            frac = (met / Goal.NEED.toFloat()).coerceAtMost(1f); color = if (done) GREEN else appColor(pkg)
            label = "$met/${Goal.NEED}"; sub = "days"
        }
        c.addView(ring, LinearLayout.LayoutParams(dp(130), dp(130)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(12) })
        if (done) c.addView(text("🎉 Goal reached this week!", 15f, GREEN, true).apply { gravity = Gravity.CENTER }, lp(8))
        if (!granted) c.addView(text("Allow Usage Access on the Home tab to track this.", 13f, MUTED).apply { gravity = Gravity.CENTER }, lp(8))

        c.addView(text("APP", 11f, MUTED, true, 0.12f), lp(16))
        val apps = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((n, p) in Limits.apps) apps.addView(button(n, p == pkg, appColor(p)) { Goal.set(this, p, target); show() },
            LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
        c.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(apps) }, lp(8))

        c.addView(text("DAILY TARGET", 11f, MUTED, true, 0.12f), lp(16))
        val mins = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (m in listOf(30, 60, 90)) mins.addView(button(hm(m.toLong()), m == target, PURPLE) { Goal.set(this, pkg, m); show() },
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(8) })
        c.addView(mins, lp(8))
        return c
    }
}
