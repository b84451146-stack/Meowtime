package com.meowtime.app

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.RectF
import android.view.View

/** The cat on the app screen. Tap it to pet it: it hops and little hearts float up from its head. */
class CatView(c: Context) : View(c) {
    private var name = CatArt.outfit(c)
    private var mood = "happy"
    private var bmp = CatArt.bitmap(c, name, mood)
    private var progress = 0f
    private val dst = RectF()

    init { setOnClickListener { pet() } }

    fun setOutfit(n: String) { name = n; bmp = CatArt.bitmap(context, n, mood); invalidate() }
    fun setMood(m: String) { mood = m; bmp = CatArt.bitmap(context, name, m); invalidate() }

    fun pet() {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1300
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
        }.start()
        ObjectAnimator.ofFloat(this, "translationY", 0f, -36f, 0f, -10f, 0f).setDuration(600).start()
    }

    override fun onDraw(canvas: Canvas) {
        val bw = bmp.width.toFloat(); val bh = bmp.height.toFloat()
        val s = minOf(width / bw, height / bh)
        dst.set((width - bw * s) / 2, (height - bh * s) / 2, (width + bw * s) / 2, (height + bh * s) / 2)
        canvas.save()
        canvas.translate(dst.left, dst.top); canvas.scale(s, s)
        canvas.drawBitmap(bmp, 0f, 0f, null)
        if (progress in 0.001f..0.999f) CatArt.drawHearts(canvas, bw, bh, name, progress)
        canvas.restore()
    }
}
