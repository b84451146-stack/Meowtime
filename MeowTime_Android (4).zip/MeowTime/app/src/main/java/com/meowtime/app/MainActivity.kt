package com.meowtime.app

import android.animation.Animator
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.Manifest
import android.app.AppOpsManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.text.InputType
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val BG = Color.parseColor("#F6F4FF")
    private val INK = Color.parseColor("#1D1B3A")
    private val MUTED = Color.parseColor("#8A87B0")
    private val PURPLE = Color.parseColor("#7A5AE0")
    private val LAV = Color.parseColor("#EFEAFF")
    private val LINE = Color.parseColor("#E3DDFB")
    private val PINK = Color.parseColor("#E0457B")
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private var tab = 0
    private lateinit var content: FrameLayout
    private lateinit var nav: LinearLayout
    private val loops = mutableListOf<Animator>()
    private val handler = Handler(Looper.getMainLooper())
    private var focusMin = 25

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        content = FrameLayout(this)
        nav = LinearLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(nav, LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(root)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() { super.onResume(); show() }
    override fun onPause() { super.onPause(); stopLoops() }
    private fun stopLoops() { loops.forEach { it.cancel() }; loops.clear(); handler.removeCallbacksAndMessages(null) }

    // ---------- permissions ----------
    private fun usageGranted(): Boolean {
        val ops = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }
    private fun blockerOn(): Boolean =
        Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains("$packageName/.BlockerService") == true

    // ---------- small view helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, r: Int, stroke: Int = 0, sw: Int = 1) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(sw), stroke)
    }
    private fun text(t: CharSequence, sp: Float, color: Int = INK, bold: Boolean = false, spacing: Float = 0f) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(color); letterSpacing = spacing; if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun card(fill: Int = Color.WHITE) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = bg(fill, 28, LINE); setPadding(dp(20), dp(20), dp(20), dp(20))
    }
    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(top) }
    private fun page() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(16), dp(20), dp(24)) }
    private fun hm(m: Long) = if (m >= 60) "${m / 60}h ${m % 60}m" else "${m}m"

    private fun button(label: String, filled: Boolean, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 15f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (filled) Color.WHITE else PURPLE)
        background = bg(if (filled) PURPLE else Color.WHITE, 24, if (filled) 0 else LINE)
        setPadding(dp(20), dp(12), dp(20), dp(12))
        setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }
        setOnClickListener { onClick() }
    }

    /** A progress bar that fills up with an animation. */
    private fun bar(frac: Float, hot: Boolean): View {
        val track = FrameLayout(this).apply { background = bg(LINE, 8) }
        val fill = View(this).apply { background = bg(if (hot) Color.parseColor("#FF7AA8") else PURPLE, 8) }
        track.addView(fill, FrameLayout.LayoutParams(0, MATCH))
        track.post {
            ValueAnimator.ofInt(0, (track.width * frac.coerceIn(0f, 1f)).toInt()).apply {
                duration = 800; startDelay = 250
                addUpdateListener { (fill.layoutParams as FrameLayout.LayoutParams).width = it.animatedValue as Int; fill.requestLayout() }
            }.start()
        }
        return track
    }

    private fun span(a: String, b: String) = SpannableString(a + b).apply {
        setSpan(ForegroundColorSpan(PURPLE), a.length, a.length + b.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    private fun stagger(col: ViewGroup) {
        for (i in 0 until col.childCount) {
            val v = col.getChildAt(i)
            v.alpha = 0f; v.translationY = dp(24).toFloat()
            v.animate().alpha(1f).translationY(0f).setStartDelay(i * 70L).setDuration(380).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    // ---------- screens ----------
    private fun show() {
        stopLoops()
        content.removeAllViews()
        val col = when (tab) { 0 -> home(); 1 -> limits(); 2 -> focus(); 3 -> insights(); else -> widgetTab() }
        content.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(col) })
        stagger(col)
        buildNav()
    }

    private fun buildNav() {
        nav.removeAllViews(); nav.setBackgroundColor(Color.WHITE); nav.setPadding(dp(8), dp(8), dp(8), dp(8))
        val items = listOf("🏠" to "Home", "🔒" to "Limits", "📖" to "Focus", "📈" to "Insights", "🐾" to "Widget")
        items.forEachIndexed { i, item ->
            val sel = i == tab
            val t = TextView(this).apply {
                text = "${item.first}\n${item.second}"; gravity = Gravity.CENTER; textSize = 12f
                setTextColor(if (sel) PURPLE else MUTED); if (sel) typeface = Typeface.DEFAULT_BOLD
                background = if (sel) bg(LAV, 20) else null
                setPadding(0, dp(8), 0, dp(8))
                setOnClickListener { if (tab != i) { tab = i; show() } }
            }
            nav.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
    }

    private fun home(): LinearLayout {
        val granted = usageGranted(); val blocker = blockerOn()
        val mood = if (granted) Mood.current(this) else "happy"
        val col = page()
        col.addView(text("🐾  MeowTime", 20f, INK, true))
        col.addView(text(SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date()).uppercase(), 12f, MUTED, true, 0.12f), lp(22))
        val h = Mood.headline.getValue(mood)
        col.addView(text(span(h.first, h.second), 34f, INK, true), lp(6))
        col.addView(text(Mood.sub.getValue(mood), 15f, MUTED), lp(6))
        if (!granted || !blocker) col.addView(setupCard(granted, blocker), lp(18))
        val usage = if (granted) Limits.usedAll(this) else emptyMap()
        col.addView(companionCard(mood, granted), lp(18))
        col.addView(screenTimeCard(usage, granted), lp(14))
        return col
    }

    private fun setupCard(granted: Boolean, blocker: Boolean): View {
        val c = card(LAV)
        c.addView(text("Finish setup", 18f, INK, true))
        c.addView(text("MeowTime needs two permissions. It only checks which app is open and for how long. Nothing leaves your phone.", 13f, MUTED), lp(6))
        if (!granted) c.addView(button("Allow Usage Access", true) { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }, lp(14))
        if (!blocker) c.addView(button("Turn on blocker", true) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, lp(10))
        return c
    }

    private fun companionCard(mood: String, granted: Boolean): View {
        val c = card(Color.parseColor("#F3EEFF"))
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(text("YOUR COMPANION", 11f, PURPLE, true, 0.14f))
        left.addView(text(Mood.title.getValue(mood), 16f, PURPLE, true), lp(4))
        left.addView(text(Mood.line.getValue(mood), 19f, INK, true), lp(10))
        top.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))

        val cat = CatView(this).apply { setMood(mood) }
        val holder = FrameLayout(this)
        holder.addView(cat, FrameLayout.LayoutParams(dp(110), dp(110), Gravity.CENTER))
        val circle = FrameLayout(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#E4DAFF")) }
        }
        circle.addView(holder, FrameLayout.LayoutParams(dp(110), dp(110), Gravity.CENTER))
        top.addView(circle, LinearLayout.LayoutParams(dp(130), dp(130)).apply { leftMargin = dp(12) })
        // gentle idle bounce so MeowTime feels alive
        val bob = ObjectAnimator.ofFloat(holder, "translationY", 0f, -dp(6).toFloat()).apply {
            duration = 1400; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
        }
        loops.add(bob); bob.start()
        c.addView(top)

        c.addView(button("♥  Pet MeowTime", false) { cat.pet() }, lp(16).apply { width = WRAP })

        val hp = if (granted) Mood.happiness(this) else 75
        val pct = text("0%", 14f, PURPLE, true)
        ValueAnimator.ofInt(0, hp).apply {
            duration = 800; startDelay = 300
            addUpdateListener { pct.text = "${it.animatedValue}%" }
        }.start()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(text("HAPPINESS", 11f, MUTED, true, 0.12f))
        row.addView(bar(hp / 100f, false), LinearLayout.LayoutParams(0, dp(10), 1f).apply { setMargins(dp(10), 0, dp(10), 0) })
        row.addView(pct)
        c.addView(row, lp(18))
        return c
    }

    private fun screenTimeCard(usage: Map<String, Long>, granted: Boolean): View {
        val c = card()
        c.addView(text("TODAY ON TRACKED APPS", 11f, MUTED, true, 0.14f))
        c.addView(text("Your daily balance", 18f, INK, true), lp(6))
        var used = 0L; var lim = 0L
        for ((_, pkg) in Limits.apps) { used += usage[pkg] ?: 0L; lim += Limits.limitMin(this, pkg) }
        val big = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        big.addView(text(hm(used), 40f, INK, true))
        big.addView(text("  / ${hm(lim)}", 16f, MUTED))
        c.addView(big, lp(14))
        c.addView(bar(if (lim > 0) used / lim.toFloat() else 0f, lim in 1..used), lp(12).apply { height = dp(10) })
        if (!granted) c.addView(text("Allow Usage Access to see your real numbers.", 13f, MUTED), lp(10))
        for ((name, pkg) in Limits.apps) {
            val u = usage[pkg] ?: 0L; val l = Limits.limitMin(this, pkg)
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            r.addView(text(name, 14f, INK), LinearLayout.LayoutParams(0, WRAP, 1f))
            r.addView(text("$u / $l min", 13f, if (l in 1..u) PINK else MUTED, true))
            c.addView(r, lp(16))
            c.addView(bar(if (l > 0) u / l.toFloat() else 0f, l in 1..u), lp(6).apply { height = dp(6) })
        }
        return c
    }

    private fun round(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 20f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
        setTextColor(PURPLE); background = bg(LAV, 14); setOnClickListener { onClick() }
    }

    private fun stepLimit(pkg: String, delta: Int) {
        val cur = Limits.limitMin(this, pkg)
        val want = (Limits.pendingMin(this, pkg) ?: cur) + delta
        if (want > Limits.MAX) { Toast.makeText(this, "The highest limit is 5 hours (300 min).", Toast.LENGTH_SHORT).show(); return }
        if (want < 5) { Toast.makeText(this, "The lowest limit is 5 minutes.", Toast.LENGTH_SHORT).show(); return }
        val msg = Limits.setLimit(this, pkg, want)
        if (want > cur) Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        MeowWidget.refresh(this); show()
    }

    private fun limits(): LinearLayout {
        val granted = usageGranted()
        val usage = if (granted) Limits.usedAll(this) else emptyMap()
        val col = page()
        col.addView(text("App limits", 30f, INK, true))
        col.addView(text("Every app starts at 5 hours (the highest) and stays there until you change it. Lowering works right away. Raising only starts tomorrow, so a blocked app stays blocked.", 14f, MUTED), lp(6))
        for ((name, pkg) in Limits.apps) {
            val used = usage[pkg] ?: 0L
            val lim = Limits.limitMin(this, pkg)
            val pend = Limits.pendingMin(this, pkg)
            val blocked = lim > 0 && used >= lim
            val c = card()
            val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            head.addView(text(name, 17f, INK, true), LinearLayout.LayoutParams(0, WRAP, 1f))
            head.addView(text("$used / $lim min", 14f, if (blocked) PINK else MUTED, true))
            c.addView(head)
            c.addView(bar(if (lim > 0) used / lim.toFloat() else 0f, blocked), lp(12).apply { height = dp(10) })
            if (blocked) c.addView(text("🔒 Limit reached. Locked until midnight.", 13f, PINK), lp(10))
            c.addView(text("DAILY LIMIT", 11f, MUTED, true, 0.12f), lp(14))
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            r.addView(round("−") { stepLimit(pkg, -5) }, LinearLayout.LayoutParams(dp(44), dp(44)))
            r.addView(text("${lim}m", 18f, INK, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(84), WRAP))
            r.addView(round("+") { stepLimit(pkg, 5) }, LinearLayout.LayoutParams(dp(44), dp(44)))
            c.addView(r, lp(8))
            if (pend != null) c.addView(text("Tomorrow: ${pend}m", 13f, PURPLE), lp(8))
            col.addView(c, lp(14))
        }
        return col
    }

    private fun fmt(ms: Long): String { val t = ms / 1000; return "%02d:%02d".format(t / 60, t % 60) }

    private fun focus(): LinearLayout {
        Focus.finishIfDone(this)
        val active = Focus.active(this)
        val col = page()
        col.addView(text("Focus mode", 30f, INK, true))
        col.addView(text("Silence notifications and pause your distracting apps while you study.", 14f, MUTED), lp(6))
        val c = card(Color.parseColor("#F3EEFF"))
        val cat = CatView(this).apply { setMood(if (active) "study" else "happy") }
        c.addView(cat, LinearLayout.LayoutParams(MATCH, dp(170)))
        val clock = text(fmt(if (active) Focus.remainingMs(this) else focusMin * 60_000L), 48f, INK, true).apply { gravity = Gravity.CENTER }
        c.addView(clock, lp(8))
        val track = FrameLayout(this).apply { background = bg(LINE, 8) }
        val fill = View(this).apply { background = bg(PURPLE, 8) }
        track.addView(fill, FrameLayout.LayoutParams(0, MATCH))
        c.addView(track, lp(12).apply { height = dp(10) })
        if (!active) {
            val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (m in listOf(25, 45, 60)) chips.addView(button("$m min", focusMin == m) { focusMin = m; show() },
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(8) })
            chips.addView(button("Custom", focusMin !in listOf(25, 45, 60)) { customFocus() }, LinearLayout.LayoutParams(0, WRAP, 1f))
            c.addView(chips, lp(18))
            c.addView(button("Start focus", true) { Focus.start(this, focusMin); MeowWidget.refresh(this); show() }, lp(14))
        } else {
            c.addView(button("Stop session", false) { Focus.cancel(this); MeowWidget.refresh(this); show() }, lp(18))
            val tick = object : Runnable {
                override fun run() {
                    if (tab != 2) return
                    if (Focus.finishIfDone(this@MainActivity)) {
                        Toast.makeText(this@MainActivity, "Session complete! 🎉", Toast.LENGTH_LONG).show()
                        MeowWidget.refresh(this@MainActivity); show(); return
                    }
                    val rem = Focus.remainingMs(this@MainActivity)
                    clock.text = fmt(rem)
                    fill.layoutParams.width = (track.width * (1f - rem / Focus.plannedMs(this@MainActivity).toFloat())).toInt()
                    fill.requestLayout()
                    handler.postDelayed(this, 1000)
                }
            }
            handler.post(tick)
        }
        col.addView(c, lp(18))

        val info = card()
        if (Focus.dndAllowed(this)) {
            info.addView(text("🔕 Do Not Disturb turns on during focus and goes back to how it was afterwards.", 14f, INK))
        } else {
            info.addView(text("Allow Do Not Disturb access so MeowTime can silence notifications while you study.", 14f, INK))
            info.addView(button("Allow Do Not Disturb", false) { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }, lp(12).apply { width = WRAP })
        }
        info.addView(text("📵 Your tracked apps are paused until the session ends.", 14f, INK), lp(12))
        col.addView(info, lp(14))
        return col
    }

    private fun customFocus() {
        val input = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(focusMin.toString()) }
        AlertDialog.Builder(this).setTitle("Focus minutes (5 to 180)").setView(input)
            .setPositiveButton("OK") { _, _ -> focusMin = (input.text.toString().toIntOrNull() ?: 25).coerceIn(5, 180); show() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun statCard(label: String, value: String): View = card().apply {
        setPadding(dp(16), dp(16), dp(16), dp(16))
        addView(text(label.uppercase(), 11f, MUTED, true, 0.12f)); addView(text(value, 24f, INK, true), lp(6))
    }

    private fun insights(): LinearLayout {
        val granted = usageGranted()
        val days = if (granted) Limits.dayTotals(this) else List(7) { 0L }
        val col = page()
        col.addView(text("Insights", 30f, INK, true))
        col.addView(text(if (granted) "Your last 7 days on tracked apps." else "Allow Usage Access on the Home tab to see your real numbers.", 14f, MUTED), lp(6))
        val c = card()
        c.addView(text("MINUTES PER DAY", 11f, MUTED, true, 0.14f))
        val top = (days.maxOrNull() ?: 0L).coerceAtLeast(60L)
        val chart = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        days.forEachIndexed { i, m ->
            val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -(6 - i)) }
            val bcol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            bcol.addView(text(hm(m), 10f, MUTED))
            val barV = View(this).apply { background = bg(if (i == 6) PURPLE else Color.parseColor("#CFC4F7"), 10) }
            bcol.addView(barV, LinearLayout.LayoutParams(dp(26), 0))
            bcol.addView(text(SimpleDateFormat("EEE", Locale.getDefault()).format(cal.time), 11f, MUTED), lp(4))
            chart.addView(bcol, LinearLayout.LayoutParams(0, WRAP, 1f))
            ValueAnimator.ofInt(0, maxOf(dp(4), (dp(140) * m / top).toInt())).apply {
                duration = 700; startDelay = 200L + i * 60
                addUpdateListener { barV.layoutParams.height = it.animatedValue as Int; barV.requestLayout() }
            }.start()
        }
        c.addView(chart, lp(14))
        col.addView(c, lp(18))
        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r1.addView(statCard("Today", hm(days.last())), LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(7) })
        r1.addView(statCard("7-day average", hm(days.sum() / 7)), LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(7) })
        col.addView(r1, lp(14))
        val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r2.addView(statCard("Focus sessions", "${Focus.sessions(this)}"), LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(7) })
        r2.addView(statCard("Study time", hm(Focus.minutes(this).toLong())), LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(7) })
        col.addView(r2, lp(14))
        return col
    }

    private fun label(n: String) = if (n == "iceflame") "Ice flame" else n.replaceFirstChar { it.uppercase() }

    private fun widgetTab(): LinearLayout {
        val col = page()
        col.addView(text("Widget", 30f, INK, true))
        col.addView(text("Pick MeowTime's outfit. It shows on your home screen and follows your mood.", 14f, MUTED), lp(6))
        val c = card(Color.parseColor("#F3EEFF"))
        val preview = CatView(this).apply { setMood("happy") }
        c.addView(preview, LinearLayout.LayoutParams(MATCH, dp(220)))
        col.addView(c, lp(18))

        val tiles = LinkedHashMap<String, LinearLayout>()
        fun paint() {
            val cur = CatArt.outfit(this)
            for ((n, t) in tiles) t.background = bg(Color.WHITE, 20, if (n == cur) PURPLE else LINE, if (n == cur) 2 else 1)
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (n in CatArt.outfits.keys) {
            val t = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(10), dp(10), dp(10), dp(10))
            }
            val img = ImageView(this).apply {
                setImageBitmap(CatArt.bitmap(this@MainActivity, n, "happy")); scaleType = ImageView.ScaleType.FIT_CENTER
            }
            t.addView(img, LinearLayout.LayoutParams(dp(72), dp(100)))
            t.addView(text(label(n), 12f, INK, true), lp(6))
            t.setOnClickListener {
                CatArt.setOutfit(this, n); preview.setOutfit(n); preview.pet(); MeowWidget.refresh(this); paint()
            }
            tiles[n] = t
            row.addView(t, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(10) })
        }
        paint()
        col.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }, lp(16))
        val how = card()
        how.addView(text("Add it to your home screen", 17f, INK, true))
        how.addView(text("1. Long-press an empty spot on your home screen.\n2. Tap Widgets and find MeowTime.\n3. Drag it out. Tap the cat on the widget to pet it.", 14f, MUTED), lp(8))
        col.addView(how, lp(16))
        return col
    }
}
