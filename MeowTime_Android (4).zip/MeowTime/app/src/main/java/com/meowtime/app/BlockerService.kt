package com.meowtime.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

/**
 * Android does not let an app force-close another app. Instead, when a limited app comes to the
 * front, this service sends the user to the home screen and opens MeowTime's break screen.
 */
class BlockerService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var current: String? = null
    private var tick = 0

    private val poll = object : Runnable {
        override fun run() {
            // Catches the moment a limit is reached while the app is already open.
            current?.let { enforce(it) }
            if (Focus.finishIfDone(this@BlockerService)) MeowWidget.refresh(this@BlockerService)
            try { Notifier.checkWarnings(this@BlockerService, Limits.usedAll(this@BlockerService)) } catch (e: SecurityException) {}
            MeowWidget.refreshIfChanged(this@BlockerService)   // keep the home-screen cat's mood current
            if (++tick % 3 == 0) MeowWidget.idle(this@BlockerService)   // blink / wiggle every ~30 s while the screen is on
            handler.postDelayed(this, 10_000)
        }
    }

    override fun onServiceConnected() { handler.post(poll) }
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); super.onDestroy() }
    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        current = pkg
        enforce(pkg)
    }

    private fun enforce(pkg: String) {
        if (pkg == packageName || pkg !in Limits.apps.values) return
        if (!Limits.isBlocked(this, pkg)) return
        current = packageName
        MeowWidget.refresh(this)
        if (!Focus.active(this)) {
            val name = Limits.apps.entries.firstOrNull { it.value == pkg }?.key ?: "This app"
            Notifier.post(this, pkg.hashCode(), "Enough screen time! 😾", "$name is done for today. Go do some work or step outside.", "angry")
        }
        performGlobalAction(GLOBAL_ACTION_HOME)
        startActivity(Intent(this, BlockActivity::class.java)
            .putExtra("pkg", pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
    }
}
