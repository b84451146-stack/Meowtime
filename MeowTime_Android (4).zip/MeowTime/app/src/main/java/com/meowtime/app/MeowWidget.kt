package com.meowtime.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.os.PowerManager
import android.util.LruCache
import android.view.View
import android.widget.RemoteViews
import java.util.Calendar
import java.util.concurrent.atomic.AtomicBoolean

/** Treats and the feeding streak. A treat can be given 3 times a day; the streak counts days in a row with a treat. */
object Treats {
    const val PER_DAY = 3
    private fun prefs(c: Context) = c.getSharedPreferences("meowtime", Context.MODE_PRIVATE)

    private fun yesterday(): Int = Calendar.getInstance().let {
        it.add(Calendar.DAY_OF_YEAR, -1)
        it.get(Calendar.YEAR) * 10000 + (it.get(Calendar.MONTH) + 1) * 100 + it.get(Calendar.DAY_OF_MONTH)
    }

    fun today(c: Context): Int { val p = prefs(c); return if (p.getInt("treat_day", 0) == Limits.day()) p.getInt("treat_n", 0) else 0 }

    fun streak(c: Context): Int {
        val p = prefs(c); val d = p.getInt("streak_day", 0)
        return if (d == Limits.day() || d == yesterday()) p.getInt("streak", 0) else 0
    }

    /** Gives one treat. Returns false if the cat is full for today. */
    fun give(c: Context): Boolean {
        val n = today(c)
        if (n >= PER_DAY) return false
        val p = prefs(c)
        val e = p.edit().putInt("treat_day", Limits.day()).putInt("treat_n", n + 1)
        if (p.getInt("streak_day", 0) != Limits.day()) {
            val s = if (p.getInt("streak_day", 0) == yesterday()) p.getInt("streak", 0) + 1 else 1
            e.putInt("streak", s).putInt("streak_day", Limits.day())
        }
        e.apply()
        return true
    }
}

/**
 * Home-screen widget. Widgets cannot run free animation, so every "animation" here is a short run of
 * pictures pushed one after another (blink, wiggle, hearts, falling treat), then back to normal.
 */
class MeowWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) = render(c, m, ids, null, null, state(c))

    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        val action = i.action
        if (action != ACTION_PET && action != ACTION_TREAT) return
        val pending = goAsync()
        Thread {
            try { if (action == ACTION_PET) pet(c) else treat(c) } finally { pending.finish() }
        }.start()
    }

    companion object {
        const val ACTION_PET = "com.meowtime.app.PET"
        const val ACTION_TREAT = "com.meowtime.app.TREAT"
        private val busy = AtomicBoolean(false)
        private val cache = LruCache<String, Bitmap>(10)

        private fun prefs(c: Context) = c.getSharedPreferences("meowtime", Context.MODE_PRIVATE)
        private fun widgetIds(c: Context): Pair<AppWidgetManager, IntArray> {
            val m = AppWidgetManager.getInstance(c)
            return m to m.getAppWidgetIds(ComponentName(c, MeowWidget::class.java))
        }

        /** The cat picture for this outfit and mood, shrunk so each widget update stays small. */
        private fun art(c: Context, outfit: String, mood: String): Bitmap {
            val key = "${outfit}_$mood"
            cache.get(key)?.let { return it }
            val src = CatArt.bitmap(c, outfit, mood)
            val scale = 360f / maxOf(src.width, src.height)
            val bmp = if (scale < 1f) Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true) else src
            cache.put(key, bmp)
            return bmp
        }

        /** Tilts and lifts the cat around its feet. */
        private fun pose(src: Bitmap, angle: Float, lift: Float): Bitmap {
            val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
            val cv = Canvas(out)
            cv.translate(0f, -lift * src.height)
            cv.rotate(angle, src.width / 2f, src.height.toFloat())
            cv.drawBitmap(src, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG))
            return out
        }

        private fun withHearts(src: Bitmap, outfit: String, progress: Float): Bitmap {
            val out = src.copy(Bitmap.Config.ARGB_8888, true)
            CatArt.drawHearts(Canvas(out), out.width.toFloat(), out.height.toFloat(), outfit, progress)
            return out
        }

        private fun withTreat(src: Bitmap, outfit: String, t: Float): Bitmap {
            val out = src.copy(Bitmap.Config.ARGB_8888, true)
            val info = CatArt.outfits.getValue(outfit)
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = out.width * 0.16f; textAlign = Paint.Align.CENTER }
            val y = (0.08f + (info.ey + 0.06f - 0.08f) * t) * out.height
            val x = info.mx * out.width + (1f - t) * out.width * 0.12f
            Canvas(out).drawText("🍖", x, y, p)
            return out
        }

        class State(
            val mood: String, val usageText: String, val pct: Int, val level: Int,
            val streakText: String, val treatText: String
        ) { val sig get() = "$mood|$pct|$usageText|$streakText|$treatText" }

        private fun fmt(min: Long): String = if (min >= 60) "${min / 60}h ${min % 60}m" else "${min}m"

        /** Everything the widget shows besides the cat picture. Reads real usage once per update. */
        private fun state(c: Context): State {
            val mood = Mood.current(c)
            var text: String; var pct = 0
            try {
                val u = Limits.usedAll(c)
                var worst = 0.0; var name = ""; var left = 0L
                for ((n, pkg) in Limits.apps) {
                    val lim = Limits.limitMin(c, pkg).coerceAtLeast(1); val used = u[pkg] ?: 0L
                    val r = used.toDouble() / lim
                    if (r > worst) { worst = r; name = n; left = (lim - used).coerceAtLeast(0) }
                }
                pct = (worst * 100).toInt().coerceIn(0, 100)
                text = when { worst <= 0.0 -> "No scrolling yet today 🎉"; left <= 0L -> "$name · limit reached"; else -> "$name · ${fmt(left)} left" }
            } catch (e: SecurityException) { text = "Turn on Usage Access in MeowTime" }
            val level = if (pct >= 100) 2 else if (pct >= 80) 1 else 0
            val s = Treats.streak(c); val left = Treats.PER_DAY - Treats.today(c)
            val streakText = if (s > 0) "🔥 $s-day streak" else "Feed me to start a streak"
            val treatText = if (left > 0) "🍖 Treat" else "😴 Full"
            return State(mood, text, pct, level, streakText, treatText)
        }

        private fun render(c: Context, m: AppWidgetManager, ids: IntArray, bmp: Bitmap?, bubble: String?, st: State) {
            if (ids.isEmpty()) return
            val v = RemoteViews(c.packageName, R.layout.widget_cat)
            v.setImageViewBitmap(R.id.cat_img, bmp ?: art(c, CatArt.outfit(c), st.mood))
            v.setTextViewText(R.id.bubble, bubble ?: Mood.say.getValue(st.mood))
            v.setTextViewText(R.id.usage_text, st.usageText)
            v.setViewVisibility(R.id.bar_ok, if (st.level == 0) View.VISIBLE else View.GONE)
            v.setViewVisibility(R.id.bar_warn, if (st.level == 1) View.VISIBLE else View.GONE)
            v.setViewVisibility(R.id.bar_bad, if (st.level == 2) View.VISIBLE else View.GONE)
            for (id in intArrayOf(R.id.bar_ok, R.id.bar_warn, R.id.bar_bad)) v.setProgressBar(id, 100, st.pct, false)
            v.setTextViewText(R.id.streak, st.streakText)
            v.setTextViewText(R.id.treat_btn, st.treatText)
            val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            v.setOnClickPendingIntent(R.id.cat_img, PendingIntent.getBroadcast(c, 0, Intent(c, MeowWidget::class.java).setAction(ACTION_PET), flags))
            v.setOnClickPendingIntent(R.id.treat_btn, PendingIntent.getBroadcast(c, 2, Intent(c, MeowWidget::class.java).setAction(ACTION_TREAT), flags))
            val open = PendingIntent.getActivity(c, 1, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            v.setOnClickPendingIntent(R.id.bubble, open)
            v.setOnClickPendingIntent(R.id.usage_text, open)
            m.updateAppWidget(ids, v)
            if (bmp == null && bubble == null) prefs(c).edit().putString("widget_sig", st.sig).apply()
        }

        /** Runs one animation at a time; a second request while one is playing is simply skipped. */
        private fun play(block: () -> Unit) {
            if (!busy.compareAndSet(false, true)) return
            try { block() } finally { busy.set(false) }
        }

        private fun pet(c: Context) = play {
            val (m, ids) = widgetIds(c); val outfit = CatArt.outfit(c); val st = state(c)
            val base = art(c, outfit, "excited")
            for (p in floatArrayOf(.1f, .25f, .4f, .55f, .7f, .85f)) { render(c, m, ids, withHearts(base, outfit, p), "Purr… 💗", st); Thread.sleep(280) }
            render(c, m, ids, null, null, st)
        }

        private fun treat(c: Context) = play {
            val (m, ids) = widgetIds(c); val outfit = CatArt.outfit(c)
            if (!Treats.give(c)) {
                val st = state(c); val base = art(c, outfit, "sleepy")
                render(c, m, ids, base, "I'm full for today! 😴", st); Thread.sleep(1800)
                render(c, m, ids, null, null, st); return@play
            }
            val st = state(c); val base = art(c, outfit, "excited")
            for (k in 0..4) { render(c, m, ids, withTreat(base, outfit, k / 4f), "Ooh, a treat! 🍖", st); Thread.sleep(220) }
            for (p in floatArrayOf(.2f, .45f, .7f, .9f)) { render(c, m, ids, withHearts(base, outfit, p), "Yum! 😋", st); Thread.sleep(280) }
            render(c, m, ids, null, null, st)
        }

        /** A small blink or wiggle now and then so the cat feels alive. Skipped when the screen is off. */
        fun idle(c: Context) {
            val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isInteractive) return
            val (m, ids) = widgetIds(c)
            if (ids.isEmpty()) return
            play {
                val outfit = CatArt.outfit(c); val st = state(c)
                val base = art(c, outfit, st.mood)
                if (st.mood != "sleepy" && st.mood != "sad" && Math.random() < 0.5) {
                    render(c, m, ids, art(c, outfit, "sleepy"), null, st); Thread.sleep(170)   // eyes closed = blink
                } else {
                    for ((a, l) in listOf(-5f to 0f, 0f to .04f, 5f to 0f, 0f to .04f, 0f to 0f)) {
                        render(c, m, ids, pose(base, a, l), null, st); Thread.sleep(160)
                    }
                }
                render(c, m, ids, null, null, st)
            }
        }

        /** Cheap check the blocker service runs every few seconds: redraw only when something shown has changed. */
        fun refreshIfChanged(c: Context) {
            if (busy.get()) return
            if (state(c).sig != prefs(c).getString("widget_sig", null)) refresh(c)
        }

        fun refresh(c: Context) {
            val (m, ids) = widgetIds(c)
            if (ids.isNotEmpty()) render(c, m, ids, null, null, state(c))
        }
    }
}
